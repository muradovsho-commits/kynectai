"""web_read.py - cross-platform "read a page's text" used by outreach/coffee prep.

macOS:   drives the user's Google Chrome via AppleScript (mac_chrome.py).
Windows: drives a dedicated Chrome profile via Selenium, so the user logs into
         LinkedIn once and the session persists across runs.

Public contract (matches mac_chrome): read_url_text(url, wait) -> str
Returns "" on any failure (callers fall back to drafting from the details given).
"""

import sys
import time
import threading
from pathlib import Path

_lock = threading.Lock()
_driver = None  # reused so the logged-in Chrome window stays warm


def _profile_dir() -> str:
    # Lives next to the OB app files: ob/.ob_chrome_profile
    base = Path(__file__).resolve().parent
    p = base / ".ob_chrome_profile"
    try:
        p.mkdir(exist_ok=True)
    except Exception:
        pass
    return str(p)


def _new_driver():
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    opts = Options()
    opts.add_argument("--user-data-dir=" + _profile_dir())
    opts.add_argument("--no-first-run")
    opts.add_argument("--no-default-browser-check")
    opts.add_argument("--start-minimized")
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.add_experimental_option("useAutomationExtension", False)
    # Selenium Manager (Selenium >= 4.6) auto-resolves the matching chromedriver.
    return webdriver.Chrome(options=opts)


def _selenium_read(url: str, wait: float) -> str:
    global _driver
    try:
        import selenium  # noqa: F401
    except Exception:
        print("[web_read] Selenium not installed. Run: "
              ".venv\\Scripts\\python.exe -m pip install selenium")
        return ""

    with _lock:
        for attempt in range(2):
            try:
                if _driver is None:
                    _driver = _new_driver()
                _driver.get(url)
                time.sleep(max(1.0, float(wait)))
                txt = _driver.execute_script("return document.body.innerText;")
                return (txt or "").strip()
            except Exception as e:
                print("[web_read] chrome read error:", str(e)[:160])
                # Driver may have died (window closed); drop it and retry once.
                try:
                    if _driver is not None:
                        _driver.quit()
                except Exception:
                    pass
                _driver = None
        return ""


def read_url_text(url: str, wait: float = 4.0) -> str:
    if sys.platform == "darwin":
        try:
            import mac_chrome
            return mac_chrome.read_url_text(url, wait=wait)
        except Exception as e:
            print("[web_read] mac_chrome error:", str(e)[:120])
            return ""
    # Windows / Linux
    return _selenium_read(url, wait)


def chrome_installed() -> bool:
    """Best-effort, mirrors mac_chrome.chrome_installed() for callers that check."""
    if sys.platform == "darwin":
        try:
            import mac_chrome
            return mac_chrome.chrome_installed()
        except Exception:
            return False
    return True  # assume Chrome present on Windows; Selenium will surface a clear error if not
