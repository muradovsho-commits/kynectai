"""
activehud.py — OB active HUD.

Orb is a portal: hover it to reveal tab nodes embedded in the neuron network,
click a node to fly through the particles into that tab (zoom transition).
In a tab the orb shrinks to the top-left corner and the dock stays visible;
Esc or the back arrow flies you back out. Memory is the first real tab; the
others are placeholders. New tabs plug in via register_tab().

Dock is a control panel only: mic (mute), settings, back-to-idle.
"""
import math
import os
import html
import json
import random

from PyQt6.QtWidgets import (
    QWidget, QScrollArea, QVBoxLayout, QHBoxLayout, QLineEdit, QLabel, QPushButton, QGridLayout, QApplication
)
from PyQt6.QtCore import Qt, QTimer, QPointF, QRectF, QRect, pyqtSignal, pyqtSlot, QObject, QUrl
from PyQt6.QtGui import QPainter, QColor, QRadialGradient, QLinearGradient, QPen, QPainterPath, QPixmap, QFont, QImage, QFontMetrics

MEM_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "memory", "long_term.json")


def _load_mem():
    try:
        with open(MEM_PATH, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_mem(data):
    try:
        os.makedirs(os.path.dirname(MEM_PATH), exist_ok=True)
        with open(MEM_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print("[Memory] save failed:", e)
        return False


def draw_brain(p, ox, oy, s, col, width=1.7):
    p.save()
    p.translate(ox, oy); p.scale(s, s); p.translate(-30, -30)
    pen = QPen(col); pen.setWidthF(width); pen.setCosmetic(True)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap); pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush)
    path = QPainterPath()
    path.moveTo(30, 12)
    path.cubicTo(40, 11, 50, 16, 49, 24)
    path.cubicTo(53, 28.5, 51.5, 36, 45.5, 38)
    path.cubicTo(44.5, 44, 37, 47, 30, 43.5)
    path.cubicTo(23, 47, 15.5, 44, 14.5, 38)
    path.cubicTo(8.5, 36, 7, 28.5, 11, 24)
    path.cubicTo(10, 16, 20, 11, 30, 12)
    p.drawPath(path)
    p.drawLine(QPointF(30, 13.5), QPointF(30, 42.5))
    for fp in (((23, 18), (17, 21), (19, 25)), ((24, 28), (17, 31), (21, 35)),
               ((37, 18), (43, 21), (41, 25)), ((36, 28), (43, 31), (39, 35))):
        fl = QPainterPath(); fl.moveTo(fp[0][0], fp[0][1])
        fl.quadTo(fp[1][0], fp[1][1], fp[2][0], fp[2][1]); p.drawPath(fl)
    p.restore()


# ---- node glyphs (drawn directly onto the orb, 24-unit box) ----
def _ng_clock(p):
    p.drawEllipse(QPointF(12, 12), 8.5, 8.5)
    p.drawLine(QPointF(12, 12), QPointF(12, 6.5)); p.drawLine(QPointF(12, 12), QPointF(15.5, 13.5))
def _ng_folder(p):
    path = QPainterPath(); path.moveTo(3, 8); path.lineTo(3, 18); path.lineTo(21, 18)
    path.lineTo(21, 9); path.lineTo(11, 9); path.lineTo(9, 7); path.lineTo(3, 7); path.closeSubpath()
    p.drawPath(path)
def _ng_doc(p):
    path = QPainterPath(); path.addRoundedRect(QRectF(5, 3, 14, 18), 2, 2); p.drawPath(path)
    for y in (8, 12, 16): p.drawLine(QPointF(8, y), QPointF(16, y))
def _ng_music(p):
    p.drawEllipse(QPointF(8, 17), 2.6, 2.6); p.drawLine(QPointF(10.6, 17), QPointF(10.6, 6))
    p.drawLine(QPointF(10.6, 6), QPointF(16, 8)); p.drawLine(QPointF(16, 8), QPointF(16, 14))
    p.drawEllipse(QPointF(13.4, 14.5), 2.6, 2.6)
def _ng_search(p):
    p.drawEllipse(QPointF(10.5, 10.5), 6, 6); p.drawLine(QPointF(14.8, 14.8), QPointF(19, 19))
def _ng_system(p):
    path = QPainterPath(); path.addRoundedRect(QRectF(7, 7, 10, 10), 1.5, 1.5); p.drawPath(path)
    for off in (10, 14):
        p.drawLine(QPointF(off, 3), QPointF(off, 7)); p.drawLine(QPointF(off, 17), QPointF(off, 21))
        p.drawLine(QPointF(3, off), QPointF(7, off)); p.drawLine(QPointF(17, off), QPointF(21, off))
def _ng_dot(p):
    p.drawEllipse(QPointF(12, 12), 3, 3)
def _ng_cookbook(p):
    # lid
    p.drawLine(QPointF(4.5, 10.5), QPointF(19.5, 10.5))
    p.drawEllipse(QPointF(12, 8.7), 1.1, 1.1)
    # pot body
    path = QPainterPath(); path.moveTo(5.6, 10.5)
    path.lineTo(6.4, 18.8); path.quadTo(6.6, 20.0, 7.8, 20.0)
    path.lineTo(16.2, 20.0); path.quadTo(17.4, 20.0, 17.6, 18.8)
    path.lineTo(18.4, 10.5)
    p.drawPath(path)
    # handles
    p.drawLine(QPointF(3.3, 12.0), QPointF(5.6, 12.0))
    p.drawLine(QPointF(18.4, 12.0), QPointF(20.7, 12.0))
    # steam
    s1 = QPainterPath(); s1.moveTo(9.6, 6.6); s1.quadTo(8.1, 5.0, 9.6, 3.4); p.drawPath(s1)
    s2 = QPainterPath(); s2.moveTo(14.4, 6.6); s2.quadTo(15.9, 5.0, 14.4, 3.4); p.drawPath(s2)
def _ng_council(p):
    p.drawEllipse(QPointF(12, 6), 2.6, 2.6)
    p.drawEllipse(QPointF(6.5, 18), 2.6, 2.6)
    p.drawEllipse(QPointF(17.5, 18), 2.6, 2.6)
    p.drawLine(QPointF(12, 8.6), QPointF(12, 13))
    p.drawLine(QPointF(12, 13), QPointF(6.7, 15.6))
    p.drawLine(QPointF(12, 13), QPointF(17.3, 15.6))
def _ng_outreach(p):
    path = QPainterPath()
    path.moveTo(3.5, 12.5); path.lineTo(20.5, 4.5)
    path.lineTo(13.5, 20.0); path.lineTo(10.8, 13.2); path.closeSubpath()
    p.drawPath(path)
    p.drawLine(QPointF(10.8, 13.2), QPointF(20.5, 4.5))
def _ng_intern(p):
    p.drawRoundedRect(QRectF(6, 5.5, 12, 15.5), 2, 2)
    p.drawRoundedRect(QRectF(9.5, 3, 5, 3.5), 1, 1)
    p.drawLine(QPointF(9, 11), QPointF(15, 11))
    p.drawLine(QPointF(9, 14.5), QPointF(15, 14.5))
    p.drawLine(QPointF(9, 18), QPointF(13, 18))
def _ng_back(p):
    p.drawLine(QPointF(14.5, 6), QPointF(8, 12))
    p.drawLine(QPointF(8, 12), QPointF(14.5, 18))
    p.drawLine(QPointF(8, 12), QPointF(19, 12))
def _ng_study(p):
    p.drawRoundedRect(QRectF(5, 4, 14, 16), 2, 2)
    p.drawLine(QPointF(8, 9), QPointF(16, 9))
    p.drawLine(QPointF(8, 12), QPointF(16, 12))
    p.drawLine(QPointF(8, 15), QPointF(13, 15))
def _ng_brief(p):
    p.drawLine(QPointF(3, 16.5), QPointF(21, 16.5))
    p.drawArc(QRectF(7, 9.5, 10, 14), 0, 180 * 16)
    p.drawLine(QPointF(12, 4.5), QPointF(12, 6.8))
    p.drawLine(QPointF(5.5, 7.5), QPointF(7, 8.8))
    p.drawLine(QPointF(18.5, 7.5), QPointF(17, 8.8))
def _ng_earn(p):
    p.drawRoundedRect(QRectF(4.5, 6, 15, 13), 2, 2)
    p.drawLine(QPointF(4.5, 10.5), QPointF(19.5, 10.5))
    p.drawLine(QPointF(8.5, 4), QPointF(8.5, 7))
    p.drawLine(QPointF(15.5, 4), QPointF(15.5, 7))
def _ng_fdiff(p):
    p.drawRoundedRect(QRectF(5, 4.5, 9, 12), 1.2, 1.2)
    p.drawRoundedRect(QRectF(10, 7.5, 9, 12), 1.2, 1.2)
def _ng_teardown(p):
    p.drawLine(QPointF(4.5, 19.5), QPointF(20, 19.5))
    p.drawRect(QRectF(6, 12, 3.2, 7))
    p.drawRect(QRectF(11, 7.5, 3.2, 11.5))
    p.drawRect(QRectF(16, 14.5, 3.2, 4.5))
def _ng_crm(p):
    p.drawEllipse(QPointF(8.5, 8.5), 2.3, 2.3)
    b1 = QPainterPath(); b1.moveTo(4.5, 18.5); b1.arcTo(QRectF(4.5, 13.0, 8.0, 11.0), 180, -180); p.drawPath(b1)
    p.drawEllipse(QPointF(15.6, 9.6), 1.9, 1.9)
    b2 = QPainterPath(); b2.moveTo(12.9, 18.8); b2.arcTo(QRectF(12.9, 14.2, 6.4, 9.0), 155, -150); p.drawPath(b2)
def _ng_contacts(p):
    p.drawEllipse(QPointF(12.0, 8.4), 3.2, 3.2)
    b = QPainterPath(); b.moveTo(5.6, 19.6); b.arcTo(QRectF(5.6, 12.6, 12.8, 15.0), 180, -180); p.drawPath(b)


def _ng_prep(p):
    cup = QPainterPath(); cup.addRoundedRect(QRectF(5, 9, 10, 9), 1.5, 1.5); p.drawPath(cup)
    handle = QPainterPath(); handle.moveTo(15, 11); handle.arcTo(QRectF(14, 10, 5, 6), 90, -180); p.drawPath(handle)
    p.drawLine(QPointF(7.5, 4.5), QPointF(7.5, 6.8))
    p.drawLine(QPointF(10, 4.5), QPointF(10, 6.8))
    p.drawLine(QPointF(12.5, 4.5), QPointF(12.5, 6.8))

_NODE_GLYPHS = {"clock": _ng_clock, "folder": _ng_folder, "doc": _ng_doc,
                "music": _ng_music, "search": _ng_search, "system": _ng_system,
                "cookbook": _ng_cookbook, "council": _ng_council, "outreach": _ng_outreach,
                "prep": _ng_prep, "crm": _ng_crm, "teardown": _ng_teardown, "fdiff": _ng_fdiff, "earn": _ng_earn, "brief": _ng_brief, "study": _ng_study, "intern": _ng_intern, "contacts": _ng_contacts, "back": _ng_back}

# curated Ollama model catalog for the Cookbook tab
_CB_CATALOG = [
    # General
    {"name": "qwen2.5:7b",          "label": "Qwen 2.5 7B",        "gb": 4.7,  "cat": "General",   "blurb": "Strong all-rounder. OB default."},
    {"name": "qwen2.5:3b",          "label": "Qwen 2.5 3B",        "gb": 1.9,  "cat": "General",   "blurb": "Small and snappy."},
    {"name": "qwen2.5:14b",         "label": "Qwen 2.5 14B",       "gb": 9.0,  "cat": "General",   "blurb": "Smarter, heavier."},
    {"name": "qwen2.5:32b",         "label": "Qwen 2.5 32B",       "gb": 20.0, "cat": "General",   "blurb": "Big. Won't fit 16GB."},
    {"name": "llama3.1:8b",         "label": "Llama 3.1 8B",       "gb": 4.9,  "cat": "General",   "blurb": "Meta's reliable workhorse."},
    {"name": "llama3.2:3b",         "label": "Llama 3.2 3B",       "gb": 2.0,  "cat": "General",   "blurb": "Light and capable."},
    {"name": "llama3.3:70b",        "label": "Llama 3.3 70B",      "gb": 43.0, "cat": "General",   "blurb": "Frontier-class. Needs big RAM."},
    {"name": "mistral:7b",          "label": "Mistral 7B",         "gb": 4.1,  "cat": "General",   "blurb": "Fast and lean."},
    {"name": "mistral-nemo:12b",    "label": "Mistral Nemo 12B",   "gb": 7.1,  "cat": "General",   "blurb": "128k context."},
    {"name": "mixtral:8x7b",        "label": "Mixtral 8x7B",       "gb": 26.0, "cat": "General",   "blurb": "Mixture of experts. Heavy."},
    {"name": "gemma2:2b",           "label": "Gemma 2 2B",         "gb": 1.6,  "cat": "General",   "blurb": "Tiny Google model."},
    {"name": "gemma2:9b",           "label": "Gemma 2 9B",         "gb": 5.4,  "cat": "General",   "blurb": "Google's open model."},
    {"name": "gemma2:27b",          "label": "Gemma 2 27B",        "gb": 16.0, "cat": "General",   "blurb": "Large Gemma. Tight."},
    {"name": "phi3:3.8b",           "label": "Phi-3 Mini 3.8B",    "gb": 2.2,  "cat": "General",   "blurb": "Microsoft, small + sharp."},
    {"name": "solar:10.7b",         "label": "Solar 10.7B",        "gb": 6.1,  "cat": "General",   "blurb": "Upstage, strong mid-size."},
    {"name": "yi:9b",               "label": "Yi 9B",              "gb": 5.0,  "cat": "General",   "blurb": "01.AI bilingual model."},
    {"name": "command-r:35b",       "label": "Command R 35B",      "gb": 20.0, "cat": "General",   "blurb": "Cohere RAG model. Heavy."},
    # Coding
    {"name": "qwen2.5-coder:1.5b",  "label": "Qwen 2.5 Coder 1.5B","gb": 1.0,  "cat": "Coding",    "blurb": "Tiny code model."},
    {"name": "qwen2.5-coder:7b",    "label": "Qwen 2.5 Coder 7B",  "gb": 4.7,  "cat": "Coding",    "blurb": "Best small coding model."},
    {"name": "qwen2.5-coder:14b",   "label": "Qwen 2.5 Coder 14B", "gb": 9.0,  "cat": "Coding",    "blurb": "Stronger code, tight on RAM."},
    {"name": "qwen2.5-coder:32b",   "label": "Qwen 2.5 Coder 32B", "gb": 20.0, "cat": "Coding",    "blurb": "Top open coder. Big."},
    {"name": "deepseek-coder-v2:16b","label":"DeepSeek Coder V2 16B","gb": 8.9, "cat": "Coding",    "blurb": "Strong code MoE."},
    {"name": "codellama:7b",        "label": "Code Llama 7B",      "gb": 3.8,  "cat": "Coding",    "blurb": "Meta code model."},
    {"name": "codellama:13b",       "label": "Code Llama 13B",     "gb": 7.4,  "cat": "Coding",    "blurb": "Bigger Code Llama."},
    {"name": "codegemma:7b",        "label": "CodeGemma 7B",       "gb": 5.0,  "cat": "Coding",    "blurb": "Google code model."},
    {"name": "starcoder2:7b",       "label": "StarCoder2 7B",      "gb": 4.0,  "cat": "Coding",    "blurb": "Code completion."},
    {"name": "starcoder2:15b",      "label": "StarCoder2 15B",     "gb": 9.1,  "cat": "Coding",    "blurb": "Larger StarCoder."},
    # Reasoning
    {"name": "deepseek-r1:1.5b",    "label": "DeepSeek R1 1.5B",   "gb": 1.1,  "cat": "Reasoning", "blurb": "Tiny reasoner."},
    {"name": "deepseek-r1:7b",      "label": "DeepSeek R1 7B",     "gb": 4.7,  "cat": "Reasoning", "blurb": "Step-by-step reasoning."},
    {"name": "deepseek-r1:8b",      "label": "DeepSeek R1 8B",     "gb": 4.9,  "cat": "Reasoning", "blurb": "Llama-distilled R1."},
    {"name": "deepseek-r1:14b",     "label": "DeepSeek R1 14B",    "gb": 9.0,  "cat": "Reasoning", "blurb": "Deeper reasoning, tight."},
    {"name": "deepseek-r1:32b",     "label": "DeepSeek R1 32B",    "gb": 20.0, "cat": "Reasoning", "blurb": "Strong reasoner. Big."},
    {"name": "qwq:32b",             "label": "QwQ 32B",            "gb": 20.0, "cat": "Reasoning", "blurb": "Qwen reasoning model. Big."},
    {"name": "phi4:14b",            "label": "Phi-4 14B",          "gb": 9.1,  "cat": "Reasoning", "blurb": "Punches above its weight."},
    # Fast / tiny
    {"name": "llama3.2:1b",         "label": "Llama 3.2 1B",       "gb": 1.3,  "cat": "Fast",      "blurb": "Instant, weak."},
    {"name": "qwen2.5:1.5b",        "label": "Qwen 2.5 1.5B",      "gb": 1.0,  "cat": "Fast",      "blurb": "Very small."},
    {"name": "qwen2.5:0.5b",        "label": "Qwen 2.5 0.5B",      "gb": 0.4,  "cat": "Fast",      "blurb": "Smallest usable."},
    {"name": "tinyllama:1.1b",      "label": "TinyLlama 1.1B",     "gb": 0.6,  "cat": "Fast",      "blurb": "Toy-tier, ultra fast."},
    {"name": "gemma2:2b",           "label": "Gemma 2 2B (fast)",  "gb": 1.6,  "cat": "Fast",      "blurb": "Quick Google model."},
    # Vision
    {"name": "llava:7b",            "label": "LLaVA 7B",           "gb": 4.7,  "cat": "Vision",    "blurb": "Reads images."},
    {"name": "llava:13b",           "label": "LLaVA 13B",          "gb": 8.0,  "cat": "Vision",    "blurb": "Bigger vision model."},
    {"name": "llama3.2-vision:11b", "label": "Llama 3.2 Vision 11B","gb": 7.9, "cat": "Vision",    "blurb": "Meta vision model."},
    {"name": "minicpm-v:8b",        "label": "MiniCPM-V 8B",       "gb": 5.5,  "cat": "Vision",    "blurb": "Efficient vision model."},
    {"name": "bakllava:7b",         "label": "BakLLaVA 7B",        "gb": 4.7,  "cat": "Vision",    "blurb": "Mistral-based vision."},
]


class _ClickCard(QWidget):
    """A clickable panel that emits clicked() on press."""
    clicked = pyqtSignal()
    def mousePressEvent(self, e):
        self.clicked.emit()


def _md_inline(s):
    import re as _re
    s = html.escape(s)
    s = _re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
    s = _re.sub(r"`(.+?)`", r"<span style='color:#9fd0a8'>\1</span>", s)
    return s


def _md_to_html(md):
    import re as _re
    out = []
    for raw in (md or "").split("\n"):
        line = raw.rstrip()
        if not line.strip():
            out.append("<div style='font-size:5px'>&nbsp;</div>")
            continue
        m = _re.match(r"^(#{1,4})\s+(.*)$", line)
        if m:
            sz = {1: 15, 2: 14, 3: 13, 4: 12}[len(m.group(1))]
            out.append("<div style='color:#7fb0ee;font-size:%dpx;font-weight:700;margin:8px 0 2px 0'>%s</div>" % (sz, _md_inline(m.group(2))))
            continue
        m2 = _re.match(r"^\s*[-*]\s+(.*)$", line)
        if m2:
            out.append("<div style='margin:1px 0 1px 12px'>&#8226;&nbsp;%s</div>" % _md_inline(m2.group(1)))
            continue
        m3 = _re.match(r"^\s*(\d+)\.\s+(.*)$", line)
        if m3:
            out.append("<div style='margin:1px 0 1px 12px'>%s.&nbsp;%s</div>" % (m3.group(1), _md_inline(m3.group(2))))
            continue
        out.append("<div style='margin:2px 0'>%s</div>" % _md_inline(line))
    return "<div style=\"font-family:-apple-system,'Helvetica Neue',sans-serif;font-size:13px;color:#d7e4f6;line-height:1.45\">" + "".join(out) + "</div>"


def _hud_store_dir():
    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def _hud_store_load(kind):
    try:
        return json.load(open(os.path.join(_hud_store_dir(), kind + "_history.json")))
    except Exception:
        return []


def _hud_store_add(kind, item):
    items = _hud_store_load(kind)
    items.insert(0, item)
    items = items[:50]
    try:
        json.dump(items, open(os.path.join(_hud_store_dir(), kind + "_history.json"), "w"), indent=2)
    except Exception as e:
        print("[store]", e)


def _hud_store_save(kind, items):
    try:
        json.dump(items, open(os.path.join(_hud_store_dir(), kind + "_history.json"), "w"), indent=2)
    except Exception as e:
        print("[store]", e)


_BACKBTN = '<button class="backbtn" onclick="window.bridge.goBack()" aria-label="Back">&#8249;</button>'


class _OutreachBridge(QObject):
    """JS <-> Python bridge for the Outreach web tab."""
    draftReady = pyqtSignal(str)
    historyReady = pyqtSignal(str)
    exitRequested = pyqtSignal()
    batchUpdate = pyqtSignal(str)
    batchDone = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    @pyqtSlot()
    def getHistory(self):
        import json as _json
        self.historyReady.emit(_json.dumps(_hud_store_load("outreach")))

    @pyqtSlot(str)
    def researchBatch(self, payload):
        import json as _json, threading
        try:
            d = _json.loads(payload)
        except Exception:
            d = {}
        urls = [u.strip() for u in (d.get("urls") or []) if u and u.strip()][:15]
        angle = d.get("angle", "alumni"); context = d.get("context", "")

        def worker():
            from actions import outreach as _oa
            for ix, url in enumerate(urls):
                self.batchUpdate.emit(_json.dumps({"index": ix, "url": url, "status": "working"}))
                try:
                    res = _oa.research_profile(linkedin_url=url, email="", context=context, angle=angle)
                except Exception as e:
                    res = {"error": str(e)}
                res["index"] = ix; res["url"] = url; res["status"] = "done"; res["email"] = ""
                self.batchUpdate.emit(_json.dumps(res))
                if not res.get("error"):
                    import time as _t
                    item = {"id": str(int(_t.time() * 1000)) + "_" + str(ix), "ts": int(_t.time()),
                            "title": (res.get("name") or "Draft") + " \u00b7 " + (res.get("subject") or ""),
                            "data": {"url": url, "email": "", "context": context, "angle": angle,
                                     "name": res.get("name", ""), "summary": res.get("summary", ""),
                                     "subject": res.get("subject", ""), "body": res.get("body", ""),
                                     "read_profile": res.get("read_profile", False)}}
                    _hud_store_add("outreach", item)
            self.historyReady.emit(_json.dumps(_hud_store_load("outreach")))
            self.batchDone.emit()

        threading.Thread(target=worker, daemon=True).start()

    @pyqtSlot(str)
    def research(self, payload):
        import json as _json, threading
        try:
            d = _json.loads(payload)
        except Exception:
            d = {}

        def worker():
            try:
                from actions import outreach as _oa
                res = _oa.research_profile(
                    linkedin_url=d.get("url", ""), email=d.get("email", ""),
                    context=d.get("context", ""), angle=d.get("angle", "alumni"))
            except Exception as e:
                res = {"error": str(e)}
            res["email"] = d.get("email", "")
            self.draftReady.emit(_json.dumps(res))
            if not res.get("error"):
                import time as _t
                item = {"id": str(int(_t.time() * 1000)), "ts": int(_t.time()),
                        "title": (res.get("name") or "Draft") + " · " + (res.get("subject") or ""),
                        "data": {"url": d.get("url", ""), "email": d.get("email", ""), "context": d.get("context", ""),
                                 "angle": d.get("angle", "alumni"), "name": res.get("name", ""), "summary": res.get("summary", ""),
                                 "subject": res.get("subject", ""), "body": res.get("body", ""), "read_profile": res.get("read_profile", False)}}
                _hud_store_add("outreach", item)
                self.historyReady.emit(_json.dumps(_hud_store_load("outreach")))

        threading.Thread(target=worker, daemon=True).start()

    @pyqtSlot(str)
    def openComposer(self, payload):
        import json as _json, threading
        try:
            d = _json.loads(payload)
        except Exception:
            return

        def worker():
            try:
                from actions.draft_email import draft_email as draft_email_action
                draft_email_action(parameters={"to": d.get("email", ""),
                                               "subject": d.get("subject", ""),
                                               "body": d.get("body", "")})
            except Exception as e:
                print("[outreach] composer error:", e)

        threading.Thread(target=worker, daemon=True).start()

    @pyqtSlot(str)
    def copyText(self, text):
        try:
            QApplication.clipboard().setText(text)
        except Exception:
            pass


_OUTREACH_HTML = r"""<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>
:root{--bg:#0b0b0e;--surface:#161619;--surface2:#1d1d21;--border:#2a2a30;--text:#f1f0ee;--muted:#92928e;--accent:#2f6bff;--accent2:#2456cc;--good:#4ade80;--amber:#fbbf24;--red:#f87171}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--bg);color:var(--text);font-family:-apple-system,"SF Pro Display","Segoe UI",Roboto,sans-serif;-webkit-font-smoothing:antialiased}
body{padding:30px 26px 60px}
.wrap{max-width:720px;margin:0 auto}
.h1{font-size:24px;font-weight:600;letter-spacing:-0.02em}
.sub{color:var(--muted);font-size:14px;margin-top:4px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:20px;margin-top:18px}
label{display:block;font-size:12px;color:var(--muted);margin:0 0 6px 2px;font-weight:500}
input,textarea{width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--text);padding:12px 14px;font-size:14px;font-family:inherit;outline:none;transition:border-color .15s}
input:focus,textarea:focus{border-color:var(--accent)}
input::placeholder,textarea::placeholder{color:#5f5f5b}
.field{margin-bottom:14px}
.angles{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:14px}
.angle{background:var(--surface2);border:1px solid var(--border);border-radius:11px;padding:11px 12px;cursor:pointer;transition:all .12s}
.angle:hover{border-color:#3a3a42}
.angle.sel{border-color:var(--accent);background:rgba(47,107,255,0.10)}
.angle .top{display:flex;justify-content:space-between;align-items:center}
.angle .nm{font-size:13px;font-weight:600}
.angle .rt{font-size:11px;font-weight:600;padding:1px 7px;border-radius:20px}
.angle .sb{font-size:11px;color:var(--muted);margin-top:3px;line-height:1.3}
.btn{width:100%;background:var(--accent);color:#fff;border:none;border-radius:11px;padding:13px;font-size:14px;font-weight:600;cursor:pointer;font-family:inherit;transition:background .15s}
.btn:hover{background:var(--accent2)}
.btn:disabled{opacity:.55;cursor:default}
.btn.sec{background:transparent;border:1px solid var(--border);color:var(--text)}
.btn.sec:hover{border-color:var(--accent);background:transparent}
.row{display:flex;gap:10px}
.who{font-size:13px;color:#c9c9c5;line-height:1.55}
.tag{font-size:11px;font-weight:600;color:var(--good);background:rgba(74,222,128,0.12);padding:2px 9px;border-radius:20px;display:inline-block;margin-bottom:10px}
.tag.warn{color:var(--amber);background:rgba(251,191,36,0.12)}
.subj{font-size:15px;font-weight:600;color:#cfe0ff;margin-bottom:12px}
.body{font-size:14px;line-height:1.6;white-space:pre-wrap;color:#e3e2df}
.eyebrow{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;margin-bottom:12px}
.spinner{display:inline-block;width:15px;height:15px;border:2px solid rgba(255,255,255,.35);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;vertical-align:-2px;margin-right:8px}
@keyframes spin{to{transform:rotate(360deg)}}
.modes{display:inline-flex;background:var(--surface2);border:1px solid var(--border);border-radius:10px;padding:3px;margin-bottom:14px}
.mode{background:transparent;border:none;color:var(--muted);padding:7px 16px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit}
.mode.sel{background:var(--accent);color:#fff}
.bcard{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:14px 16px;margin-top:10px}
.bcard .bh{display:flex;align-items:center;gap:10px}.bcard .bn{font-size:14px;font-weight:600}
.bpill{font-size:11px;font-weight:600;padding:2px 9px;border-radius:20px;margin-left:auto}
.bpill.q{color:var(--muted);background:rgba(146,146,142,.15)}.bpill.w{color:var(--amber);background:rgba(251,191,36,.14)}.bpill.d{color:var(--good);background:rgba(74,222,128,.14)}.bpill.f{color:var(--red);background:rgba(248,113,113,.14)}
.bsubj{font-size:13px;font-weight:600;color:#cfe0ff;margin-top:10px}.bbody{font-size:13px;line-height:1.55;white-space:pre-wrap;color:#dededa;margin-top:6px}
.hidden{display:none}
.backbtn{position:fixed;top:12px;left:14px;width:34px;height:34px;border-radius:9px;background:rgba(255,255,255,.05);border:1px solid var(--border);color:var(--text);font-size:20px;line-height:1;cursor:pointer;z-index:50}.backbtn:hover{border-color:var(--accent)}
.hist-item{background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:10px 13px;margin-bottom:8px;cursor:pointer}.hist-item:hover{border-color:var(--accent)}.hist-item .t{font-size:13px;font-weight:600;color:var(--text)}.hist-item .d{font-size:11px;color:var(--muted);margin-top:3px}
</style></head><body>
<button class="backbtn" onclick="window.bridge.goBack()" aria-label="Back">&#8249;</button>
<div class="wrap">
  <div class="h1">Outreach</div>
  <div class="sub">Paste a LinkedIn profile, pick your angle, and get a personalized email in your voice.</div>

  <div class="card">
    <div class="modes"><button class="mode sel" id="m_single" onclick="setMode('single')">Single</button><button class="mode" id="m_batch" onclick="setMode('batch')">Batch</button></div>
    <div class="field" id="singleUrlField"><label>LinkedIn URL or name</label><input id="url" placeholder="https://www.linkedin.com/in/..."></div>
    <div class="field" id="batchField" style="display:none"><label>LinkedIn URLs, one per line</label><textarea id="urls" placeholder="https://www.linkedin.com/in/...&#10;https://www.linkedin.com/in/..." style="min-height:120px;resize:vertical"></textarea></div>
    <div class="field" id="emailField"><label>Recipient email <span style="color:#5f5f5b">(optional, to open the composer)</span></label><input id="email" placeholder="name@firm.com"></div>
    <label>What kind of message?</label>
    <div class="angles" id="angles"></div>
    <div class="field"><label id="ctxLabel">What do you have in common?</label><input id="context" placeholder=""></div>
    <button class="btn" id="go" onclick="run()">Research and draft</button>
  </div>

  <div id="whoCard" class="card hidden">
    <div class="eyebrow">Who they are</div>
    <div class="who" id="who"></div>
  </div>

  <div id="draftCard" class="card hidden">
    <div class="eyebrow">Draft</div>
    <div class="subj" id="subj"></div>
    <div class="body" id="bodyout"></div>
    <div class="row" style="margin-top:16px">
      <button class="btn" id="openBtn" onclick="openComposer()" style="flex:1;width:auto">Open in composer</button>
      <button class="btn sec" onclick="copyDraft()" style="flex:0 0 auto;width:auto;padding:13px 26px">Copy</button>
    </div>
  </div>
  <div id="batchOut" style="display:none"></div>
  <div class="eyebrow" style="margin-top:30px">Recent</div>
  <div id="hist"></div>
</div>
<script>
var ANGLES=[
 {k:"intro",n:"Intro",s:"First-time cold outreach"},
 {k:"warm",n:"Warm Intro",s:"Referral or mutual connection"},
 {k:"followup",n:"Follow-up",s:"After a call or prior email"},
 {k:"thankyou",n:"Thank You",s:"After a chat or their help"},
 {k:"reconnect",n:"Reconnect",s:"Old contact, pick back up"},
 {k:"congrats",n:"Congrats",s:"New role, deal, or news"},
 {k:"referral",n:"Referral Ask",s:"Ask for an intro/referral"},
 {k:"custom",n:"Custom",s:"Describe it in context"}];
var CTX={intro:"Why this person? Any hook?",warm:"Who referred you?",followup:"What happened + next step?",thankyou:"What are you thanking them for?",reconnect:"How do you know them?",congrats:"What's the news?",referral:"What are you asking for?",custom:"Describe the email you want"};
var PH={intro:"e.g. their group covers TMT, which I'm targeting",warm:"e.g. Jane Smith suggested I reach out",followup:"e.g. spoke Tuesday; you said apply when apps open",thankyou:"e.g. the coffee chat Thursday; recruiting advice",reconnect:"e.g. met at the 2024 conference; want to catch up",congrats:"e.g. promoted to VP; closed a big deal",referral:"e.g. intro to someone on the buyside team",custom:"e.g. short note sharing an article they'd like"};
var angle="intro", lastDraft=null;
function rateColor(r){return r>=55?"var(--good)":r>=35?"var(--amber)":"var(--red)"}
function rateBg(r){return r>=55?"rgba(74,222,128,0.12)":r>=35?"rgba(251,191,36,0.12)":"rgba(248,113,113,0.12)"}
function renderAngles(){
  var h="";
  ANGLES.forEach(function(a){
    h+='<div class="angle'+(a.k===angle?' sel':'')+'" onclick="pick(\''+a.k+'\')">'+
       '<div class="top"><span class="nm">'+a.n+'</span></div>'+
       '<div class="sb">'+a.s+'</div></div>';
  });
  document.getElementById("angles").innerHTML=h;
}
function pick(k){angle=k;renderAngles();document.getElementById("ctxLabel").textContent=CTX[k];document.getElementById("context").placeholder=PH[k];}
function run(){
  if(MODE==='batch')return runBatch();
  var go=document.getElementById("go");
  go.disabled=true;go.innerHTML='<span class="spinner"></span>Researching and drafting...';
  ["url","email","context"].forEach(function(id){var e=document.getElementById(id);if(e)e.disabled=true;});
  document.getElementById("whoCard").classList.remove("hidden");
  document.getElementById("who").innerHTML='<span class="spinner"></span> Researching their background and drafting your email...';
  document.getElementById("draftCard").classList.add("hidden");
  var payload={url:document.getElementById("url").value.trim(),email:document.getElementById("email").value.trim(),context:document.getElementById("context").value.trim(),angle:angle};
  window.bridge.research(JSON.stringify(payload));
}
function onDraft(s){
  var go=document.getElementById("go");
  go.disabled=false;go.textContent="Research and draft";
  ["url","email","context"].forEach(function(id){var e=document.getElementById(id);if(e)e.disabled=false;});
  var d={};try{d=JSON.parse(s)}catch(e){}
  if(d.error){document.getElementById("whoCard").classList.remove("hidden");document.getElementById("who").innerHTML='<span class="tag warn">Error</span><br>'+d.error;return;}
  var who=document.getElementById("who");
  var tag=d.read_profile?'<span class="tag">Read from LinkedIn</span>':'<span class="tag warn">From web search</span>';
  who.innerHTML=tag+'<br>'+(d.summary||"");
  document.getElementById("whoCard").classList.remove("hidden");
  document.getElementById("subj").textContent="Subject: "+(d.subject||"");
  document.getElementById("bodyout").textContent=d.body||"";
  document.getElementById("draftCard").classList.remove("hidden");
  lastDraft=d;
  document.getElementById("openBtn").style.opacity=(d.email&&d.email.indexOf("@")>-1)?"1":"0.55";
}
function openComposer(){if(!lastDraft||!lastDraft.email||lastDraft.email.indexOf("@")<0)return;window.bridge.openComposer(JSON.stringify({email:lastDraft.email,subject:lastDraft.subject,body:lastDraft.body}));}
function copyDraft(){if(!lastDraft)return;window.bridge.copyText("Subject: "+lastDraft.subject+"\n\n"+lastDraft.body);}
renderAngles();
function esch(x){return (x||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function fmtD(ts){try{return new Date(ts*1000).toLocaleDateString(undefined,{month:'short',day:'numeric'})}catch(e){return ''}}
var HIST=[];
function renderHistory(s){try{HIST=JSON.parse(s)}catch(e){HIST=[]}var h='';if(!HIST.length){h='<div style="color:var(--muted);font-size:13px">Nothing saved yet.</div>'}HIST.forEach(function(it,ix){h+='<div class="hist-item" onclick="loadItem('+ix+')"><div class="t">'+esch((it.title||'Draft').slice(0,70))+'</div><div class="d">'+fmtD(it.ts)+'</div></div>'});document.getElementById('hist').innerHTML=h}
function loadItem(ix){var it=HIST[ix];if(!it)return;var d=it.data||{};document.getElementById('url').value=d.url||'';document.getElementById('email').value=d.email||'';document.getElementById('context').value=d.context||'';if(d.angle){angle=d.angle;renderAngles();document.getElementById('ctxLabel').textContent=CTX[angle];document.getElementById('context').placeholder=PH[angle]||''}onDraft(JSON.stringify(d))}
var MODE='single',BRES=[];
function setMode(m){MODE=m;
 document.getElementById('m_single').className='mode'+(m==='single'?' sel':'');
 document.getElementById('m_batch').className='mode'+(m==='batch'?' sel':'');
 document.getElementById('singleUrlField').style.display=(m==='single')?'':'none';
 document.getElementById('batchField').style.display=(m==='batch')?'':'none';
 document.getElementById('emailField').style.display=(m==='batch')?'none':'';
 document.getElementById('go').textContent=(m==='batch')?'Draft all':'Research and draft';
 document.getElementById('whoCard').classList.add('hidden');
 document.getElementById('draftCard').classList.add('hidden');
 document.getElementById('batchOut').style.display=(m==='batch')?'':'none';}
function runBatch(){
 var raw=document.getElementById('urls').value.split('\n').map(function(x){return x.trim()}).filter(function(x){return x});
 if(!raw.length)return;
 var go=document.getElementById('go');go.disabled=true;go.innerHTML='<span class="spinner"></span>Drafting '+raw.length+'...';
 BRES=[];var bo=document.getElementById('batchOut');bo.style.display='';var h='';
 raw.forEach(function(u,ix){h+='<div class="bcard" id="bc_'+ix+'"><div class="bh"><span class="bn" id="bn_'+ix+'">'+esch(u.replace(/^https?:\/\/(www\.)?linkedin\.com\/in\//,'').replace(/\/$/,''))+'</span><span class="bpill q" id="bp_'+ix+'">Queued</span></div><div id="bd_'+ix+'"></div></div>'});
 bo.innerHTML=h;
 window.bridge.researchBatch(JSON.stringify({urls:raw,angle:angle,context:document.getElementById('context').value.trim()}));}
function onBatchUpdate(s){var d={};try{d=JSON.parse(s)}catch(e){return}if(d.index<0)return;var ix=d.index;
 var pill=document.getElementById('bp_'+ix),bn=document.getElementById('bn_'+ix),bd=document.getElementById('bd_'+ix);
 if(d.status==='working'){if(pill){pill.className='bpill w';pill.innerHTML='<span class="spinner"></span>'}return}
 if(d.status==='done'){BRES[ix]=d;
  if(d.error){if(pill){pill.className='bpill f';pill.textContent='Failed'}if(bd)bd.innerHTML='<div class="bbody" style="color:var(--red)">'+esch(d.error)+'</div>';return}
  if(bn&&d.name)bn.textContent=d.name;
  if(pill){pill.className='bpill d';pill.textContent='Done'}
  if(bd)bd.innerHTML='<div class="bsubj">Subject: '+esch(d.subject||'')+'</div><div class="bbody">'+esch(d.body||'')+'</div><div class="row" style="margin-top:10px"><button class="btn" style="width:auto;flex:0 0 auto;padding:8px 14px;font-size:12px" onclick="openBatch('+ix+')">Open in composer</button><button class="btn sec" style="width:auto;flex:0 0 auto;padding:8px 14px;font-size:12px" onclick="copyBatch('+ix+')">Copy</button></div>';}}
function onBatchDone(){var go=document.getElementById('go');go.disabled=false;go.textContent='Draft all';}
function openBatch(ix){var d=BRES[ix];if(!d)return;window.bridge.openComposer(JSON.stringify({email:d.email||'',subject:d.subject,body:d.body}));}
function copyBatch(ix){var d=BRES[ix];if(!d)return;window.bridge.copyText("Subject: "+d.subject+"\n\n"+d.body);}
new QWebChannel(qt.webChannelTransport,function(channel){window.bridge=channel.objects.bridge;window.bridge.draftReady.connect(onDraft);window.bridge.historyReady.connect(renderHistory);window.bridge.batchUpdate.connect(onBatchUpdate);window.bridge.batchDone.connect(onBatchDone);window.bridge.getHistory();});
</script></body></html>"""


class _CookbookBridge(QObject):
    stateReady = pyqtSignal(str)
    pullProgress = pyqtSignal(str)
    exitRequested = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    def _config_path(self):
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), "config", "api_keys.json")

    def _active(self):
        try:
            return json.load(open(self._config_path())).get("ollama_model", "")
        except Exception:
            return ""

    @pyqtSlot()
    def getState(self):
        import threading
        threading.Thread(target=self._emit_state, daemon=True).start()

    def _emit_state(self):
        import subprocess, requests, json as _json
        chip, ram = "Mac", 0
        try:
            chip = subprocess.check_output(["sysctl", "-n", "machdep.cpu.brand_string"], text=True).strip()
        except Exception:
            pass
        try:
            ram = round(int(subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True).strip()) / (1024 ** 3))
        except Exception:
            pass
        try:
            r = requests.get("http://localhost:11434/api/tags", timeout=6); r.raise_for_status()
            installed = [m.get("name", "") for m in r.json().get("models", [])]; up = True
        except Exception:
            installed, up = [], False
        active = self._active()

        def fit(gb):
            if ram <= 0 or not gb:
                return {"label": "", "tier": "na"}
            if gb <= ram * 0.35:
                return {"label": "Fits well", "tier": "good"}
            if gb <= ram * 0.6:
                return {"label": "Fits, tighter", "tier": "mid"}
            return {"label": "Risky on your RAM", "tier": "bad"}

        models, seen = [], set()
        for c in _CB_CATALOG:
            seen.add(c["name"])
            models.append({"name": c["name"], "label": c.get("label", c["name"]), "gb": c.get("gb", 0),
                           "cat": c.get("cat", "General"), "blurb": c.get("blurb", ""),
                           "installed": c["name"] in installed, "active": c["name"] == active,
                           "fit": fit(c.get("gb", 0))})
        for nm in installed:
            if nm not in seen:
                models.append({"name": nm, "label": nm, "gb": 0, "cat": "Installed",
                               "blurb": "Installed locally.", "installed": True,
                               "active": nm == active, "fit": {"label": "", "tier": "na"}})
        self.stateReady.emit(_json.dumps({"chip": chip, "ram": ram, "up": up, "active": active, "models": models}))

    @pyqtSlot(str)
    def setActive(self, model):
        try:
            p = self._config_path(); d = json.load(open(p)); d["ollama_model"] = model
            json.dump(d, open(p, "w"), indent=2)
        except Exception as e:
            print("[cookbook] set active:", e)
        try:
            import or_client; or_client.client.ollama_model = model
        except Exception:
            pass
        self._emit_state()

    @pyqtSlot(str)
    def deleteModel(self, model):
        import requests
        try:
            requests.delete("http://localhost:11434/api/delete", json={"name": model}, timeout=15)
        except Exception as e:
            print("[cookbook] delete:", e)
        self._emit_state()

    @pyqtSlot(str)
    def pull(self, model):
        import threading
        threading.Thread(target=self._pull_worker, args=(model,), daemon=True).start()

    def _pull_worker(self, model):
        import requests, json as _json
        try:
            with requests.post("http://localhost:11434/api/pull", json={"name": model, "stream": True},
                               stream=True, timeout=None) as r:
                for line in r.iter_lines():
                    if not line:
                        continue
                    try:
                        ev = _json.loads(line.decode("utf-8"))
                    except Exception:
                        continue
                    if ev.get("error"):
                        self.pullProgress.emit(_json.dumps({"model": model, "status": "error", "percent": 0, "done": True}))
                        return
                    if ev.get("status") == "success":
                        self.pullProgress.emit(_json.dumps({"model": model, "status": "success", "percent": 100, "done": True}))
                        self._emit_state(); return
                    pct = 0
                    if ev.get("total") and ev.get("completed"):
                        pct = int(ev["completed"] / ev["total"] * 100)
                    self.pullProgress.emit(_json.dumps({"model": model, "status": ev.get("status", "working"), "percent": pct, "done": False}))
            self._emit_state()
        except Exception as e:
            print("[cookbook] pull:", e)
            self.pullProgress.emit(_json.dumps({"model": model, "status": "error", "percent": 0, "done": True}))


class _CouncilBridge(QObject):
    agentsReady = pyqtSignal(str)
    agentUpdate = pyqtSignal(str)
    councilDone = pyqtSignal()
    exitRequested = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    @pyqtSlot()
    def getAgents(self):
        import json as _json
        try:
            from council import AGENTS
            data = [{"id": a["id"], "name": a["name"], "short": a.get("short", "")} for a in AGENTS]
        except Exception as e:
            print("[council] agents:", e); data = []
        self.agentsReady.emit(_json.dumps(data))

    @pyqtSlot(str)
    def convene(self, payload):
        import json as _json, threading
        try:
            d = _json.loads(payload)
        except Exception:
            d = {}
        goal = (d.get("goal") or "").strip()
        agents = d.get("agents") or None
        if not goal:
            return

        def cb(aid, status, text):
            self.agentUpdate.emit(_json.dumps({"id": aid, "status": status, "report": text}))

        def worker():
            try:
                import council as _c
                _c.run_council(goal, cb, agent_ids=agents)
            except Exception as e:
                self.agentUpdate.emit(_json.dumps({"id": "_error", "status": "error", "report": str(e)}))
            self.councilDone.emit()

        threading.Thread(target=worker, daemon=True).start()


_CB_CSS = """:root{--bg:#0b0b0e;--surface:#161619;--surface2:#1d1d21;--border:#2a2a30;--text:#f1f0ee;--muted:#92928e;--accent:#2f6bff;--accent2:#2456cc;--good:#4ade80;--amber:#fbbf24;--red:#f87171}
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:var(--bg);color:var(--text);font-family:-apple-system,"SF Pro Display","Segoe UI",Roboto,sans-serif;-webkit-font-smoothing:antialiased}
body{padding:30px 26px 60px}.wrap{max-width:860px;margin:0 auto}
.h1{font-size:24px;font-weight:600;letter-spacing:-.02em}.sub{color:var(--muted);font-size:14px;margin-top:4px}
.btn{background:var(--accent);color:#fff;border:none;border-radius:9px;padding:9px 12px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit}
.btn:hover{background:var(--accent2)}.btn:disabled{opacity:.6}
.spinner{display:inline-block;width:13px;height:13px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;vertical-align:-2px}
@keyframes spin{to{transform:rotate(360deg)}}
input,textarea{background:var(--surface2);border:1px solid var(--border);border-radius:10px;color:var(--text);padding:11px 14px;font-size:14px;font-family:inherit;outline:none}
input:focus,textarea:focus{border-color:var(--accent)}
.backbtn{position:fixed;top:12px;left:14px;width:34px;height:34px;border-radius:9px;background:rgba(255,255,255,.05);border:1px solid var(--border);color:var(--text);font-size:20px;line-height:1;cursor:pointer;z-index:50}.backbtn:hover{border-color:var(--accent)}
.hist-item{background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:10px 13px;margin-bottom:8px;cursor:pointer}.hist-item:hover{border-color:var(--accent)}.hist-item .t{font-size:13px;font-weight:600;color:var(--text)}.hist-item .d{font-size:11px;color:var(--muted);margin-top:3px}"""

_COOKBOOK_HTML = r"""<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>__CSS__
.hw{display:flex;gap:18px;align-items:center;background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:12px 16px;margin-top:16px;font-size:13px}
.warn{background:rgba(251,191,36,.1);border:1px solid rgba(251,191,36,.3);color:var(--amber);border-radius:12px;padding:12px 16px;margin-top:14px;font-size:13px}
.pullrow{display:flex;gap:10px;margin-top:16px}.pullrow input{flex:1}
.sec-h{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;margin:26px 0 10px 2px}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}
.m{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:14px 15px;display:flex;flex-direction:column}
.m.act{border-color:var(--accent)}.m .lab{font-size:14px;font-weight:600}
.m .nm{font-family:ui-monospace,Menlo,monospace;font-size:11px;color:var(--muted);margin-top:2px}
.m .bl{font-size:12px;color:#b9b9b4;margin-top:7px;line-height:1.4;flex:1}
.fit{font-size:11px;font-weight:600;padding:1px 8px;border-radius:20px;margin-top:8px;align-self:flex-start}
.row{display:flex;gap:8px;margin-top:11px}.row .btn{flex:1}
.btn.ghost{background:transparent;border:1px solid var(--border);color:var(--text)}
.btn.del{flex:0 0 auto;background:transparent;border:1px solid #5a2a2a;color:var(--red)}
</style></head><body>
<div class="wrap">
<div class="h1">Cookbook</div>
<div class="sub">Local models for OB, running on your Mac through Ollama.</div>
<div id="hw" class="hw" style="display:none"></div>
<div id="warn" class="warn" style="display:none">Ollama isn't reachable. Open the Ollama app, then reload this tab.</div>
<div class="pullrow"><input id="custom" placeholder="Pull any model by name, e.g. llama3.2:1b"><button class="btn" style="padding:11px 20px" onclick="pullCustom()">Pull</button></div>
<div id="cats"></div>
</div>
<script>
var STATE=null,pulling={};
function cssid(n){return n.replace(/[^a-zA-Z0-9]/g,'_')}
function fitStyle(t){return t==='good'?'color:var(--good);background:rgba(74,222,128,.12)':t==='mid'?'color:var(--amber);background:rgba(251,191,36,.12)':t==='bad'?'color:var(--red);background:rgba(248,113,113,.12)':'display:none'}
function onState(s){STATE=JSON.parse(s);render()}
function render(){var st=STATE;
 document.getElementById('warn').style.display=st.up?'none':'block';
 var hw=document.getElementById('hw');hw.style.display='flex';
 hw.innerHTML='<span><b>'+(st.chip||'Mac')+'</b></span>'+(st.ram?'<span>'+st.ram+' GB RAM</span>':'')+'<span style="margin-left:auto">Active brain: <b style="color:var(--accent)">'+(st.active||'none')+'</b></span>';
 var cats={};st.models.forEach(function(m){(cats[m.cat]=cats[m.cat]||[]).push(m)});
 var order=['General','Coding','Reasoning','Fast','Vision','Installed'];
 var keys=Object.keys(cats).sort(function(a,b){var ia=order.indexOf(a),ib=order.indexOf(b);return (ia<0?99:ia)-(ib<0?99:ib)});
 var h='';keys.forEach(function(c){h+='<div class="sec-h">'+c+'</div><div class="grid">';
  cats[c].forEach(function(m){h+='<div class="m'+(m.active?' act':'')+'"><div class="lab">'+m.label+'</div><div class="nm">'+m.name+'</div>';
   if(m.fit&&m.fit.label)h+='<div class="fit" style="'+fitStyle(m.fit.tier)+'">'+m.fit.label+'</div>';
   if(m.blurb)h+='<div class="bl">'+m.blurb+'</div>';
   h+='<div class="row">';
   if(m.active){h+='<button class="btn ghost" disabled>Active brain</button><button class="btn del" onclick="del(\''+m.name+'\')">Remove</button>'}
   else if(m.installed){h+='<button class="btn" onclick="use(\''+m.name+'\')">Use for OB</button><button class="btn del" onclick="del(\''+m.name+'\')">Remove</button>'}
   else{var lbl=pulling[m.name]?pulling[m.name]:('Download \u00b7 '+(m.gb||'?')+' GB');h+='<button class="btn" id="b_'+cssid(m.name)+'" onclick="pull(\''+m.name+'\')"'+(pulling[m.name]?' disabled':'')+'>'+lbl+'</button>'}
   h+='</div></div>'});h+='</div>'});
 document.getElementById('cats').innerHTML=h;}
function use(m){window.bridge.setActive(m)}
function del(m){window.bridge.deleteModel(m)}
function pull(m){pulling[m]='starting 0%';window.bridge.pull(m);var b=document.getElementById('b_'+cssid(m));if(b){b.disabled=true;b.textContent='starting 0%'}}
function pullCustom(){var v=document.getElementById('custom').value.trim();if(!v)return;document.getElementById('custom').value='';pulling[v]='starting 0%';window.bridge.pull(v)}
function onPull(s){var d=JSON.parse(s);
 if(d.done){if(d.status==='error'){pulling[d.model]=undefined;var b=document.getElementById('b_'+cssid(d.model));if(b){b.disabled=false;b.textContent='error, retry'}}else{delete pulling[d.model]}return}
 pulling[d.model]=d.status.slice(0,12)+' '+d.percent+'%';var b=document.getElementById('b_'+cssid(d.model));if(b){b.textContent=pulling[d.model]}}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.stateReady.connect(onState);bridge.pullProgress.connect(onPull);bridge.getState()});
</script></body></html>"""
_COOKBOOK_HTML = _COOKBOOK_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)

_COUNCIL_HTML = r"""<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>__CSS__
.wrap{max-width:720px}
textarea{width:100%;margin-top:18px;resize:vertical;min-height:64px}
.seats{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin-top:14px}
.seat{background:var(--surface2);border:1px solid var(--border);border-radius:11px;padding:11px 8px;cursor:pointer;text-align:center}
.seat.sel{border-color:var(--accent);background:rgba(47,107,255,.1)}
.seat .nm{font-size:12px;font-weight:600}.seat .sb{font-size:10px;color:var(--muted);margin-top:3px;line-height:1.25}
.go{width:100%;margin-top:14px;padding:13px;border-radius:11px;font-size:14px}
.rc{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px 18px;margin-top:14px}
.rc .top{display:flex;align-items:center;gap:10px}.rc .nm{font-size:15px;font-weight:600}
.pill{font-size:11px;font-weight:600;padding:2px 10px;border-radius:20px;margin-left:auto}
.pill.q{color:var(--muted);background:rgba(146,146,142,.15)}.pill.w{color:var(--amber);background:rgba(251,191,36,.14)}.pill.d{color:var(--good);background:rgba(74,222,128,.14)}
.rep{font-size:13.5px;line-height:1.6;color:#dededa;margin-top:10px}
.rep h2{font-size:15px;margin:12px 0 6px}.rep h3{font-size:13.5px;margin:10px 0 5px}
.rep ul{margin:6px 0 6px 18px}.rep li{margin:3px 0}.rep p{margin:7px 0}.rep b{font-weight:600;color:#fff}
</style></head><body>
<div class="wrap">
<div class="h1">Council</div>
<div class="sub">Five specialist agents think through your goal in sequence, each building on the last.</div>
<textarea id="goal" placeholder="What should the council work on? e.g. Launch a paid tier for OfferBell"></textarea>
<div class="seats" id="seats"></div>
<button class="btn go" id="go" onclick="convene()">Convene the council</button>
<div id="results"></div>
</div>
<script>
var SUBS={research:'Brief and prior art',business:'Market and model',architect:'Structure and design',developer:'Build plan',marketing:'Launch and traction'};
var AG=[],sel={};
function onAgents(s){AG=JSON.parse(s);AG.forEach(function(a){sel[a.id]=true});renderSeats()}
function renderSeats(){var h='';AG.forEach(function(a){h+='<div class="seat'+(sel[a.id]?' sel':'')+'" onclick="toggle(\''+a.id+'\')"><div class="nm">'+a.short+'</div><div class="sb">'+(SUBS[a.id]||'')+'</div></div>'});document.getElementById('seats').innerHTML=h}
function toggle(id){sel[id]=!sel[id];renderSeats()}
function esc(x){return x.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function inl(x){return esc(x).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>')}
function mdToHtml(t){if(!t)return '';var lines=t.split('\n'),h='',inUl=false;
 lines.forEach(function(ln){var s=ln.trim();
  if(/^#{2,}\s/.test(s)){if(inUl){h+='</ul>';inUl=false}h+='<h3>'+inl(s.replace(/^#+\s/,''))+'</h3>'}
  else if(/^#\s/.test(s)){if(inUl){h+='</ul>';inUl=false}h+='<h2>'+inl(s.replace(/^#\s/,''))+'</h2>'}
  else if(/^[-*]\s/.test(s)){if(!inUl){h+='<ul>';inUl=true}h+='<li>'+inl(s.replace(/^[-*]\s/,''))+'</li>'}
  else if(s===''){if(inUl){h+='</ul>';inUl=false}}
  else{if(inUl){h+='</ul>';inUl=false}h+='<p>'+inl(s)+'</p>'}});
 if(inUl)h+='</ul>';return h}
function nameOf(id){var a=AG.find(function(x){return x.id===id});return a?a.name:id}
function convene(){var goal=document.getElementById('goal').value.trim();if(!goal)return;
 var ids=AG.filter(function(a){return sel[a.id]}).map(function(a){return a.id});if(!ids.length)return;
 var go=document.getElementById('go');go.disabled=true;go.innerHTML='<span class="spinner"></span> Convening...';
 var h='';ids.forEach(function(id){h+='<div class="rc" id="rc_'+id+'"><div class="top"><span class="nm">'+nameOf(id)+'</span><span class="pill q" id="pill_'+id+'">Queued</span></div><div class="rep" id="rep_'+id+'"></div></div>'});
 document.getElementById('results').innerHTML=h;
 window.bridge.convene(JSON.stringify({goal:goal,agents:ids}))}
function onUpdate(s){var d=JSON.parse(s);
 if(d.id==='_error'){document.getElementById('results').innerHTML+='<div class="rc"><div class="rep">Council error: '+esc(d.report)+'</div></div>';return}
 var pill=document.getElementById('pill_'+d.id),rep=document.getElementById('rep_'+d.id);
 if(d.status==='working'){if(pill){pill.className='pill w';pill.innerHTML='<span class="spinner"></span>'}}
 else if(d.status==='done'){if(pill){pill.className='pill d';pill.textContent='Done'}if(rep){rep.innerHTML=mdToHtml(d.report)}}}
function onDone(){var go=document.getElementById('go');go.disabled=false;go.textContent='Convene the council'}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.agentsReady.connect(onAgents);bridge.agentUpdate.connect(onUpdate);bridge.councilDone.connect(onDone);bridge.getAgents()});
</script></body></html>"""
_COUNCIL_HTML = _COUNCIL_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)


class _PrepBridge(QObject):
    prepReady = pyqtSignal(str)
    historyReady = pyqtSignal(str)
    exitRequested = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    @pyqtSlot()
    def getHistory(self):
        import json as _json
        self.historyReady.emit(_json.dumps(_hud_store_load("prep")))

    @pyqtSlot(str)
    def prep(self, payload):
        import json as _json, threading
        try:
            d = _json.loads(payload)
        except Exception:
            d = {}

        def worker():
            try:
                from actions import prep as _p
                res = _p.coffee_prep(linkedin_url=d.get("url", ""), context=d.get("context", ""))
            except Exception as e:
                res = {"error": str(e)}
            self.prepReady.emit(_json.dumps(res))
            if not res.get("error"):
                import time as _t
                item = {"id": str(int(_t.time() * 1000)), "ts": int(_t.time()),
                        "title": res.get("name") or "Prep",
                        "data": {"url": d.get("url", ""), "context": d.get("context", ""), "name": res.get("name", ""),
                                 "snapshot": res.get("snapshot", ""), "commonalities": res.get("commonalities", []),
                                 "questions": res.get("questions", []), "talking_points": res.get("talking_points", []),
                                 "watchouts": res.get("watchouts", []), "read_profile": res.get("read_profile", False)}}
                _hud_store_add("prep", item)
                self.historyReady.emit(_json.dumps(_hud_store_load("prep")))

        threading.Thread(target=worker, daemon=True).start()


_PREP_HTML = r"""<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>__CSS__
.wrap{max-width:720px}
.field{margin-top:14px}
label{display:block;font-size:12px;color:var(--muted);margin:0 0 6px 2px;font-weight:500}
input{width:100%}
.go{width:100%;margin-top:16px;padding:13px;border-radius:11px;font-size:14px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px 18px;margin-top:14px}
.eyebrow{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;margin-bottom:10px}
.snap{font-size:14px;line-height:1.6;color:#e3e2df}
.tag{font-size:11px;font-weight:600;color:var(--good);background:rgba(74,222,128,.12);padding:2px 9px;border-radius:20px;display:inline-block;margin-bottom:10px}
.tag.warn{color:var(--amber);background:rgba(251,191,36,.12)}
ul{margin:0;padding:0;list-style:none}
li{font-size:13.5px;line-height:1.5;color:#dededa;padding:7px 0 7px 20px;position:relative;border-top:1px solid rgba(255,255,255,.04)}
li:first-child{border-top:none}
li:before{content:"";position:absolute;left:4px;top:14px;width:5px;height:5px;border-radius:50%;background:var(--accent)}
.q li:before{background:var(--good)}
.w li:before{background:var(--amber)}
</style></head><body>
<div class="wrap">
<div class="h1">Coffee chat prep</div>
<div class="sub">Paste who you're meeting. OB reads their profile and preps you: who they are, your common ground, and what to ask.</div>
<div class="field"><label>LinkedIn URL</label><input id="url" placeholder="https://www.linkedin.com/in/..."></div>
<div class="field"><label>What's the call for? <span style="color:#5f5f5b">(optional)</span></label><input id="context" placeholder="e.g. recruiting advice, learning about their group"></div>
<button class="btn go" id="go" onclick="run()">Prep me</button>
<div id="out"></div>
<div class="eyebrow" style="margin-top:30px">Recent</div>
<div id="hist"></div>
</div>
<script>
function esc(x){return (x||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function listCard(title,items,cls){if(!items||!items.length)return '';var h='<div class="card"><div class="eyebrow">'+title+'</div><ul class="'+(cls||'')+'">';items.forEach(function(i){h+='<li>'+esc(i)+'</li>'});return h+'</ul></div>'}
function run(){
 var go=document.getElementById('go');go.disabled=true;go.innerHTML='<span class="spinner"></span> Reading their profile...';
 ['url','context'].forEach(function(id){var e=document.getElementById(id);if(e)e.disabled=true;});
 document.getElementById('out').innerHTML='<div class="card"><div class="eyebrow"><span class="spinner"></span> Working</div><div class="snap">Reading their LinkedIn and building your prep. This can take a few seconds.</div></div>';
 window.bridge.prep(JSON.stringify({url:document.getElementById('url').value.trim(),context:document.getElementById('context').value.trim()}));
}
function onPrep(s){
 var go=document.getElementById('go');go.disabled=false;go.textContent='Prep me';
 ['url','context'].forEach(function(id){var e=document.getElementById(id);if(e)e.disabled=false;});
 var d={};try{d=JSON.parse(s)}catch(e){}
 if(d.error){document.getElementById('out').innerHTML='<div class="card"><span class="tag warn">Error</span><div class="snap">'+esc(d.error)+'</div></div>';return}
 var h='';
 var tag=d.read_profile?'<span class="tag">Read from LinkedIn</span>':'<span class="tag warn">From web search</span>';
 if(d.snapshot)h+='<div class="card"><div class="eyebrow">Snapshot</div>'+tag+'<div class="snap">'+esc(d.snapshot)+'</div></div>';
 h+=listCard('Common ground',d.commonalities,'');
 h+=listCard('Questions to ask',d.questions,'q');
 h+=listCard('Talking points',d.talking_points,'');
 h+=listCard('Watch-outs',d.watchouts,'w');
 document.getElementById('out').innerHTML=h;
}
function fmtD(ts){try{return new Date(ts*1000).toLocaleDateString(undefined,{month:'short',day:'numeric'})}catch(e){return ''}}
var HIST=[];
function renderHistory(s){try{HIST=JSON.parse(s)}catch(e){HIST=[]}var h='';if(!HIST.length){h='<div style="color:var(--muted);font-size:13px">Nothing saved yet.</div>'}HIST.forEach(function(it,ix){h+='<div class="hist-item" onclick="loadItem('+ix+')"><div class="t">'+esc((it.title||'Prep').slice(0,70))+'</div><div class="d">'+fmtD(it.ts)+'</div></div>'});document.getElementById('hist').innerHTML=h}
function loadItem(ix){var it=HIST[ix];if(!it)return;var d=it.data||{};document.getElementById('url').value=d.url||'';document.getElementById('context').value=d.context||'';onPrep(JSON.stringify(d))}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.prepReady.connect(onPrep);bridge.historyReady.connect(renderHistory);bridge.getHistory()});
</script></body></html>"""
_PREP_HTML = _PREP_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)


class _CrmBridge(QObject):
    contactsReady = pyqtSignal(str)
    followupReady = pyqtSignal(str)
    exitRequested = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    @pyqtSlot()
    def getContacts(self):
        import json as _json
        self.contactsReady.emit(_json.dumps(_hud_store_load("crm")))

    @pyqtSlot(str)
    def saveContact(self, payload):
        import json as _json, time as _t
        try:
            c = _json.loads(payload)
        except Exception:
            return
        if not c.get("id"):
            c["id"] = str(int(_t.time() * 1000))
        items = _hud_store_load("crm"); found = False
        for i, it in enumerate(items):
            if it.get("id") == c["id"]:
                items[i] = c; found = True; break
        if not found:
            items.insert(0, c)
        _hud_store_save("crm", items)
        self.contactsReady.emit(_json.dumps(items))

    @pyqtSlot(str)
    def deleteContact(self, cid):
        import json as _json
        items = [it for it in _hud_store_load("crm") if it.get("id") != cid]
        _hud_store_save("crm", items)
        self.contactsReady.emit(_json.dumps(items))

    @pyqtSlot(str)
    def draftFollowup(self, payload):
        import json as _json, threading
        try:
            d = _json.loads(payload)
        except Exception:
            d = {}

        def worker():
            try:
                from actions import outreach as _oa
                r = _oa.draft_followup(name=d.get("name", ""), firm=d.get("firm", ""),
                                       role=d.get("role", ""), notes=d.get("notes", ""))
                r["id"] = d.get("id", "")
            except Exception as e:
                r = {"id": d.get("id", ""), "error": str(e)}
            self.followupReady.emit(_json.dumps(r))

        threading.Thread(target=worker, daemon=True).start()

    @pyqtSlot(str)
    def openComposer(self, payload):
        import json as _json, threading
        try:
            d = _json.loads(payload)
        except Exception:
            return

        def worker():
            try:
                from actions.draft_email import draft_email as de
                de(parameters={"to": d.get("email", ""), "subject": d.get("subject", ""), "body": d.get("body", "")})
            except Exception as e:
                print("[crm] composer", e)

        threading.Thread(target=worker, daemon=True).start()

    @pyqtSlot(str)
    def copyText(self, text):
        try:
            QApplication.clipboard().setText(text)
        except Exception:
            pass


_CRM_HTML = r'''<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>__CSS__
.wrap{max-width:780px}
.topbar{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}
.addbtn{width:auto;flex:0 0 auto;padding:10px 16px;margin-top:4px}
.stats{display:flex;gap:10px;margin-top:18px}
.stat{flex:1;background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:13px 16px}
.stat .n{font-size:22px;font-weight:700;letter-spacing:-.02em}
.stat .l{font-size:11px;color:var(--muted);margin-top:1px;text-transform:uppercase;letter-spacing:.08em}
.stat.amber .n{color:var(--amber)}.stat.green .n{color:var(--good)}
.card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:18px;margin-top:14px}
.card .fh{font-size:14px;font-weight:600;margin-bottom:14px}
.frow{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}.frow.one{grid-template-columns:1fr}
label{display:block;font-size:11px;color:var(--muted);margin:0 0 5px 2px;font-weight:500}
select{width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:9px;color:var(--text);padding:10px 12px;font-size:13px;font-family:inherit;outline:none}
input:focus,textarea:focus,select:focus{border-color:var(--accent)}
.formbtns{display:flex;gap:8px;margin-top:4px}
.sec-h{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;margin:26px 0 10px 2px}
.ccard{display:flex;gap:13px;align-items:flex-start;background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:15px 16px;margin-bottom:10px;transition:border-color .15s}
.ccard:hover{border-color:#3a3a42}
.ccard.due{border-left:3px solid var(--amber);padding-left:14px}
.av{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:600;color:#fff;flex:0 0 auto}
.cbody{flex:1;min-width:0}
.crow{display:flex;align-items:center;gap:10px}
.cname{font-size:15px;font-weight:600}
.spill{font-size:11px;font-weight:600;padding:2px 10px;border-radius:20px;margin-left:auto;white-space:nowrap}
.s0{color:var(--muted);background:rgba(146,146,142,.15)}.s1{color:#7fb0ee;background:rgba(47,107,255,.14)}.s2{color:var(--good);background:rgba(74,222,128,.14)}
.cmeta{font-size:13px;color:var(--muted);margin-top:2px}
.chips{display:flex;gap:7px;margin-top:9px;flex-wrap:wrap}
.chip{font-size:11px;font-weight:500;padding:3px 9px;border-radius:7px;background:var(--surface2);color:var(--muted)}
.chip.due{background:rgba(251,191,36,.14);color:var(--amber);font-weight:600}
.cnotes{font-size:13px;color:#cfcfca;margin-top:9px;line-height:1.45}
.cact{display:flex;gap:6px;margin-top:12px;align-items:center;flex-wrap:wrap}
.cact a{color:var(--accent);font-size:12px;text-decoration:none;margin-right:4px}
.mini{background:transparent;border:1px solid var(--border);color:#cfcfca;border-radius:8px;padding:6px 11px;font-size:12px;cursor:pointer;font-family:inherit}
.mini:hover{border-color:var(--accent);color:var(--text)}.mini.danger:hover{border-color:#7a3030;color:var(--red)}
.fup{background:var(--surface2);border:1px solid var(--border);border-radius:10px;padding:13px;margin-top:11px}
.fup .fs{font-size:13px;font-weight:600;color:#cfe0ff}.fup .fb{font-size:13px;white-space:pre-wrap;line-height:1.55;margin-top:6px;color:#dededa}
.empty{color:var(--muted);font-size:13px;margin-top:22px;text-align:center;padding:34px 20px;border:1px dashed var(--border);border-radius:14px}
</style></head><body>
<div class="wrap">
<div class="topbar"><div><div class="h1">Networking</div><div class="sub">Track who you have reached out to and never drop a follow-up.</div></div><button class="btn addbtn" onclick="showForm()">+ Add</button></div>
<div class="stats" id="stats"></div>
<div id="formCard" class="card hidden">
 <div class="fh" id="formTitle">New contact</div>
 <div class="frow"><div><label>Name</label><input id="f_name"></div><div><label>Firm</label><input id="f_firm"></div></div>
 <div class="frow"><div><label>Role</label><input id="f_role"></div><div><label>Status</label><select id="f_status"></select></div></div>
 <div class="frow"><div><label>LinkedIn URL</label><input id="f_url"></div><div><label>Email</label><input id="f_email"></div></div>
 <div class="frow"><div><label>Last contacted</label><input id="f_last" type="date"></div><div><label>Next follow-up</label><input id="f_next" type="date"></div></div>
 <div class="frow one"><div><label>Notes</label><textarea id="f_notes" style="min-height:60px"></textarea></div></div>
 <div class="formbtns"><button class="btn" onclick="saveForm()">Save contact</button><button class="mini" onclick="hideForm()">Cancel</button></div>
</div>
<div id="dueSection"></div>
<div id="list"></div>
</div>
<script>
var STATUSES=["To contact","Reached out","Replied","Call set","Closed"];
var PALETTE=["#2f6bff","#8b5cf6","#ec4899","#f59e0b","#10b981","#06b6d4","#ef4444","#84cc16"];
var CONTACTS=[],EDITID=null,FUP={};
function statusClass(s){return (s==="Replied"||s==="Call set")?"s2":(s==="Reached out")?"s1":"s0"}
function today(){return new Date().toISOString().slice(0,10)}
function val(id){return document.getElementById(id).value.trim()}
function esc(x){return (x||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function isDue(c){return c.next&&c.next<=today()&&c.status!=="Replied"&&c.status!=="Closed"}
function initials(n){n=(n||"").trim();if(!n)return "?";var p=n.split(/\s+/);return ((p[0][0]||"")+(p.length>1?(p[p.length-1][0]||""):"")).toUpperCase()}
function avColor(n){var s=0;n=n||"";for(var i=0;i<n.length;i++)s+=n.charCodeAt(i);return PALETTE[s%PALETTE.length]}
function fillSel(){document.getElementById("f_status").innerHTML=STATUSES.map(function(s){return "<option>"+s+"</option>"}).join("")}
function showForm(c){EDITID=(c&&c.id)||null;fillSel();
 document.getElementById("formTitle").textContent=EDITID?"Edit contact":"New contact";
 document.getElementById("f_name").value=(c&&c.name)||"";document.getElementById("f_firm").value=(c&&c.firm)||"";
 document.getElementById("f_role").value=(c&&c.role)||"";document.getElementById("f_status").value=(c&&c.status)||"To contact";
 document.getElementById("f_url").value=(c&&c.url)||"";document.getElementById("f_email").value=(c&&c.email)||"";
 document.getElementById("f_last").value=(c&&c.last)||"";document.getElementById("f_next").value=(c&&c.next)||"";
 document.getElementById("f_notes").value=(c&&c.notes)||"";
 document.getElementById("formCard").classList.remove("hidden");}
function hideForm(){document.getElementById("formCard").classList.add("hidden");EDITID=null}
function saveForm(){var c={id:EDITID,name:val("f_name"),firm:val("f_firm"),role:val("f_role"),status:val("f_status"),url:val("f_url"),email:val("f_email"),last:val("f_last"),next:val("f_next"),notes:val("f_notes")};
 if(!c.name)return;
 if(c.status==="Reached out"&&!c.next){var d=new Date();d.setDate(d.getDate()+7);c.next=d.toISOString().slice(0,10)}
 window.bridge.saveContact(JSON.stringify(c));hideForm()}
function onContacts(s){try{CONTACTS=JSON.parse(s)}catch(e){CONTACTS=[]}render()}
function card(c){var due=isDue(c);var meta=[c.role,c.firm].filter(Boolean).join("  \u00b7  ");
 var h='<div class="ccard'+(due?" due":"")+'"><div class="av" style="background:'+avColor(c.name)+'">'+esc(initials(c.name))+'</div><div class="cbody">';
 h+='<div class="crow"><span class="cname">'+esc(c.name)+'</span><span class="spill '+statusClass(c.status)+'">'+esc(c.status||"")+'</span></div>';
 if(meta)h+='<div class="cmeta">'+esc(meta)+'</div>';
 var chips="";if(due)chips+='<span class="chip due">Follow up due</span>';else if(c.next)chips+='<span class="chip">Next '+c.next+'</span>';if(c.last)chips+='<span class="chip">Last contact '+c.last+'</span>';
 if(chips)h+='<div class="chips">'+chips+'</div>';
 if(c.notes)h+='<div class="cnotes">'+esc(c.notes)+'</div>';
 h+='<div class="cact">';
 if(c.url)h+='<a href="'+esc(c.url)+'" target="_blank">LinkedIn</a>';
 h+='<button class="mini" onclick="editC(\''+c.id+'\')">Edit</button><button class="mini" onclick="fup(\''+c.id+'\')">Draft follow-up</button><button class="mini danger" onclick="delC(\''+c.id+'\')">Delete</button></div>';
 h+='<div id="fup_'+c.id+'"></div></div></div>';return h}
function render(){
 var total=CONTACTS.length,due=CONTACTS.filter(isDue),rest=CONTACTS.filter(function(c){return !isDue(c)});
 var replied=CONTACTS.filter(function(c){return c.status==="Replied"||c.status==="Call set"}).length;
 document.getElementById("stats").innerHTML='<div class="stat"><div class="n">'+total+'</div><div class="l">Contacts</div></div><div class="stat amber"><div class="n">'+due.length+'</div><div class="l">Due</div></div><div class="stat green"><div class="n">'+replied+'</div><div class="l">Replied</div></div>';
 document.getElementById("dueSection").innerHTML=due.length?('<div class="sec-h">Follow up due</div>'+due.map(card).join("")):"";
 var rs;if(total){rs=(due.length?'<div class="sec-h">Everyone else</div>':'<div class="sec-h">All contacts</div>')+rest.map(card).join("")}else{rs='<div class="empty">No contacts yet. Add someone you reached out to and OB keeps your follow-ups on track.</div>'}
 document.getElementById("list").innerHTML=rs}
function editC(id){var c=CONTACTS.find(function(x){return x.id===id});if(c){showForm(c);document.getElementById("formCard").scrollIntoView({behavior:"smooth",block:"nearest"})}}
function delC(id){window.bridge.deleteContact(id)}
function fup(id){var el=document.getElementById("fup_"+id);if(el)el.innerHTML='<div class="fup"><span class="spinner"></span> Drafting follow-up...</div>';var c=CONTACTS.find(function(x){return x.id===id})||{};window.bridge.draftFollowup(JSON.stringify({id:id,name:c.name,firm:c.firm,role:c.role,notes:c.notes}))}
function onFollowup(s){var d={};try{d=JSON.parse(s)}catch(e){return}var el=document.getElementById("fup_"+d.id);if(!el)return;
 if(d.error){el.innerHTML='<div class="fup" style="color:var(--red)">'+esc(d.error)+'</div>';return}
 FUP[d.id]=d;
 el.innerHTML='<div class="fup"><div class="fs">Subject: '+esc(d.subject)+'</div><div class="fb">'+esc(d.body)+'</div><div class="cact"><button class="mini" onclick="openFup(\''+d.id+'\')">Open in composer</button><button class="mini" onclick="copyFup(\''+d.id+'\')">Copy</button></div></div>'}
function openFup(id){var d=FUP[id];if(!d)return;var c=CONTACTS.find(function(x){return x.id===id})||{};window.bridge.openComposer(JSON.stringify({email:c.email||"",subject:d.subject,body:d.body}))}
function copyFup(id){var d=FUP[id];if(!d)return;window.bridge.copyText("Subject: "+d.subject+"\n\n"+d.body)}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.contactsReady.connect(onContacts);bridge.followupReady.connect(onFollowup);bridge.getContacts()});
</script></body></html>
'''
_CRM_HTML = _CRM_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)


class _TeardownBridge(QObject):
    teardownReady = pyqtSignal(str)
    historyReady = pyqtSignal(str)
    exitRequested = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    @pyqtSlot()
    def getHistory(self):
        import json as _json
        self.historyReady.emit(_json.dumps(_hud_store_load("teardown")))

    @pyqtSlot(str)
    def run(self, ticker):
        import json as _json, threading

        def worker():
            try:
                from actions import teardown as _td
                res = _td.company_teardown(ticker)
            except Exception as e:
                res = {"error": str(e)}
            self.teardownReady.emit(_json.dumps(res))
            if not res.get("error"):
                import time as _t
                item = {"id": str(int(_t.time() * 1000)), "ts": int(_t.time()),
                        "title": (res.get("ticker") or "") + "  " + (res.get("name") or ""), "data": res}
                _hud_store_add("teardown", item)
                self.historyReady.emit(_json.dumps(_hud_store_load("teardown")))

        threading.Thread(target=worker, daemon=True).start()


_TEARDOWN_HTML = r'''<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>__CSS__
.wrap{max-width:780px}
.searchrow{display:flex;gap:10px;margin-top:18px}
.searchrow input{flex:1;text-transform:uppercase}
.searchrow .btn{width:auto;flex:0 0 auto;padding:12px 22px}
.head{display:flex;align-items:baseline;gap:10px}
.cname{font-size:20px;font-weight:700;letter-spacing:-.02em}
.tk{font-size:13px;color:var(--muted);font-family:ui-monospace,Menlo,monospace}
.links{display:flex;gap:8px;margin-top:8px;flex-wrap:wrap}
.flink{font-size:11px;color:var(--accent);text-decoration:none;border:1px solid var(--border);border-radius:7px;padding:4px 10px}
.flink:hover{border-color:var(--accent)}
.card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px 18px;margin-top:12px}
.card.edge{border-color:rgba(47,107,255,.4);background:rgba(47,107,255,.05)}
.eyebrow{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;margin-bottom:10px}
.card.edge .eyebrow{color:#7fb0ee}
.snap{font-size:14px;line-height:1.6;color:#e3e2df}
.biz{font-size:13.5px;line-height:1.6;color:#dededa}
ul{margin:0;padding:0;list-style:none}
li{font-size:13.5px;line-height:1.5;color:#dededa;padding:7px 0 7px 18px;position:relative;border-top:1px solid rgba(255,255,255,.04)}
li:first-child{border-top:none}
li:before{content:"";position:absolute;left:3px;top:14px;width:5px;height:5px;border-radius:50%;background:var(--accent)}
.fin li:before{background:var(--good)}.edge li:before{background:var(--accent)}.quality li:before{background:var(--amber)}.risk li:before{background:var(--red)}.bear li:before{background:var(--red)}.val li:before{background:var(--amber)}
.mt{width:100%;border-collapse:collapse;font-size:13px}
.mt th{color:var(--muted);font-weight:600;text-align:right;padding:6px 8px;font-size:12px}
.mt th:first-child{text-align:left}
.mt td{text-align:right;padding:8px;border-top:1px solid rgba(255,255,255,.05);color:#e3e2df;font-variant-numeric:tabular-nums}
.mt td.ml{text-align:left;color:var(--muted)}
</style></head><body>
<div class="wrap">
<div class="h1">Company teardown</div>
<div class="sub">Ticker in, deep memo out: real SEC financials plus the non-obvious read most investors skip.</div>
<div class="searchrow"><input id="tk" placeholder="Ticker, e.g. NVDA" onkeydown="if(event.key==='Enter')run()"><button class="btn" onclick="run()">Run teardown</button></div>
<div id="out"></div>
<div class="eyebrow" style="margin-top:30px">Recent</div>
<div id="hist"></div>
</div>
<script>
var HIST=[];
function esc(x){return (x||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function fmtD(ts){try{return new Date(ts*1000).toLocaleDateString(undefined,{month:"short",day:"numeric"})}catch(e){return ""}}
function listCard(title,items,cls){if(!items||!items.length)return "";var ec=(cls==="edge")?" edge":"";var h='<div class="card'+ec+'"><div class="eyebrow">'+title+'</div><ul class="'+(cls||"")+'">';items.forEach(function(i){h+="<li>"+esc(i)+"</li>"});return h+"</ul></div>"}
function metricsTable(m){if(!m||!m.years||!m.years.length)return "";
 var h='<div class="card"><div class="eyebrow">Key figures (from SEC filings)</div><table class="mt"><thead><tr><th></th>';
 m.years.forEach(function(y){h+='<th>'+y+'</th>'});h+='</tr></thead><tbody>';
 m.rows.forEach(function(r){h+='<tr><td class="ml">'+esc(r.label)+'</td>';r.vals.forEach(function(v){h+='<td>'+esc(v)+'</td>'});h+='</tr>'});
 return h+'</tbody></table></div>'}
function prose(title,txt){if(!txt)return "";return '<div class="card"><div class="eyebrow">'+title+'</div><div class="biz">'+esc(txt)+'</div></div>'}
function render(d){
 if(d.error){return '<div class="card"><div class="snap" style="color:var(--red)">'+esc(d.error)+'</div></div>'}
 var h='<div class="card"><div class="head"><span class="cname">'+esc(d.name||"")+'</span><span class="tk">'+esc(d.ticker||"")+'</span></div>';
 var links="";if(d.tenk&&d.tenk.url)links+='<a class="flink" href="'+esc(d.tenk.url)+'" target="_blank">10-K '+esc(d.tenk.date||"")+'</a>';if(d.tenq&&d.tenq.url)links+='<a class="flink" href="'+esc(d.tenq.url)+'" target="_blank">10-Q '+esc(d.tenq.date||"")+'</a>';
 if(links)h+='<div class="links">'+links+'</div>';
 if(d.snapshot)h+='<div class="snap" style="margin-top:12px">'+esc(d.snapshot)+'</div>';
 h+='</div>';
 h+=prose("1 · Business overview",d.businessOverview);
 h+=listCard("2 · Growth drivers",d.growthDrivers,"edge");
 h+=prose("3 · Competitive advantage",d.competitiveAdvantage);
 h+=metricsTable(d.metrics);
 h+=listCard("4 · Financial quality",d.financialQuality,"fin");
 h+=listCard("5 · Risks",d.risks,"risk");
 h+=prose("6 · Valuation perspective",d.valuation);
 h+=listCard("7 · Key metrics to watch",d.keyMetrics,"val");
 return h}
function run(){var tk=document.getElementById("tk").value.trim();if(!tk)return;var b=document.querySelector(".searchrow .btn");b.disabled=true;b.innerHTML='<span class="spinner"></span> Pulling filings...';document.getElementById("tk").disabled=true;document.getElementById("out").innerHTML='<div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:16px;margin-top:14px;color:#9aa6b8;font-size:14px"><span class="spinner"></span> Pulling SEC filings and building the teardown...</div>';window.bridge.run(tk)}
function onTeardown(s){var b=document.querySelector(".searchrow .btn");b.disabled=false;b.textContent="Run teardown";document.getElementById("tk").disabled=false;var d={};try{d=JSON.parse(s)}catch(e){}document.getElementById("out").innerHTML=render(d)}
function renderHistory(s){try{HIST=JSON.parse(s)}catch(e){HIST=[]}var h="";if(!HIST.length){h='<div style="color:var(--muted);font-size:13px">Nothing saved yet.</div>'}HIST.forEach(function(it,ix){h+='<div class="hist-item" onclick="loadItem('+ix+')"><div class="t">'+esc((it.title||"Teardown").slice(0,60))+'</div><div class="d">'+fmtD(it.ts)+'</div></div>'});document.getElementById("hist").innerHTML=h}
function loadItem(ix){var it=HIST[ix];if(!it)return;document.getElementById("tk").value=(it.data&&it.data.ticker)||"";document.getElementById("out").innerHTML=render(it.data||{})}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.teardownReady.connect(onTeardown);bridge.historyReady.connect(renderHistory);bridge.getHistory()});
</script></body></html>
'''
_TEARDOWN_HTML = _TEARDOWN_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)


class _ContactsBridge(QObject):
    contactsReady = pyqtSignal(str)
    exitRequested = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    @pyqtSlot()
    def getContacts(self):
        import json as _json
        try:
            from actions.contacts_store import load_contacts
            self.contactsReady.emit(_json.dumps(load_contacts()))
        except Exception:
            self.contactsReady.emit("[]")

    @pyqtSlot(str)
    def saveContact(self, payload):
        import json as _json
        try:
            c = _json.loads(payload)
            from actions.contacts_store import add_or_update
            items = add_or_update(c)
            self.contactsReady.emit(_json.dumps(items))
        except Exception:
            self.getContacts()

    @pyqtSlot(str)
    def deleteContact(self, cid):
        import json as _json
        try:
            from actions.contacts_store import delete
            items = delete(cid)
            self.contactsReady.emit(_json.dumps(items))
        except Exception:
            self.getContacts()


_CONTACTS_HTML = r'''<!DOCTYPE html><html><head><meta charset="utf-8"><script src="qrc:///qtwebchannel/qwebchannel.js"></script><style>__CSS__
.topbar{display:flex;gap:10px;align-items:center;margin:20px 0 6px}
.search{flex:1}
.addbtn{white-space:nowrap}
.formcard{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:18px 20px;margin:14px 0 22px;display:none}
.formcard.open{display:block}
.formcard h3{font-size:15px;font-weight:600;margin-bottom:14px}
.fgrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.f{display:flex;flex-direction:column;gap:5px}
.f.full{grid-column:1 / -1}
.f label{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);font-weight:600}
.f input,.f textarea{width:100%}
.formactions{display:flex;gap:10px;margin-top:16px}
.btn.ghost{background:transparent;border:1px solid var(--border);color:var(--text)}
.count{font-size:12px;color:var(--muted);margin:2px 0 12px 2px}
.list{display:flex;flex-direction:column;gap:10px}
.cc{display:flex;gap:14px;align-items:flex-start;background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:14px 16px;transition:border-color .15s}
.cc:hover{border-color:#3a3a42}
.av{flex:0 0 auto;width:42px;height:42px;border-radius:50%;background:linear-gradient(135deg,#2f6bff,#7aa2ff);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:15px;color:#fff}
.cbody{flex:1;min-width:0}
.cname{font-size:15px;font-weight:600}
.crow2{display:flex;gap:18px;flex-wrap:wrap;margin-top:5px}
.cfield{font-size:13px;color:var(--text)}
.cfield .ic{color:var(--muted);margin-right:6px}
.cnone{font-size:13px;color:var(--muted)}
.cnotes{font-size:12px;color:var(--muted);margin-top:6px}
.chips{margin-top:8px;display:flex;gap:6px;flex-wrap:wrap}
.chip{font-size:11px;background:var(--surface2);border:1px solid var(--border);color:var(--muted);border-radius:20px;padding:2px 9px}
.cacts{flex:0 0 auto;display:flex;gap:6px;opacity:0;transition:opacity .15s}
.cc:hover .cacts{opacity:1}
.iconbtn{width:30px;height:30px;border-radius:8px;border:1px solid var(--border);background:transparent;color:var(--muted);cursor:pointer;font-size:13px}
.iconbtn.ed:hover{border-color:var(--accent);color:var(--accent)}
.iconbtn.del:hover{border-color:var(--red);color:var(--red)}
.empty{text-align:center;color:var(--muted);font-size:13px;border:1px dashed var(--border);border-radius:14px;padding:34px}
</style></head><body>
<div class="wrap">
<div class="h1">Contacts</div>
<div class="sub">Everyone OB can call, text, FaceTime, or email. Edits here apply everywhere.</div>
<div class="topbar">
  <input class="search" id="q" placeholder="Search contacts..." oninput="render()">
  <button class="btn addbtn" onclick="openAdd()">+ Add contact</button>
</div>
<div class="formcard" id="form">
  <h3 id="formTitle">Add a contact</h3>
  <input type="hidden" id="cid">
  <div class="fgrid">
    <div class="f"><label>Name</label><input id="nm" placeholder="Mike Musungu"></div>
    <div class="f"><label>Phone</label><input id="ph" placeholder="+1..."></div>
    <div class="f"><label>Email</label><input id="em" placeholder="name@email.com"></div>
    <div class="f"><label>Aliases (what you call them)</label><input id="al" placeholder="mike, musungu"></div>
    <div class="f full"><label>Notes</label><textarea id="nt" rows="2" placeholder="Optional"></textarea></div>
  </div>
  <div class="formactions"><button class="btn" onclick="save()">Save contact</button><button class="btn ghost" onclick="closeForm()">Cancel</button></div>
</div>
<div class="count" id="count"></div>
<div class="list" id="list"></div>
</div>
<script>
var C=[];
function esc(x){return (x||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function initials(n){var p=(n||"").trim().split(/\s+/);return (((p[0]||"")[0]||"?")+((p[1]||"")[0]||"")).toUpperCase()}
function openAdd(){resetForm();document.getElementById("formTitle").textContent="Add a contact";document.getElementById("form").classList.add("open");document.getElementById("nm").focus()}
function closeForm(){document.getElementById("form").classList.remove("open");resetForm()}
function resetForm(){["cid","nm","ph","em","al","nt"].forEach(function(i){document.getElementById(i).value=""})}
function save(){
  var nm=document.getElementById("nm").value.trim();if(!nm){document.getElementById("nm").focus();return}
  var al=document.getElementById("al").value.split(",").map(function(s){return s.trim()}).filter(Boolean);
  var c={id:document.getElementById("cid").value||"",name:nm,phone:document.getElementById("ph").value.trim(),email:document.getElementById("em").value.trim(),aliases:al,notes:document.getElementById("nt").value.trim()};
  window.bridge.saveContact(JSON.stringify(c));closeForm();
}
function edit(ix){var c=C[ix];if(!c)return;document.getElementById("cid").value=c.id||"";document.getElementById("nm").value=c.name||"";document.getElementById("ph").value=c.phone||"";document.getElementById("em").value=c.email||"";document.getElementById("al").value=(c.aliases||[]).join(", ");document.getElementById("nt").value=c.notes||"";document.getElementById("formTitle").textContent="Edit contact";document.getElementById("form").classList.add("open");window.scrollTo(0,0)}
function del(ix){var c=C[ix];if(!c)return;if(window.confirm("Delete "+(c.name||"this contact")+"?"))window.bridge.deleteContact(c.id||"")}
function render(){
  var q=(document.getElementById("q").value||"").toLowerCase();
  var rows=C.map(function(c,ix){return {c:c,ix:ix}}).filter(function(o){if(!q)return true;var c=o.c;var hay=((c.name||"")+" "+(c.phone||"")+" "+(c.email||"")+" "+((c.aliases||[]).join(" "))).toLowerCase();return hay.indexOf(q)>=0});
  document.getElementById("count").textContent=C.length+(C.length===1?" contact":" contacts");
  if(!rows.length){document.getElementById("list").innerHTML='<div class="empty">'+(C.length?"No matches.":"No contacts yet. Add someone and OB can reach them by name.")+'</div>';return}
  var h="";
  rows.forEach(function(o){var c=o.c,ix=o.ix;
    h+='<div class="cc"><div class="av">'+esc(initials(c.name))+'</div><div class="cbody"><div class="cname">'+esc(c.name)+'</div>';
    h+='<div class="crow2">';
    if(c.phone)h+='<span class="cfield"><span class="ic">\u260e</span>'+esc(c.phone)+'</span>';
    if(c.email)h+='<span class="cfield"><span class="ic">\u2709</span>'+esc(c.email)+'</span>';
    if(!c.phone&&!c.email)h+='<span class="cnone">no phone or email</span>';
    h+='</div>';
    if(c.notes)h+='<div class="cnotes">'+esc(c.notes)+'</div>';
    if(c.aliases&&c.aliases.length){h+='<div class="chips">';c.aliases.forEach(function(a){h+='<span class="chip">'+esc(a)+'</span>'});h+='</div>'}
    h+='</div><div class="cacts"><button class="iconbtn ed" title="Edit" onclick="edit('+ix+')">\u270e</button><button class="iconbtn del" title="Delete" onclick="del('+ix+')">\u2715</button></div></div>';
  });
  document.getElementById("list").innerHTML=h;
}
function onContacts(s){try{C=JSON.parse(s)}catch(e){C=[]}render()}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.contactsReady.connect(onContacts);bridge.getContacts()});
</script></body></html>
'''
_CONTACTS_HTML = _CONTACTS_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)


class _DiffBridge(QObject):
    diffReady = pyqtSignal(str)
    historyReady = pyqtSignal(str)
    exitRequested = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    @pyqtSlot()
    def getHistory(self):
        import json as _json
        self.historyReady.emit(_json.dumps(_hud_store_load("fdiff")))

    @pyqtSlot(str)
    def run(self, ticker):
        import json as _json, threading

        def worker():
            try:
                from actions import filing_diff as _fd
                res = _fd.filing_diff(ticker)
            except Exception as e:
                res = {"error": str(e)}
            self.diffReady.emit(_json.dumps(res))
            if not res.get("error"):
                import time as _t
                item = {"id": str(int(_t.time() * 1000)), "ts": int(_t.time()),
                        "title": (res.get("ticker") or "") + "  " + (res.get("name") or ""), "data": res}
                _hud_store_add("fdiff", item)
                self.historyReady.emit(_json.dumps(_hud_store_load("fdiff")))

        threading.Thread(target=worker, daemon=True).start()


_FDIFF_HTML = r'''<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>__CSS__
.wrap{max-width:760px}
.searchrow{display:flex;gap:10px;margin-top:18px}
.searchrow input{flex:1;text-transform:uppercase}
.searchrow .btn{width:auto;flex:0 0 auto;padding:12px 22px}
.head{display:flex;align-items:baseline;gap:10px}
.cname{font-size:20px;font-weight:700;letter-spacing:-.02em}
.tk{font-size:13px;color:var(--muted);font-family:ui-monospace,Menlo,monospace}
.links{display:flex;gap:8px;margin-top:8px;flex-wrap:wrap}
.flink{font-size:11px;color:var(--accent);text-decoration:none;border:1px solid var(--border);border-radius:7px;padding:4px 10px}
.flink:hover{border-color:var(--accent)}
.card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px 18px;margin-top:12px}
.eyebrow{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;margin-bottom:12px}
.snap{font-size:14px;line-height:1.6;color:#e3e2df}
.it{padding:10px 0;border-top:1px solid rgba(255,255,255,.05)}.it:first-child{border-top:none}
.it .t{font-size:14px;font-weight:600;display:flex;align-items:center;gap:8px}
.it .t .dot{width:7px;height:7px;border-radius:50%;flex:0 0 auto}
.it .w{font-size:13px;color:#bdbdb8;margin-top:4px;line-height:1.5;padding-left:15px}
.added .dot{background:var(--red)}.esc .dot{background:var(--amber)}.removed .dot{background:var(--muted)}
.cnt{font-size:11px;font-weight:600;color:var(--muted);margin-left:6px}
</style></head><body>
<div class="wrap">
<div class="h1">Filing diff</div>
<div class="sub">What changed in the risk factors year over year: what management newly fears, escalated, or quietly dropped.</div>
<div class="searchrow"><input id="tk" placeholder="Ticker, e.g. NVDA" onkeydown="if(event.key==='Enter')run()"><button class="btn" onclick="run()">Compare 10-Ks</button></div>
<div id="out"></div>
<div class="eyebrow" style="margin-top:30px">Recent</div>
<div id="hist"></div>
</div>
<script>
var HIST=[];
function esc(x){return (x||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function fmtD(ts){try{return new Date(ts*1000).toLocaleDateString(undefined,{month:"short",day:"numeric"})}catch(e){return ""}}
function itemsCard(title,items,cls){if(!items||!items.length)return "";var h='<div class="card '+cls+'"><div class="eyebrow">'+title+'<span class="cnt">'+items.length+'</span></div>';items.forEach(function(i){h+='<div class="it"><div class="t"><span class="dot"></span>'+esc(i.title||"")+'</div>'+(i.why?'<div class="w">'+esc(i.why)+'</div>':"")+'</div>'});return h+'</div>'}
function render(d){
 if(d.error){return '<div class="card"><div class="snap" style="color:var(--red)">'+esc(d.error)+'</div></div>'}
 var h='<div class="card"><div class="head"><span class="cname">'+esc(d.name||"")+'</span><span class="tk">'+esc(d.ticker||"")+'</span></div>';
 var links="";if(d.newer&&d.newer.url)links+='<a class="flink" href="'+esc(d.newer.url)+'" target="_blank">New 10-K '+esc(d.newer.date||"")+'</a>';if(d.older&&d.older.url)links+='<a class="flink" href="'+esc(d.older.url)+'" target="_blank">Prior 10-K '+esc(d.older.date||"")+'</a>';
 if(links)h+='<div class="links">'+links+'</div>';
 if(d.summary)h+='<div class="snap" style="margin-top:12px">'+esc(d.summary)+'</div>';
 h+='</div>';
 h+=itemsCard("Newly added risks",d.added,"added");
 h+=itemsCard("Escalated / reworded worse",d.escalated,"esc");
 h+=itemsCard("Removed risks",d.removed,"removed");
 if(!(d.added&&d.added.length)&&!(d.escalated&&d.escalated.length)&&!(d.removed&&d.removed.length))h+='<div class="card"><div class="snap" style="color:var(--muted)">No material changes detected between the two filings.</div></div>';
 return h}
function run(){var tk=document.getElementById("tk").value.trim();if(!tk)return;var b=document.querySelector(".searchrow .btn");b.disabled=true;b.innerHTML='<span class="spinner"></span> Comparing filings...';document.getElementById("out").innerHTML="";window.bridge.run(tk)}
function onDiff(s){var b=document.querySelector(".searchrow .btn");b.disabled=false;b.textContent="Compare 10-Ks";var d={};try{d=JSON.parse(s)}catch(e){}document.getElementById("out").innerHTML=render(d)}
function renderHistory(s){try{HIST=JSON.parse(s)}catch(e){HIST=[]}var h="";if(!HIST.length){h='<div style="color:var(--muted);font-size:13px">Nothing saved yet.</div>'}HIST.forEach(function(it,ix){h+='<div class="hist-item" onclick="loadItem('+ix+')"><div class="t">'+esc((it.title||"Diff").slice(0,60))+'</div><div class="d">'+fmtD(it.ts)+'</div></div>'});document.getElementById("hist").innerHTML=h}
function loadItem(ix){var it=HIST[ix];if(!it)return;document.getElementById("tk").value=(it.data&&it.data.ticker)||"";document.getElementById("out").innerHTML=render(it.data||{})}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.diffReady.connect(onDiff);bridge.historyReady.connect(renderHistory);bridge.getHistory()});
</script></body></html>
'''
_FDIFF_HTML = _FDIFF_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)


class _EarnBridge(QObject):
    briefReady = pyqtSignal(str)
    historyReady = pyqtSignal(str)
    exitRequested = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    @pyqtSlot()
    def getHistory(self):
        import json as _json
        self.historyReady.emit(_json.dumps(_hud_store_load("earnings")))

    @pyqtSlot(str)
    def run(self, ticker):
        import json as _json, threading

        def worker():
            try:
                from actions import earnings as _e
                res = _e.earnings_brief(ticker)
            except Exception as e:
                res = {"error": str(e)}
            self.briefReady.emit(_json.dumps(res))
            if not res.get("error"):
                import time as _t
                item = {"id": str(int(_t.time() * 1000)), "ts": int(_t.time()),
                        "title": (res.get("ticker") or "") + "  " + (res.get("name") or ""), "data": res}
                _hud_store_add("earnings", item)
                self.historyReady.emit(_json.dumps(_hud_store_load("earnings")))

        threading.Thread(target=worker, daemon=True).start()


_EARN_HTML = r'''<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>__CSS__
.wrap{max-width:800px}
.searchrow{display:flex;gap:10px;margin-top:18px}
.searchrow input{flex:1;text-transform:uppercase}
.searchrow .btn{width:auto;flex:0 0 auto;padding:12px 22px}
.head{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.cname{font-size:20px;font-weight:700;letter-spacing:-.02em}
.tk{font-size:13px;color:var(--muted);font-family:ui-monospace,Menlo,monospace}
.pricepill{margin-left:auto;font-size:13px;font-weight:700;color:var(--good);background:rgba(74,166,108,.12);border:1px solid rgba(74,166,108,.35);border-radius:999px;padding:5px 12px}
.pricepill.neg{color:var(--red);background:rgba(214,90,90,.12);border-color:rgba(214,90,90,.35)}
.datepill{font-size:12px;font-weight:600;color:var(--accent);background:rgba(47,107,255,.1);border:1px solid rgba(47,107,255,.35);border-radius:999px;padding:5px 12px}
.pricepill + .datepill{margin-left:8px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px 18px;margin-top:12px}
.eyebrow{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;margin-bottom:12px}
.snap{font-size:14px;line-height:1.6;color:#e3e2df}
ul{margin:0;padding:0;list-style:none}
li{font-size:13.5px;line-height:1.5;color:#dededa;padding:7px 0 7px 18px;position:relative;border-top:1px solid rgba(255,255,255,.04)}
li:first-child{border-top:none}
li:before{content:"";position:absolute;left:3px;top:14px;width:5px;height:5px;border-radius:50%;background:var(--accent)}
.last li:before{background:var(--good)}.watch li:before{background:var(--amber)}.wild li:before{background:var(--red)}
.statgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px}
.stat{background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:11px;padding:11px 13px}
.stat .l{font-size:10.5px;color:var(--muted);text-transform:uppercase;letter-spacing:.07em}
.stat .v{font-size:18px;font-weight:700;margin-top:3px;font-variant-numeric:tabular-nums}
.nprow{display:flex;gap:12px}.np{flex:1}.np .l{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.07em}.np .v{font-size:22px;font-weight:700;color:var(--accent);margin-top:3px}
.bmrow{display:flex;gap:10px;flex-wrap:wrap}
.bm{flex:1;min-width:130px;background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:11px;padding:10px 12px}
.bm .p{font-size:11px;color:var(--muted)}.bm .av{font-size:12.5px;margin-top:3px;color:#cfcfca}.bm .tag{font-size:13px;font-weight:700;margin-top:5px}
.bm.beat{border-color:rgba(74,166,108,.3)}.bm.beat .tag{color:var(--good)}
.bm.miss{border-color:rgba(214,90,90,.3)}.bm.miss .tag{color:var(--red)}
.rbar{display:flex;height:12px;border-radius:6px;overflow:hidden;background:rgba(255,255,255,.05)}
.rbar div{height:100%}
.rleg{display:flex;flex-wrap:wrap;gap:12px;margin-top:10px}
.rl{font-size:12px;color:#cfcfca;display:flex;align-items:center;gap:6px}.rl i{width:9px;height:9px;border-radius:2px;display:inline-block}
.hl{display:block;font-size:13px;line-height:1.4;color:#dcdcd8;text-decoration:none;padding:8px 0;border-top:1px solid rgba(255,255,255,.04)}
.hl:first-of-type{border-top:none}a.hl:hover{color:var(--accent)}
.mt{width:100%;border-collapse:collapse;font-size:13px}
.mt th{color:var(--muted);font-weight:600;text-align:right;padding:6px 8px;font-size:12px}
.mt th:first-child{text-align:left}
.mt td{text-align:right;padding:8px;border-top:1px solid rgba(255,255,255,.05);color:#e3e2df;font-variant-numeric:tabular-nums}
.mt td.ml{text-align:left;color:var(--muted)}
</style></head><body>
<div class="wrap">
<div class="h1">Earnings mode</div>
<div class="sub">The setup into the print: live stats, beat/miss history, ratings, and what to watch.</div>
<div class="searchrow"><input id="tk" placeholder="Ticker, e.g. NVDA" onkeydown="if(event.key==='Enter')run()"><button class="btn" onclick="run()">Earnings preview</button></div>
<div id="out"></div>
<div class="eyebrow" style="margin-top:30px">Recent</div>
<div id="hist"></div>
</div>
<script>
var HIST=[];var MO=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
function esc(x){return (x||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function fmtTs(ts){try{return new Date(ts*1000).toLocaleDateString(undefined,{month:"short",day:"numeric"})}catch(e){return ""}}
function fmtDate(s){if(!s)return "";var p=(""+s).split("-");if(p.length!=3)return s;return MO[parseInt(p[1],10)-1]+" "+parseInt(p[2],10)+", "+p[0]}
function listCard(title,items,cls){if(!items||!items.length)return "";var h='<div class="card"><div class="eyebrow">'+title+'</div><ul class="'+(cls||"")+'">';items.forEach(function(i){h+="<li>"+esc(i)+"</li>"});return h+"</ul></div>"}
function metricsTable(m){if(!m||!m.quarters||!m.quarters.length)return "";var h='<div class="card"><div class="eyebrow">Recent quarters (from filings)</div><table class="mt"><thead><tr><th></th>';m.quarters.forEach(function(q){h+='<th>'+esc(q)+'</th>'});h+='</tr></thead><tbody>';m.rows.forEach(function(r){h+='<tr><td class="ml">'+esc(r.label)+'</td>';r.vals.forEach(function(v){h+='<td>'+esc(v)+'</td>'});h+='</tr>'});return h+'</tbody></table></div>'}
function statGrid(s){if(!s||!s.length)return "";var h='<div class="card"><div class="eyebrow">Key stats</div><div class="statgrid">';s.forEach(function(x){h+='<div class="stat"><div class="l">'+esc(x.label)+'</div><div class="v">'+esc(x.value)+'</div></div>'});return h+'</div></div>'}
function nextCard(ne){if(!ne||(!ne.eps&&!ne.rev))return "";var h='<div class="card"><div class="eyebrow">Next print estimates</div><div class="nprow">';if(ne.eps)h+='<div class="np"><div class="l">EPS estimate</div><div class="v">'+esc(ne.eps)+'</div></div>';if(ne.rev)h+='<div class="np"><div class="l">Revenue estimate</div><div class="v">'+esc(ne.rev)+'</div></div>';return h+'</div></div>'}
function beatMiss(arr){if(!arr||!arr.length)return "";var rows=arr.slice().reverse();var h='<div class="card"><div class="eyebrow">EPS beat / miss history</div><div class="bmrow">';rows.forEach(function(s){var beat=s.beat>=0;h+='<div class="bm '+(beat?"beat":"miss")+'"><div class="p">'+esc(s.period)+'</div><div class="av">$'+s.actual.toFixed(2)+' vs $'+s.estimate.toFixed(2)+' est</div><div class="tag">'+(beat?"Beat +":"Miss ")+Math.abs(s.beat).toFixed(2)+'</div></div>'});return h+'</div></div>'}
function ratingsCard(r){if(!r)return "";var segs=[["strongBuy","Strong buy","#1f9e5a"],["buy","Buy","#4aa66c"],["hold","Hold","#caa24a"],["sell","Sell","#d98a3a"],["strongSell","Strong sell","#d65a5a"]];var total=0;segs.forEach(function(s){total+=r[s[0]]||0});if(!total)return "";var bar='<div class="rbar">';var leg='<div class="rleg">';segs.forEach(function(s){var n=r[s[0]]||0;if(n>0)bar+='<div style="width:'+(100*n/total)+'%;background:'+s[2]+'"></div>';leg+='<span class="rl"><i style="background:'+s[2]+'"></i>'+s[1]+' '+n+'</span>'});return '<div class="card"><div class="eyebrow">Analyst ratings'+(r.period?' ('+esc(r.period)+')':'')+'</div>'+bar+'</div>'+leg+'</div>'}
function headlinesCard(items){if(!items||!items.length)return "";var h='<div class="card"><div class="eyebrow">Recent headlines</div>';items.forEach(function(n){var t=esc(n.headline);h+=n.url?('<a class="hl" href="'+esc(n.url)+'" target="_blank">'+t+'</a>'):('<div class="hl">'+t+'</div>')});return h+'</div>'}
function render(d){
 if(d.error){return '<div class="card"><div class="snap" style="color:var(--red)">'+esc(d.error)+'</div></div>'}
 var pc=d.price?('<span class="pricepill'+(d.price.indexOf("(-")>=0?" neg":"")+'">'+esc(d.price)+'</span>'):"";
 var dp=d.nextDate?('<span class="datepill">Reports '+esc(fmtDate(d.nextDate))+'</span>'):"";
 var h='<div class="card"><div class="head"><span class="cname">'+esc(d.name||"")+'</span><span class="tk">'+esc(d.ticker||"")+'</span>'+pc+dp+'</div>';
 if(d.note)h+='<div style="margin-top:10px;font-size:12.5px;line-height:1.5;color:var(--amber);background:rgba(212,160,60,.08);border:1px solid rgba(212,160,60,.3);border-radius:10px;padding:9px 12px">'+esc(d.note)+'</div>';
 if(d.setup)h+='<div class="snap" style="margin-top:12px">'+esc(d.setup)+'</div>';
 h+='</div>';
 h+=statGrid(d.stats);
 h+=nextCard(d.nextEst);
 h+=beatMiss(d.surprises);
 h+=metricsTable(d.metrics);
 h+=ratingsCard(d.ratings);
 h+=listCard("Reading the trajectory",d.trend,"last");
 h+=listCard("Consensus expectations",d.consensus,"last");
 h+=listCard("Last quarter",d.lastQuarter,"last");
 h+=listCard("What to watch",d.watch,"watch");
 h+=listCard("Wildcards",d.wildcards,"wild");
 h+=headlinesCard(d.headlines);
 return h}
function run(){var tk=document.getElementById("tk").value.trim();if(!tk)return;var b=document.querySelector(".searchrow .btn");b.disabled=true;b.innerHTML='<span class="spinner"></span> Building preview...';document.getElementById("out").innerHTML="";window.bridge.run(tk)}
function onBrief(s){var b=document.querySelector(".searchrow .btn");b.disabled=false;b.textContent="Earnings preview";var d={};try{d=JSON.parse(s)}catch(e){}document.getElementById("out").innerHTML=render(d)}
function renderHistory(s){try{HIST=JSON.parse(s)}catch(e){HIST=[]}var h="";if(!HIST.length){h='<div style="color:var(--muted);font-size:13px">Nothing saved yet.</div>'}HIST.forEach(function(it,ix){h+='<div class="hist-item" onclick="loadItem('+ix+')"><div class="t">'+esc((it.title||"Earnings").slice(0,60))+'</div><div class="d">'+fmtTs(it.ts)+'</div></div>'});document.getElementById("hist").innerHTML=h}
function loadItem(ix){var it=HIST[ix];if(!it)return;document.getElementById("tk").value=(it.data&&it.data.ticker)||"";document.getElementById("out").innerHTML=render(it.data||{})}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.briefReady.connect(onBrief);bridge.historyReady.connect(renderHistory);bridge.getHistory()});
</script></body></html>
'''
_EARN_HTML = _EARN_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)


class _BriefBridge(QObject):
    briefReady = pyqtSignal(str)
    watchlistReady = pyqtSignal(str)
    exitRequested = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    def _wl(self):
        items = _hud_store_load("watchlist")
        return [i.get("ticker") for i in items if isinstance(i, dict) and i.get("ticker")]

    @pyqtSlot()
    def getWatchlist(self):
        import json as _json
        self.watchlistReady.emit(_json.dumps(self._wl()))

    @pyqtSlot(str)
    def addTicker(self, t):
        import json as _json
        t = (t or "").strip().upper()
        wl = self._wl()
        if t and t not in wl:
            wl.append(t)
            _hud_store_save("watchlist", [{"ticker": x} for x in wl])
        self.watchlistReady.emit(_json.dumps(self._wl()))

    @pyqtSlot(str)
    def removeTicker(self, t):
        import json as _json
        t = (t or "").strip().upper()
        wl = [x for x in self._wl() if x != t]
        _hud_store_save("watchlist", [{"ticker": x} for x in wl])
        self.watchlistReady.emit(_json.dumps(wl))

    @pyqtSlot()
    def runBrief(self):
        import json as _json, threading

        def worker():
            try:
                from actions import morning as _m
                res = _m.morning_brief(self._wl())
            except Exception as e:
                res = {"error": str(e)}
            self.briefReady.emit(_json.dumps(res))

        threading.Thread(target=worker, daemon=True).start()


_BRIEF_HTML = r'''<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>__CSS__
.wrap{max-width:800px}
.wlrow{display:flex;gap:10px;margin-top:16px}
.wlrow input{flex:1;text-transform:uppercase}
.wlrow .btn{width:auto;flex:0 0 auto;padding:12px 22px}
.runbtn{width:100%}
.chips{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
.chip{display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:999px;padding:6px 10px 6px 13px;font-size:13px;font-weight:600;font-family:ui-monospace,Menlo,monospace}
.chip .x{cursor:pointer;color:var(--muted);font-weight:700}.chip .x:hover{color:var(--red)}
.card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px 18px;margin-top:12px}
.eyebrow{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;margin-bottom:12px}
.summary{font-size:14.5px;line-height:1.65;color:#e8e7e4}
.mkt{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px}
.mi{background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:11px;padding:11px 13px}
.mi .l{font-size:11px;color:var(--muted)}.mi .v{font-size:17px;font-weight:700;margin-top:3px;font-variant-numeric:tabular-nums}
.v.up{color:var(--good)}.v.down{color:var(--red)}
.heat{display:grid;grid-template-columns:repeat(auto-fit,minmax(94px,1fr));gap:8px}
.hc{border:1px solid var(--border);border-radius:10px;padding:9px 11px}
.hc .hl3{font-size:11px;color:#e6e5e2;font-weight:600}
.hc .hp{font-size:14px;font-weight:700;margin-top:3px;font-variant-numeric:tabular-nums}
.mv{display:flex;align-items:center;gap:12px;padding:12px 0;border-top:1px solid rgba(255,255,255,.05)}
.mv:first-child{border-top:none}
.mv .t{font-weight:700;font-family:ui-monospace,Menlo,monospace;font-size:14px;flex:0 0 58px}
.mvmid{flex:1;min-width:0}
.mvmid .hl{font-size:12.5px;color:#c2c2bd;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;text-decoration:none}
a.hl:hover{color:var(--accent)}
.ep{display:inline-block;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--accent);background:rgba(47,107,255,.12);border:1px solid rgba(47,107,255,.3);border-radius:6px;padding:2px 7px;margin-top:5px}
.ep.today{color:var(--amber);background:rgba(212,160,60,.12);border-color:rgba(212,160,60,.35)}
.px{flex:0 0 auto;text-align:right}
.px .pr{font-size:12.5px;color:#cfcfca;font-variant-numeric:tabular-nums}
.px .pct{font-size:14px;font-weight:700;font-variant-numeric:tabular-nums}
.pct.up{color:var(--good)}.pct.down{color:var(--red)}
.mvc{padding:14px 0;border-top:1px solid rgba(255,255,255,.06)}
.mvc:first-child{border-top:none}
.mvtop{display:flex;align-items:baseline;justify-content:space-between}
.mvtop .t{font-weight:700;font-family:ui-monospace,Menlo,monospace;font-size:15px}
.mvtop .pr{font-size:13px;color:#cfcfca;font-variant-numeric:tabular-nums}
.mvtop .pct{font-size:15px;font-weight:700;margin-left:8px;font-variant-numeric:tabular-nums}
.stx{font-size:12px;color:var(--muted);margin-top:6px;font-variant-numeric:tabular-nums}
.mvnews{margin-top:8px}.mvnews .hl2{padding:5px 0;font-size:12.5px}
.hl2{display:block;font-size:13px;line-height:1.4;color:#dcdcd8;text-decoration:none;padding:8px 0;border-top:1px solid rgba(255,255,255,.04)}
.hl2:first-of-type{border-top:none}a.hl2:hover{color:var(--accent)}
</style></head><body>
<div class="wrap">
<div class="h1">Morning brief</div>
<div class="sub">Your watchlist, the tape, and what matters before the open, in one rundown.</div>
<div class="wlrow"><input id="tk" placeholder="Add ticker, e.g. AMD" onkeydown="if(event.key==='Enter')addT()"><button class="btn" onclick="addT()">Add</button></div>
<div id="chips" class="chips"></div>
<div class="wlrow" style="margin-top:16px"><button class="btn runbtn" onclick="run()">Run morning brief</button></div>
<div id="out"></div>
</div>
<script>
var WL=[];
function esc(x){return (x||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function pctClass(p){return (p||0)>=0?"up":"down"}
function pctStr(p){return ((p||0)>=0?"+":"")+(p==null?0:p).toFixed(2)+"%"}
function renderChips(s){try{WL=JSON.parse(s)}catch(e){WL=[]}var h="";if(!WL.length){h='<div style="color:var(--muted);font-size:13px">No tickers yet. Add a few names you track.</div>'}WL.forEach(function(t,ix){h+='<span class="chip">'+esc(t)+'<span class="x" onclick="rm('+ix+')">&times;</span></span>'});document.getElementById("chips").innerHTML=h}
function addT(){var v=document.getElementById("tk").value.trim().toUpperCase();if(!v)return;document.getElementById("tk").value="";window.bridge.addTicker(v)}
function rm(ix){if(WL[ix])window.bridge.removeTicker(WL[ix])}
function stripCard(title,m){if(!m||!m.length)return "";var h='<div class="card"><div class="eyebrow">'+title+'</div><div class="mkt">';m.forEach(function(x){h+='<div class="mi"><div class="l">'+esc(x.label)+'</div><div class="v '+pctClass(x.pct)+'">'+pctStr(x.pct)+'</div></div>'});return h+'</div></div>'}
function heatColor(p){p=p||0;var a=Math.min(Math.abs(p)/2,1)*0.42+0.07;return (p>=0?"rgba(74,166,108,":"rgba(214,90,90,")+a+")"}
function sectorCard(arr){if(!arr||!arr.length)return "";var h='<div class="card"><div class="eyebrow">Sectors</div><div class="heat">';arr.forEach(function(s){h+='<div class="hc" style="background:'+heatColor(s.pct)+'"><div class="hl3">'+esc(s.label)+'</div><div class="hp '+pctClass(s.pct)+'">'+pctStr(s.pct)+'</div></div>'});return h+'</div></div>'}
function moversCard(arr){if(!arr||!arr.length)return "";var h='<div class="card"><div class="eyebrow">Your watchlist</div>';arr.forEach(function(m){
 var ep=m.earnings?('<span class="ep'+(m.earnings.indexOf("today")>=0?" today":"")+'">'+esc(m.earnings)+'</span>'):(m.nextDate?('<span class="ep">Reports '+esc(m.nextDate)+'</span>'):"");
 var st=[];if(m.open!=null)st.push("Open "+m.open.toFixed(2));if(m.low!=null&&m.high!=null)st.push("Range "+m.low.toFixed(2)+"\u2013"+m.high.toFixed(2));if(m.prev!=null)st.push("Prev close "+m.prev.toFixed(2));
 var hls="";(m.headlines||[]).forEach(function(n){if(!n.headline)return;hls+=n.url?('<a class="hl2" href="'+esc(n.url)+'" target="_blank">'+esc(n.headline)+'</a>'):('<div class="hl2">'+esc(n.headline)+'</div>')});if(!hls)hls='<div class="hl2" style="color:var(--muted)">No recent headline</div>';
 h+='<div class="mvc"><div class="mvtop"><div class="t">'+esc(m.ticker)+'</div><div><span class="pr">$'+(m.price!=null?m.price.toFixed(2):"--")+'</span><span class="pct '+pctClass(m.pct)+'">'+pctStr(m.pct)+'</span></div></div>'+(st.length?'<div class="stx">'+esc(st.join("   \u00b7   "))+'</div>':"")+(ep?'<div style="margin:7px 0 2px">'+ep+'</div>':"")+'<div class="mvnews">'+hls+'</div></div>';
});return h+'</div>'}
function earningsCard(today,week){if((!today||!today.length)&&(!week||!week.length))return "";var h='<div class="card"><div class="eyebrow">Earnings on deck</div>';if(today&&today.length)h+='<div style="margin-bottom:8px"><span style="font-size:12px;color:var(--amber);font-weight:700">Today: </span><span style="font-size:13px;color:#e3e2df">'+today.map(esc).join(", ")+'</span></div>';if(week&&week.length)h+='<div style="font-size:13px;color:#c2c2bd">This week: '+week.map(function(w){return esc(w.ticker)+" ("+esc(w.date)+")"}).join(", ")+'</div>';return h+'</div>'}
function newsCard(items){if(!items||!items.length)return "";var h='<div class="card"><div class="eyebrow">Top market headlines</div>';items.forEach(function(n){h+=n.url?('<a class="hl2" href="'+esc(n.url)+'" target="_blank">'+esc(n.headline)+'</a>'):('<div class="hl2">'+esc(n.headline)+'</div>')});return h+'</div>'}
function render(d){
 if(d.error)return '<div class="card"><div class="summary" style="color:var(--red)">'+esc(d.error)+'</div></div>';
 if(d.empty)return '<div class="card"><div class="summary" style="color:var(--muted)">Add a few tickers above, then run the brief.</div></div>';
 var h="";
 if(d.summary)h+='<div class="card"><div class="eyebrow">This morning</div><div class="summary">'+esc(d.summary)+'</div></div>';
 h+=stripCard("Market tone",d.market);
 h+=stripCard("Macro",d.macro);
 h+=sectorCard(d.sectors);
 h+=earningsCard(d.earningsToday,d.earningsWeek);
 h+=moversCard(d.movers);
 h+=newsCard(d.topNews);
 return h}
function run(){if(!WL.length){document.getElementById("out").innerHTML=render({empty:true});return}var b=document.querySelector(".runbtn");b.disabled=true;b.innerHTML='<span class="spinner"></span> Pulling the tape...';document.getElementById("tk").disabled=true;document.getElementById("out").innerHTML='<div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:16px;margin-top:14px;color:#9aa6b8;font-size:14px"><span class="spinner"></span> Pulling live market data and headlines...</div>';window.bridge.runBrief()}
function onBrief(s){var b=document.querySelector(".runbtn");b.disabled=false;b.textContent="Run morning brief";document.getElementById("tk").disabled=false;var d={};try{d=JSON.parse(s)}catch(e){}document.getElementById("out").innerHTML=render(d)}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.briefReady.connect(onBrief);bridge.watchlistReady.connect(renderChips);bridge.getWatchlist()});
</script></body></html>
'''
_BRIEF_HTML = _BRIEF_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)


class _StudyBridge(QObject):
    resultReady = pyqtSignal(str)
    answerReady = pyqtSignal(str)
    historyReady = pyqtSignal(str)
    exitRequested = pyqtSignal()

    def __init__(self):
        super().__init__()
        self._src = ""

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    @pyqtSlot()
    def getHistory(self):
        import json as _json
        self.historyReady.emit(_json.dumps(_hud_store_load("study")))

    def _run(self, value):
        import json as _json, threading

        def worker():
            try:
                from actions import study as _s
                res = _s.summarize_source(value)
            except Exception as e:
                res = {"error": str(e)}
            if not res.get("error"):
                import time as _t
                self._src = res.get("_source", "")
                item = {"id": str(int(_t.time() * 1000)), "ts": int(_t.time()),
                        "title": res.get("title", "Notes"), "data": res}
                _hud_store_add("study", item)
            self.resultReady.emit(_json.dumps(res))
            self.historyReady.emit(_json.dumps(_hud_store_load("study")))

        threading.Thread(target=worker, daemon=True).start()

    @pyqtSlot(str)
    def ingest(self, value):
        self._run(value)

    @pyqtSlot()
    def pickPdf(self):
        path = ""
        try:
            from PyQt6.QtWidgets import QFileDialog
            path, _ = QFileDialog.getOpenFileName(None, "Choose a PDF", "", "PDF files (*.pdf)")
        except Exception:
            path = ""
        if path:
            self._run(path)

    @pyqtSlot(int)
    def pickHistory(self, idx):
        import json as _json
        items = _hud_store_load("study")
        if 0 <= idx < len(items):
            d = items[idx].get("data", {})
            self._src = d.get("_source", "")
            self.resultReady.emit(_json.dumps(d))

    @pyqtSlot(str)
    def ask(self, q):
        import json as _json, threading

        def worker():
            try:
                from actions import study as _s
                res = _s.ask_source(self._src, q)
            except Exception as e:
                res = {"error": str(e)}
            self.answerReady.emit(_json.dumps(res))

        threading.Thread(target=worker, daemon=True).start()


_STUDY_HTML = r'''<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>__CSS__
.wrap{max-width:780px}
textarea{width:100%;background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:12px 14px;color:#e8e7e4;font-size:14px;font-family:inherit;resize:vertical;min-height:80px;box-sizing:border-box}
textarea:focus{outline:none;border-color:var(--accent)}
.btnrow{display:flex;gap:10px;margin-top:12px}
.btn.ghost{background:transparent;border:1px solid var(--border);color:#dcdcd8}
.btn.ghost:hover{border-color:var(--accent)}
.spacer{flex:1}
.card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px 18px;margin-top:12px}
.eyebrow{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:600;margin-bottom:10px}
.title{font-size:21px;font-weight:700;letter-spacing:-.02em}
.kind{font-size:12px;color:var(--muted);margin-top:3px}
.summary{font-size:14.5px;line-height:1.65;color:#e8e7e4}
.prose{font-size:14px;line-height:1.72;color:#e0dfdc;margin:0 0 13px}
.prose:last-child{margin-bottom:0}
ul{margin:0;padding:0;list-style:none}
li{font-size:13.5px;line-height:1.55;color:#dededa;padding:7px 0 7px 18px;position:relative;border-top:1px solid rgba(255,255,255,.04)}
li:first-child{border-top:none}
li:before{content:"";position:absolute;left:3px;top:14px;width:5px;height:5px;border-radius:50%;background:var(--accent)}
.take li:before{background:var(--good)}.q li:before{background:var(--amber)}
.cpt{padding:9px 0;border-top:1px solid rgba(255,255,255,.04)}.cpt:first-child{border-top:none}
.cpt .term{font-size:13.5px;font-weight:700;color:#fff}
.cpt .def{font-size:13px;color:#c2c2bd;line-height:1.5;margin-top:2px}
.askrow{display:flex;gap:10px;margin-top:10px}
.askrow input{flex:1}.askrow .btn{width:auto;flex:0 0 auto;padding:11px 18px}
.qa{margin-top:12px}
.qa .qq{font-size:13.5px;font-weight:600;color:#fff;margin-top:12px}
.qa .aa{font-size:13.5px;line-height:1.6;color:#dededa;margin-top:5px;white-space:pre-wrap}
</style></head><body>
<div class="wrap">
<div class="h1">Study</div>
<div class="sub">Drop a YouTube link, article URL, PDF, or text. Get notes, key concepts, takeaways, and grounded answers.</div>
<textarea id="src" placeholder="Paste a YouTube/article link or any text..."></textarea>
<div class="btnrow"><button class="btn ghost" onclick="pickPdf()">Choose PDF</button><span class="spacer"></span><button class="btn" id="sumbtn" onclick="go()">Summarize</button></div>
<div id="out"></div>
<div class="eyebrow" style="margin-top:30px">Recent</div>
<div id="hist"></div>
</div>
<script>
var HIST=[];
function esc(x){return (x||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function fmtTs(ts){try{return new Date(ts*1000).toLocaleDateString(undefined,{month:"short",day:"numeric"})}catch(e){return ""}}
function listCard(title,items,cls){if(!items||!items.length)return "";var h='<div class="card"><div class="eyebrow">'+title+'</div><ul class="'+(cls||"")+'">';items.forEach(function(i){h+="<li>"+esc(i)+"</li>"});return h+"</ul></div>"}
function conceptCard(arr){if(!arr||!arr.length)return "";var h='<div class="card"><div class="eyebrow">Key concepts</div>';arr.forEach(function(c){h+='<div class="cpt"><div class="term">'+esc(c.term)+'</div>'+(c.definition?'<div class="def">'+esc(c.definition)+'</div>':"")+'</div>'});return h+'</div>'}
function proseCard(title,text){if(!text)return "";var ps=text.split(/\n\s*\n/);var h='<div class="card"><div class="eyebrow">'+title+'</div>';ps.forEach(function(p){if(p.trim())h+='<p class="prose">'+esc(p.trim())+'</p>'});return h+'</div>'}
function render(d){
 if(d.error){return '<div class="card"><div class="summary" style="color:var(--red)">'+esc(d.error)+'</div></div>'}
 var h='<div class="card"><div class="title">'+esc(d.title||"")+'</div><div class="kind">'+esc(d.kind||"")+'</div>';
 if(d.summary)h+='<div class="summary" style="margin-top:12px">'+esc(d.summary)+'</div>';
 h+='</div>';
 h+=proseCard("In depth",d.deepDive);
 h+=listCard("Key points",d.keyPoints);
 h+=conceptCard(d.concepts);
 h+=listCard("Takeaways & action items",d.takeaways,"take");
 h+=listCard("Study questions",d.questions,"q");
 h+='<div class="card"><div class="eyebrow">Ask about this source</div><div class="askrow"><input id="q" placeholder="Ask a question..." onkeydown="if(event.key===\'Enter\')askQ()"><button class="btn" onclick="askQ()">Ask</button></div><div id="answers" class="qa"></div></div>';
 return h}
function go(){var v=document.getElementById("src").value.trim();if(!v)return;var b=document.getElementById("sumbtn");b.disabled=true;b.innerHTML='<span class="spinner"></span> Reading...';document.getElementById("out").innerHTML="";window.bridge.ingest(v)}
function pickPdf(){window.bridge.pickPdf()}
function onResult(s){var b=document.getElementById("sumbtn");b.disabled=false;b.textContent="Summarize";var d={};try{d=JSON.parse(s)}catch(e){}document.getElementById("out").innerHTML=render(d)}
function askQ(){var qi=document.getElementById("q");if(!qi)return;var q=qi.value.trim();if(!q)return;qi.value="";var ans=document.getElementById("answers");ans.innerHTML+='<div class="qq">'+esc(q)+'</div><div class="aa" id="pending"><span class="spinner"></span></div>';window.bridge.ask(q)}
function onAnswer(s){var d={};try{d=JSON.parse(s)}catch(e){}var p=document.getElementById("pending");if(p){p.id="";p.textContent=d.answer||d.error||""}}
function renderHistory(s){try{HIST=JSON.parse(s)}catch(e){HIST=[]}var h="";if(!HIST.length){h='<div style="color:var(--muted);font-size:13px">Nothing saved yet.</div>'}HIST.forEach(function(it,ix){h+='<div class="hist-item" onclick="loadItem('+ix+')"><div class="t">'+esc((it.title||"Notes").slice(0,70))+'</div><div class="d">'+fmtTs(it.ts)+'</div></div>'});document.getElementById("hist").innerHTML=h}
function loadItem(ix){window.bridge.pickHistory(ix)}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.resultReady.connect(onResult);bridge.answerReady.connect(onAnswer);bridge.historyReady.connect(renderHistory);bridge.getHistory()});
</script></body></html>
'''
_STUDY_HTML = _STUDY_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)


def _new_id():
    import uuid
    return uuid.uuid4().hex[:12]


class _InternBridge(QObject):
    internsReady = pyqtSignal(str)
    checkinReady = pyqtSignal(str)
    exitRequested = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    def _load(self):
        return _hud_store_load("interns")

    def _emit(self, items):
        import json as _json
        _hud_store_save("interns", items)
        self.internsReady.emit(_json.dumps(items))

    @pyqtSlot()
    def getInterns(self):
        import json as _json
        self.internsReady.emit(_json.dumps(self._load()))

    @pyqtSlot(str)
    def saveIntern(self, payload):
        import json as _json
        d = _json.loads(payload)
        items = self._load()
        iid = d.get("id") or _new_id()
        found = False
        for it in items:
            if it.get("id") == iid:
                it.update({"name": d.get("name", ""), "pod": d.get("pod", ""), "role": d.get("role", ""),
                           "email": d.get("email", ""), "notes": d.get("notes", "")})
                found = True
                break
        if not found:
            items.append({"id": iid, "name": d.get("name", ""), "pod": d.get("pod", ""), "role": d.get("role", ""),
                          "email": d.get("email", ""), "notes": d.get("notes", ""), "deliverables": []})
        self._emit(items)

    @pyqtSlot(str)
    def deleteIntern(self, iid):
        self._emit([it for it in self._load() if it.get("id") != iid])

    @pyqtSlot(str)
    def saveDeliverable(self, payload):
        import json as _json
        d = _json.loads(payload)
        items = self._load()
        for it in items:
            if it.get("id") == d.get("internId"):
                delivs = it.setdefault("deliverables", [])
                did = d.get("id")
                if did:
                    for dd in delivs:
                        if dd.get("id") == did:
                            dd.update({"title": d.get("title", ""), "due": d.get("due", ""),
                                       "status": d.get("status", ""), "notes": d.get("notes", "")})
                            break
                else:
                    delivs.append({"id": _new_id(), "title": d.get("title", ""), "due": d.get("due", ""),
                                   "status": d.get("status", "Assigned"), "notes": d.get("notes", "")})
                break
        self._emit(items)

    @pyqtSlot(str)
    def deleteDeliverable(self, payload):
        import json as _json
        d = _json.loads(payload)
        items = self._load()
        for it in items:
            if it.get("id") == d.get("internId"):
                it["deliverables"] = [x for x in it.get("deliverables", []) if x.get("id") != d.get("id")]
                break
        self._emit(items)

    @pyqtSlot(str)
    def draftCheckin(self, iid):
        import json as _json, threading
        intern = next((it for it in self._load() if it.get("id") == iid), None)
        if not intern:
            self.checkinReady.emit(_json.dumps({"internId": iid, "error": "Intern not found."}))
            return

        def worker():
            try:
                from actions import interns as _i
                res = _i.draft_checkin(intern)
            except Exception as e:
                res = {"error": str(e)}
            res["internId"] = iid
            self.checkinReady.emit(_json.dumps(res))

        threading.Thread(target=worker, daemon=True).start()

    @pyqtSlot(str)
    def openComposer(self, payload):
        import json as _json, threading
        try:
            d = _json.loads(payload)
        except Exception:
            return

        def worker():
            try:
                from actions.draft_email import draft_email as draft_email_action
                draft_email_action(parameters={"to": d.get("email", ""), "subject": d.get("subject", ""),
                                               "body": d.get("body", "")})
            except Exception as e:
                print("[interns] composer error:", e)

        threading.Thread(target=worker, daemon=True).start()

    @pyqtSlot(str)
    def copyText(self, text):
        try:
            from PyQt6.QtWidgets import QApplication
            QApplication.clipboard().setText(text or "")
        except Exception:
            pass


_INTERN_HTML = r'''<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>__CSS__
.wrap{max-width:820px}
.stats{display:flex;gap:10px;margin:16px 0}
.stat{flex:1;background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:12px 14px}
.stat .v{font-size:22px;font-weight:700}.stat .l{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-top:2px}
.stat.due .v{color:var(--amber)}.stat.over .v{color:var(--red)}.stat.rev .v{color:var(--accent)}
.btn.ghost{background:transparent;border:1px solid var(--border);color:#dcdcd8}.btn.ghost:hover{border-color:var(--accent)}
.btn.sm{width:auto;padding:7px 14px;font-size:12px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px 18px;margin-top:12px}
.ihead{display:flex;align-items:center;gap:12px}
.av{width:40px;height:40px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:15px;color:#fff;flex:0 0 auto}
.iname{font-size:16px;font-weight:700}.imeta{font-size:12px;color:var(--muted);margin-top:1px}
.iact{margin-left:auto;display:flex;gap:8px}
.dlist{margin-top:12px}
.dl{display:flex;align-items:center;gap:10px;padding:9px 0;border-top:1px solid rgba(255,255,255,.05)}
.dl:first-child{border-top:none}
.dl .dt{flex:1;min-width:0}.dl .dt .ti{font-size:13.5px;color:#e3e2df}.dl .dt .du{font-size:11.5px;color:var(--muted);margin-top:2px}
.dl .dt .du.over{color:var(--red)}
.dl select{background:#0e0e12;border:1px solid var(--border);border-radius:8px;color:#dcdcd8;font-size:12px;padding:5px 8px}
.dl .x{cursor:pointer;color:var(--muted);font-weight:700;font-size:16px}.dl .x:hover{color:var(--red)}
.empty{color:var(--muted);font-size:13px;padding:8px 0}
.form{background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:12px;padding:14px;margin-top:12px}
.form .fg{margin-bottom:10px}.form label{display:block;font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px}
.form input,.form select,.form textarea{width:100%;background:#0e0e12;border:1px solid var(--border);border-radius:9px;color:#e8e7e4;font-size:13.5px;padding:9px 11px;box-sizing:border-box;font-family:inherit}
.form .two{display:flex;gap:10px}.form .two>div{flex:1}
.form .acts{display:flex;gap:10px;margin-top:6px}
.dform{margin-top:10px}
.checkin{background:var(--surface);border:1px solid var(--accent);border-radius:12px;padding:14px;margin-top:10px}
.checkin .subj{font-size:13px;font-weight:600;color:#fff}.checkin .body{font-size:13px;color:#dededa;line-height:1.55;white-space:pre-wrap;margin-top:8px}
.checkin .acts{display:flex;gap:8px;margin-top:10px}
</style></head><body>
<div class="wrap">
<div class="h1">Intern cohort</div>
<div class="sub">Your interns, their weekly deliverables, and one-tap check-ins.</div>
<div id="stats" class="stats"></div>
<button class="btn sm" onclick="newIntern()">+ Add intern</button>
<div id="editor"></div>
<div id="list"></div>
</div>
<script>
var INT=[];var STATUSES=["Assigned","In progress","Submitted","Reviewed","Blocked"];var PAL=["#2f6bff","#16a34a","#d4a03c","#9b5de5","#e0556b","#1f9e8f","#e07a3c","#5a7de0"];
function esc(x){return (x||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function val(id){var e=document.getElementById(id);return e?e.value.trim():"";}
function initials(n){n=(n||"").trim();if(!n)return "?";var p=n.split(/\s+/);return (p[0][0]+(p.length>1?p[p.length-1][0]:"")).toUpperCase();}
function colorFor(n){var s=0;for(var i=0;i<(n||"").length;i++)s+=n.charCodeAt(i);return PAL[s%PAL.length];}
function today(){return new Date().toISOString().slice(0,10);}
function isOver(due,status){if(!due)return false;if(status==="Reviewed"||status==="Submitted")return false;return due<today();}
function statBox(v,l,cls){return '<div class="stat '+(cls||"")+'"><div class="v">'+v+'</div><div class="l">'+l+'</div></div>';}
function renderStats(){var due=0,over=0,rev=0;var t=today();INT.forEach(function(i){(i.deliverables||[]).forEach(function(d){if(d.status==="Submitted")rev++;if(isOver(d.due,d.status))over++;else if(d.due&&d.status!=="Reviewed"){var diff=(new Date(d.due)-new Date(t))/86400000;if(diff>=0&&diff<=7)due++;}});});document.getElementById("stats").innerHTML=statBox(INT.length,"Interns")+statBox(due,"Due this week","due")+statBox(rev,"Needs review","rev")+statBox(over,"Overdue","over");}
function newIntern(){editIntern(-1);}
function editIntern(ix){var i=ix>=0?INT[ix]:{};document.getElementById("editor").innerHTML='<div class="form"><input type="hidden" id="i_id" value="'+esc(i.id||"")+'"><div class="two"><div class="fg"><label>Name</label><input id="i_name" value="'+esc(i.name||"")+'"></div><div class="fg"><label>Pod / team</label><input id="i_pod" value="'+esc(i.pod||"")+'"></div></div><div class="two"><div class="fg"><label>Role</label><input id="i_role" value="'+esc(i.role||"")+'"></div><div class="fg"><label>Email</label><input id="i_email" value="'+esc(i.email||"")+'"></div></div><div class="fg"><label>Notes</label><input id="i_notes" value="'+esc(i.notes||"")+'"></div><div class="acts"><button class="btn sm" onclick="saveIntern()">Save</button><button class="btn ghost sm" onclick="cancelEdit()">Cancel</button></div></div>';document.getElementById("editor").scrollIntoView({behavior:"smooth",block:"nearest"});}
function cancelEdit(){document.getElementById("editor").innerHTML="";}
function saveIntern(){var name=val("i_name");if(!name)return;var p={id:val("i_id"),name:name,pod:val("i_pod"),role:val("i_role"),email:val("i_email"),notes:val("i_notes")};window.bridge.saveIntern(JSON.stringify(p));cancelEdit();}
function delIntern(ix){if(INT[ix])window.bridge.deleteIntern(INT[ix].id);}
function addDeliv(ix){var el=document.getElementById("dform_"+ix);if(el)el.style.display=el.style.display==="none"?"block":"none";}
function saveDeliv(ix){var t=val("dt_"+ix);if(!t)return;var p={internId:INT[ix].id,title:t,due:val("dd_"+ix),status:val("ds_"+ix),notes:val("dn_"+ix)};window.bridge.saveDeliverable(JSON.stringify(p));}
function setStatus(ix,dix,v){var d=INT[ix].deliverables[dix];window.bridge.saveDeliverable(JSON.stringify({internId:INT[ix].id,id:d.id,title:d.title,due:d.due,status:v,notes:d.notes||""}));}
function delDeliv(ix,dix){var d=INT[ix].deliverables[dix];window.bridge.deleteDeliverable(JSON.stringify({internId:INT[ix].id,id:d.id}));}
function draftCheckin(ix){var c=document.getElementById("ci_"+ix);if(c)c.innerHTML='<div class="checkin"><span class="spinner"></span> Drafting check-in...</div>';window.bridge.draftCheckin(INT[ix].id);}
function statusSelect(ix,dix,cur){var h='<select onchange="setStatus('+ix+','+dix+',this.value)">';STATUSES.forEach(function(s){h+='<option'+(s===cur?" selected":"")+'>'+s+'</option>';});return h+'</select>';}
function statusOptions(cur){var h="";STATUSES.forEach(function(s){h+='<option'+(s===cur?" selected":"")+'>'+s+'</option>';});return h;}
function card(i,ix){
 var h='<div class="card"><div class="ihead"><div class="av" style="background:'+colorFor(i.name)+'">'+esc(initials(i.name))+'</div><div><div class="iname">'+esc(i.name)+'</div><div class="imeta">'+esc([i.pod,i.role].filter(Boolean).join(" \u00b7 ")||"\u2014")+(i.email?'  \u00b7  '+esc(i.email):"")+'</div></div><div class="iact"><button class="btn ghost sm" onclick="draftCheckin('+ix+')">Draft check-in</button><button class="btn ghost sm" onclick="editIntern('+ix+')">Edit</button><button class="btn ghost sm" onclick="delIntern('+ix+')">Delete</button></div></div>';
 h+='<div class="dlist">';
 var dl=i.deliverables||[];
 if(!dl.length)h+='<div class="empty">No deliverables yet.</div>';
 dl.forEach(function(d,dix){var ov=isOver(d.due,d.status);h+='<div class="dl"><div class="dt"><div class="ti">'+esc(d.title)+'</div><div class="du'+(ov?" over":"")+'">'+(d.due?("Due "+esc(d.due)+(ov?"  \u00b7  overdue":"")):"No due date")+(d.notes?("  \u00b7  "+esc(d.notes)):"")+'</div></div>'+statusSelect(ix,dix,d.status)+'<span class="x" onclick="delDeliv('+ix+','+dix+')">&times;</span></div>';});
 h+='</div>';
 h+='<div style="margin-top:10px"><button class="btn ghost sm" onclick="addDeliv('+ix+')">+ Add deliverable</button></div>';
 h+='<div class="dform" id="dform_'+ix+'" style="display:none"><div class="form"><div class="fg"><label>Deliverable</label><input id="dt_'+ix+'" placeholder="e.g. LinkedIn post draft"></div><div class="two"><div class="fg"><label>Due date</label><input type="date" id="dd_'+ix+'"></div><div class="fg"><label>Status</label><select id="ds_'+ix+'">'+statusOptions("Assigned")+'</select></div></div><div class="fg"><label>Notes</label><input id="dn_'+ix+'"></div><div class="acts"><button class="btn sm" onclick="saveDeliv('+ix+')">Add</button></div></div></div>';
 h+='<div id="ci_'+ix+'"></div>';
 return h+'</div>';
}
function renderList(){var h="";if(!INT.length)h='<div class="card"><div class="empty">No interns yet. Add your cohort to get started.</div></div>';INT.forEach(function(i,ix){h+=card(i,ix);});document.getElementById("list").innerHTML=h;}
function onInterns(s){try{INT=JSON.parse(s)}catch(e){INT=[]}renderStats();renderList();}
function onCheckin(s){var d={};try{d=JSON.parse(s)}catch(e){}var ix=-1;INT.forEach(function(i,k){if(i.id===d.internId)ix=k;});if(ix<0)return;var c=document.getElementById("ci_"+ix);if(!c)return;if(d.error){c.innerHTML='<div class="checkin" style="border-color:var(--red)"><div class="body" style="color:var(--red)">'+esc(d.error)+'</div></div>';return;}LASTCI[ix]=d;c.innerHTML='<div class="checkin"><div class="subj">Subject: '+esc(d.subject||"")+'</div><div class="body">'+esc(d.body||"")+'</div><div class="acts"><button class="btn sm" onclick="openCI('+ix+')">Open in Outlook</button><button class="btn ghost sm" onclick="copyCI('+ix+')">Copy</button></div></div>';}
var LASTCI={};
function openCI(ix){var d=LASTCI[ix];if(!d)return;window.bridge.openComposer(JSON.stringify({email:(INT[ix]||{}).email||"",subject:d.subject||"",body:d.body||""}));}
function copyCI(ix){var d=LASTCI[ix];if(!d)return;window.bridge.copyText((d.subject?("Subject: "+d.subject+"\n\n"):"")+(d.body||""));}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.internsReady.connect(onInterns);bridge.checkinReady.connect(onCheckin);bridge.getInterns();});
</script></body></html>
'''
_INTERN_HTML = _INTERN_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)


class _NotesBridge(QObject):
    notesReady = pyqtSignal(str)
    exitRequested = pyqtSignal()

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    @pyqtSlot()
    def getNotes(self):
        import json as _json
        self.notesReady.emit(_json.dumps(_hud_store_load("notes")))

    @pyqtSlot(str)
    def addNote(self, payload):
        import json as _json, time as _t
        try:
            d = _json.loads(payload)
        except Exception:
            return
        text = (d.get("text") or "").strip()
        if not text:
            return
        items = _hud_store_load("notes")
        items.insert(0, {"id": _new_id(), "ts": int(_t.time()), "text": text, "tag": d.get("tag", "general")})
        _hud_store_save("notes", items)
        self.notesReady.emit(_json.dumps(items))

    @pyqtSlot(str)
    def deleteNote(self, nid):
        import json as _json
        items = [n for n in _hud_store_load("notes") if n.get("id") != nid]
        _hud_store_save("notes", items)
        self.notesReady.emit(_json.dumps(items))


_NOTES_HTML = r'''<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<style>__CSS__
.wrap{max-width:720px}
.addrow{display:flex;gap:8px;margin-top:16px}
.addrow input{flex:1}
.addrow select{background:#0e0e12;border:1px solid var(--border);border-radius:10px;color:#dcdcd8;font-size:13px;padding:0 10px}
.addrow .btn{width:auto;flex:0 0 auto;padding:11px 18px}
.filters{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}
.fc{font-size:12px;font-weight:600;padding:6px 12px;border-radius:999px;border:1px solid var(--border);color:var(--muted);cursor:pointer}
.fc.on{color:#fff;border-color:var(--accent);background:rgba(47,107,255,.12)}
.note{display:flex;gap:12px;align-items:flex-start;background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:13px 15px;margin-top:10px}
.note .body{flex:1;min-width:0}
.note .tx{font-size:14px;line-height:1.5;color:#e8e7e4;white-space:pre-wrap;word-break:break-word}
.note .meta{display:flex;align-items:center;gap:8px;margin-top:7px}
.tag{font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;padding:2px 8px;border-radius:6px}
.note .ts{font-size:11.5px;color:var(--muted)}
.note .x{cursor:pointer;color:var(--muted);font-weight:700;font-size:16px;flex:0 0 auto}.note .x:hover{color:var(--red)}
.empty{color:var(--muted);font-size:13px;margin-top:16px}
</style></head><body>
<div class="wrap">
<div class="h1">Notes</div>
<div class="sub">Zero-friction capture, jot an idea, a call, a trade thesis before it slips.</div>
<div class="addrow"><input id="note" placeholder="Capture a thought..." onkeydown="if(event.key==='Enter')add()"><select id="tag"></select><button class="btn" onclick="add()">Add</button></div>
<div id="filters" class="filters"></div>
<div id="list"></div>
</div>
<script>
var NOTES=[];var FILTER="all";
var TAGS=[{k:"idea",l:"Idea",c:"#2f6bff"},{k:"call",l:"Call",c:"#9b5de5"},{k:"trade",l:"Trade",c:"#16a34a"},{k:"todo",l:"Todo",c:"#d4a03c"},{k:"general",l:"General",c:"#8a8a86"}];
function esc(x){return (x||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}
function tagOf(k){for(var i=0;i<TAGS.length;i++)if(TAGS[i].k===k)return TAGS[i];return TAGS[TAGS.length-1];}
function fmtTs(ts){try{return new Date(ts*1000).toLocaleString(undefined,{month:"short",day:"numeric",hour:"numeric",minute:"2-digit"})}catch(e){return ""}}
function initTag(){var h="";TAGS.forEach(function(t){h+='<option value="'+t.k+'">'+t.l+'</option>'});document.getElementById("tag").innerHTML=h;}
function renderFilters(){var h='<span class="fc'+(FILTER==="all"?" on":"")+'" onclick="setF(\'all\')">All</span>';TAGS.forEach(function(t){h+='<span class="fc'+(FILTER===t.k?" on":"")+'" onclick="setF(\''+t.k+'\')">'+t.l+'</span>'});document.getElementById("filters").innerHTML=h;}
function setF(k){FILTER=k;renderFilters();renderList();}
function renderList(){var arr=FILTER==="all"?NOTES:NOTES.filter(function(n){return n.tag===FILTER});var h="";if(!arr.length){h='<div class="empty">Nothing captured yet.</div>';}arr.forEach(function(n){var t=tagOf(n.tag);h+='<div class="note"><div class="body"><div class="tx">'+esc(n.text)+'</div><div class="meta"><span class="tag" style="color:'+t.c+';background:'+t.c+'22">'+t.l+'</span><span class="ts">'+fmtTs(n.ts)+'</span></div></div><span class="x" onclick="del(\''+n.id+'\')">&times;</span></div>';});document.getElementById("list").innerHTML=h;}
function add(){var i=document.getElementById("note");var t=i.value.trim();if(!t)return;var tag=document.getElementById("tag").value;i.value="";window.bridge.addNote(JSON.stringify({text:t,tag:tag}));}
function del(id){window.bridge.deleteNote(id);}
function onNotes(s){try{NOTES=JSON.parse(s)}catch(e){NOTES=[]}renderList();}
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;bridge.notesReady.connect(onNotes);initTag();renderFilters();bridge.getNotes();});
</script></body></html>
'''
_NOTES_HTML = _NOTES_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)





def paint_glyph(p, name, cx, cy, size, col, width=1.8):
    if name == "brain":
        draw_brain(p, cx, cy, size / 46.0, col, width); return
    p.save()
    sc = size / 24.0
    p.translate(cx, cy); p.scale(sc, sc); p.translate(-12, -12)
    pen = QPen(col); pen.setWidthF(width); pen.setCosmetic(True)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap); pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush)
    _NODE_GLYPHS.get(name, _ng_dot)(p)
    p.restore()


class IconButton(QPushButton):
    """Flat button painting a crisp monochrome line icon."""
    def __init__(self, name, parent=None, on_click=None, pill=False, size=None):
        super().__init__(parent)
        self._name = name
        self._hover = False
        self._pill = pill
        if size:
            self.setFixedSize(size, size)
        else:
            self.setFixedSize(46 if pill else 42, 38 if pill else 40)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setStyleSheet("QPushButton { background: transparent; border: none; }")
        if on_click:
            self.clicked.connect(on_click)

    def set_name(self, name):
        self._name = name; self.update()

    def enterEvent(self, _e):
        self._hover = True; self.update()

    def leaveEvent(self, _e):
        self._hover = False; self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        if self._pill:
            bg = QColor(20, 32, 52, 220) if not self._hover else QColor(30, 48, 76, 230)
            p.setPen(QPen(QColor(40, 70, 104), 1.0)); p.setBrush(bg)
            p.drawRoundedRect(QRectF(1, 1, self.width() - 2, self.height() - 2), 9, 9)
        col = QColor(207, 230, 255) if self._hover else QColor(120, 162, 214)
        if self._name == "mic_off":
            col = QColor(214, 120, 120) if not self._hover else QColor(240, 150, 150)
        pen = QPen(col); pen.setWidthF(1.6); pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush)
        p.translate((self.width() - 24) / 2.0, (self.height() - 24) / 2.0)
        getattr(self, "_ic_" + self._name, self._ic_dot)(p)
        p.end()

    def _ic_dot(self, p): p.drawEllipse(QPointF(12, 12), 3, 3)
    def _ic_clock(self, p): _ng_clock(p)
    def _ic_folder(self, p): _ng_folder(p)
    def _ic_music(self, p): _ng_music(p)
    def _ic_settings(self, p):
        for y in (7, 12, 17): p.drawLine(QPointF(3, y), QPointF(21, y))
        p.setBrush(QColor(10, 16, 28))
        p.drawEllipse(QPointF(8, 7), 2.4, 2.4); p.drawEllipse(QPointF(15, 12), 2.4, 2.4); p.drawEllipse(QPointF(9, 17), 2.4, 2.4)
        p.setBrush(Qt.BrushStyle.NoBrush)
    def _ic_mic(self, p):
        path = QPainterPath(); path.addRoundedRect(QRectF(9, 3, 6, 11), 3, 3); p.drawPath(path)
        arc = QPainterPath(); arc.moveTo(6.5, 12); arc.arcTo(QRectF(6.5, 6, 11, 11), 200, 140); p.drawPath(arc)
        p.drawLine(QPointF(12, 17), QPointF(12, 20)); p.drawLine(QPointF(9, 20), QPointF(15, 20))
    def _ic_mic_off(self, p):
        self._ic_mic(p); p.drawLine(QPointF(5, 4), QPointF(19, 20))
    def _ic_power(self, p):
        p.drawArc(QRectF(4, 4, 16, 16), 110 * 16, 320 * 16)
        p.drawLine(QPointF(12, 3), QPointF(12, 11))
    def _ic_back(self, p):
        p.drawLine(QPointF(14, 5), QPointF(7, 12)); p.drawLine(QPointF(7, 12), QPointF(14, 19))
    def _ic_close(self, p):
        p.drawLine(QPointF(6.5, 6.5), QPointF(17.5, 17.5)); p.drawLine(QPointF(17.5, 6.5), QPointF(6.5, 17.5))
    def _ic_add(self, p):
        p.drawLine(QPointF(12, 5.5), QPointF(12, 18.5)); p.drawLine(QPointF(5.5, 12), QPointF(18.5, 12))
    def _ic_chat(self, p):
        path = QPainterPath(); path.addRoundedRect(QRectF(3, 4, 18, 12), 3, 3); p.drawPath(path)
        p.drawLine(QPointF(8, 16), QPointF(8, 20)); p.drawLine(QPointF(8, 20), QPointF(13, 16))



class TimerCanvas(QWidget):
    """Painted dial for the timer tab. Transparent base (the page supplies the
    gradient); draws rings/ticks once, then the live arc + digits per tick.
    Handles both timer (count down) and stopwatch (count up)."""
    def __init__(self, get_state, on_center_tap, parent=None):
        super().__init__(parent)
        self._get_state = get_state
        self._on_center_tap = on_center_tap
        self._base = None

    def _geom(self):
        w = self.width(); h = self.height()
        return w, h, w / 2.0, h * 0.50, min(w, h) * 0.30

    def resizeEvent(self, e):
        self._base = None; super().resizeEvent(e)

    def _build_base(self):
        w, h, cx, cy, R = self._geom()
        pm = QPixmap(max(1, w), max(1, h)); pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm); p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        gg = QRadialGradient(cx, cy, R * 1.6)
        gg.setColorAt(0.0, QColor(46, 100, 165, 55)); gg.setColorAt(1.0, QColor(46, 100, 165, 0))
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(gg); p.drawEllipse(QPointF(cx, cy), R * 1.6, R * 1.6)
        p.setBrush(Qt.BrushStyle.NoBrush)
        for rr, al in ((R, 46), (R * 0.84, 24), (R * 1.24, 15)):
            p.setPen(QPen(QColor(96, 156, 224, al), 1.2)); p.drawEllipse(QPointF(cx, cy), rr, rr)
        for i in range(60):
            a = i * (math.pi / 30.0); major = (i % 5 == 0)
            r1 = R; r2 = R + (11 if major else 5)
            p.setPen(QPen(QColor(120, 178, 238, 78 if major else 30), 1.7 if major else 1.0))
            p.drawLine(QPointF(cx + math.cos(a) * r1, cy + math.sin(a) * r1),
                       QPointF(cx + math.cos(a) * r2, cy + math.sin(a) * r2))
        p.end(); self._base = pm

    @staticmethod
    def _fmt(rem):
        s = int(math.ceil(max(0.0, float(rem))))
        if s >= 3600:
            return "%d:%02d:%02d" % (s // 3600, (s % 3600) // 60, s % 60)
        return "%d:%02d" % (s // 60, s % 60)

    @staticmethod
    def _fmt_sw(el):
        el = max(0.0, float(el)); s = int(el); t = int(el * 10) % 10
        if s >= 3600:
            return "%d:%02d:%02d" % (s // 3600, (s % 3600) // 60, s % 60)
        return "%d:%02d.%d" % (s // 60, s % 60, t)

    def _arc(self, p, cx, cy, R, frac, col):
        span = int(360 * max(0.0, min(1.0, frac)) * 16)
        for wd, al in ((16, 70), (9, 150), (5, 250)):
            c = QColor(col); c.setAlpha(al)
            pen = QPen(c, wd); pen.setCapStyle(Qt.PenCapStyle.RoundCap); p.setPen(pen)
            p.drawArc(QRectF(cx - R, cy - R, 2 * R, 2 * R), 90 * 16, -span)

    def _center(self, p, cx, cy, R, big, small, big_col, small_col, big_pt=54):
        f = QFont(); f.setPointSize(big_pt); f.setWeight(QFont.Weight.DemiBold); p.setFont(f)
        p.setPen(big_col); p.drawText(QRectF(cx - R, cy - R * 0.46, 2 * R, R * 0.92), Qt.AlignmentFlag.AlignCenter, big)
        f2 = QFont(); f2.setPointSize(13); p.setFont(f2); p.setPen(small_col)
        p.drawText(QRectF(cx - R, cy + R * 0.52, 2 * R, 32), Qt.AlignmentFlag.AlignCenter, small)

    def paintEvent(self, e):
        if self._base is None or self._base.width() != self.width() or self._base.height() != self.height():
            self._build_base()
        w, h, cx, cy, R = self._geom()
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.drawPixmap(0, 0, self._base)
        st = self._get_state()
        mode = st.get("mode", "timer")
        if mode == "stopwatch":
            el = st["elapsed"]; running = st["running"]; laps = st.get("laps", [])
            teal = QColor(64, 208, 192) if running else QColor(120, 150, 158)
            frac = (el % 60) / 60.0
            span = int(360 * frac * 16)
            for wd, al in ((7, 65), (3, 230)):
                c = QColor(teal); c.setAlpha(al)
                pen = QPen(c, wd); pen.setCapStyle(Qt.PenCapStyle.RoundCap); p.setPen(pen)
                p.drawArc(QRectF(cx - R, cy - R, 2 * R, 2 * R), 90 * 16, -span)
            for lp in laps[-12:]:
                la = -math.pi / 2 + (lp % 60) / 60.0 * 2 * math.pi
                p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor(150, 220, 210, 190))
                p.drawEllipse(QPointF(cx + math.cos(la) * R, cy + math.sin(la) * R), 3.2, 3.2)
            ang = -math.pi / 2 + frac * 2 * math.pi
            tx = cx + math.cos(ang) * R * 0.9; ty = cy + math.sin(ang) * R * 0.9
            pen = QPen(teal, 3.0); pen.setCapStyle(Qt.PenCapStyle.RoundCap); p.setPen(pen)
            p.drawLine(QPointF(cx, cy), QPointF(tx, ty))
            gh = QRadialGradient(tx, ty, 9)
            gh.setColorAt(0.0, QColor(teal.red(), teal.green(), teal.blue(), 180)); gh.setColorAt(1.0, QColor(teal.red(), teal.green(), teal.blue(), 0))
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(gh); p.drawEllipse(QPointF(tx, ty), 9, 9)
            p.setBrush(QColor(222, 255, 250)); p.drawEllipse(QPointF(tx, ty), 3, 3)
            p.setBrush(teal); p.drawEllipse(QPointF(cx, cy), 5, 5)
            sub = ("Stopwatch  -  %d laps" % len(laps)) if laps else ("Stopwatch" if running else ("Stopwatch  -  paused" if el > 0 else "Stopwatch"))
            self._center(p, cx, cy, R, self._fmt_sw(el), sub, QColor(225, 250, 245), QColor(140, 185, 178), big_pt=48)
            return
        prim = st.get("primary"); pulse = st.get("pulse", 0.0)
        if prim is None:
            p.setPen(QColor(110, 152, 206)); f = QFont(); f.setPointSize(44); p.setFont(f)
            p.drawText(QRectF(cx - R, cy - R * 0.66, 2 * R, R), Qt.AlignmentFlag.AlignCenter, "\u23f2")
            self._center(p, cx, cy, R, "", "Set a timer  -  tap a preset, type, or tell OB",
                         QColor(238, 245, 255), QColor(150, 178, 210))
            f3 = QFont(); f3.setPointSize(16); p.setFont(f3); p.setPen(QColor(158, 186, 220))
            p.drawText(QRectF(cx - R, cy + R * 0.06, 2 * R, 34), Qt.AlignmentFlag.AlignCenter, "Set a timer")
            return
        done = prim["done"]
        if done:
            base = QColor(255, 205, 90); a = 150 + int(95 * math.sin(pulse))
            for i, wd in enumerate((20, 12, 7)):
                c = QColor(base); c.setAlpha(max(30, a // (i + 1)))
                pen = QPen(c, wd); pen.setCapStyle(Qt.PenCapStyle.RoundCap); p.setPen(pen)
                p.drawEllipse(QPointF(cx, cy), R, R)
        else:
            frac = (prim["remaining"] / prim["total"]) if prim["total"] else 0.0
            self._arc(p, cx, cy, R, frac, QColor(255, 150, 70) if prim["remaining"] <= 10 else QColor(86, 170, 255))
        self._center(p, cx, cy, R, "DONE" if done else self._fmt(prim["remaining"]),
                     prim["label"] or ("Time is up" if done else "Timer"),
                     QColor(255, 225, 170) if done else QColor(238, 245, 255), QColor(150, 178, 210),
                     big_pt=40 if done else 54)

    def mousePressEvent(self, e):
        w, h, cx, cy, R = self._geom()
        dx = e.position().x() - cx; dy = e.position().y() - cy
        if (dx * dx + dy * dy) ** 0.5 <= R and self._on_center_tap:
            self._on_center_tap()


class _MockBridge(QObject):
    exitRequested = pyqtSignal()

    def __init__(self):
        super().__init__()
        self._on_start = None
        self._on_end = None

    @pyqtSlot()
    def goBack(self):
        self.exitRequested.emit()

    @pyqtSlot()
    def endMock(self):
        if self._on_end:
            try:
                self._on_end()
            except Exception as e:
                print("[OB] mock end err:", e)

    @pyqtSlot(str)
    def startMock(self, cfg):
        if self._on_start:
            try:
                self._on_start(cfg)
            except Exception as e:
                print("[OB] mock bridge err:", e)


_MOCK_HTML = """<!doctype html><html><head><meta charset="utf-8">
<style>__CSS__
*{box-sizing:border-box}
body{margin:0;padding:34px 30px 40px;color:var(--text);font-family:Inter,-apple-system,sans-serif}
.eyebrow{font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--accent);font-weight:600;margin-bottom:6px}
h1{font-family:'Instrument Serif',Georgia,serif;font-weight:400;font-size:34px;margin:0 0 22px}
.lbl{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#7d8aa0;font-weight:600;margin:22px 0 10px}
.grid{display:flex;flex-wrap:wrap;gap:8px}
.chip{padding:9px 15px;border:1px solid var(--border);border-radius:10px;background:var(--surface);
  color:var(--text);font-size:13px;cursor:pointer;transition:.12s;user-select:none}
.chip:hover{border-color:var(--accent)}
.chip.on{background:var(--accent);border-color:var(--accent);color:#fff}
.chip.soon{opacity:.4;cursor:not-allowed}
.chip.soon:hover{border-color:var(--border)}
.tip{font-size:11px;color:#6b7688;margin-top:6px}
input{width:100%;margin-top:2px;padding:12px 14px;border:1px solid var(--border);border-radius:10px;
  background:var(--surface);color:var(--text);font-size:14px;font-family:inherit;outline:none}
input:focus{border-color:var(--accent)}
.typecard{flex:1;min-width:150px;padding:14px 16px;border:1px solid var(--border);border-radius:12px;
  background:var(--surface);cursor:pointer;transition:.12s}
.typecard:hover{border-color:var(--accent)}
.typecard.on{border-color:var(--accent);background:rgba(37,99,235,.12)}
.typecard .t{font-size:14px;font-weight:600;margin-bottom:3px}
.typecard .d{font-size:11px;color:#7d8aa0}
#start{margin-top:28px;width:100%;padding:14px;border:none;border-radius:12px;background:var(--accent);
  color:#fff;font-size:15px;font-weight:600;cursor:pointer;font-family:inherit;transition:.12s}
#start:hover{filter:brightness(1.08)}
#start:disabled{opacity:.4;cursor:not-allowed}
#live{display:none;margin-top:18px}
.livehdr{display:flex;align-items:center;gap:9px;font-size:13px;color:#aab4c4;margin-bottom:12px}
.livehdr b{color:var(--text);font-weight:600}
.dot{width:8px;height:8px;border-radius:50%;background:#34d399;box-shadow:0 0 8px #34d399}
#tx{border:1px solid var(--border);border-radius:14px;background:var(--surface);padding:16px;
  min-height:46vh;max-height:60vh;overflow-y:auto;display:flex;flex-direction:column;gap:12px}
.ln{max-width:78%;padding:10px 14px;border-radius:13px;font-size:13.5px;line-height:1.5;white-space:pre-wrap}
.ln.ob{align-self:flex-start;background:#11161f;border:1px solid var(--border);color:#dfe7f2;border-top-left-radius:4px}
.ln.me{align-self:flex-end;background:var(--accent);color:#fff;border-top-right-radius:4px}
.ln .who{display:block;font-size:10px;letter-spacing:.12em;text-transform:uppercase;opacity:.6;margin-bottom:3px}
.empty{color:#6b7688;font-size:13px;text-align:center;margin:auto}
.livebar{display:flex;align-items:center;justify-content:space-between;margin-top:14px;gap:12px}
.livebar .hint{font-size:12px;color:#7d8aa0}
.ln.status{opacity:.65;font-style:italic;animation:pulse 1.4s ease-in-out infinite}
@keyframes pulse{0%,100%{opacity:.4}50%{opacity:.8}}
#endbtn{padding:11px 18px;border:1px solid var(--border);border-radius:10px;background:var(--surface);
  color:var(--text);font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;transition:.12s}
#endbtn:hover{border-color:#ef4444;color:#ef4444}
</style></head><body>
<div id="form">
  <div class="eyebrow">Mock Interview</div>
  <h1>Set up your mock</h1>

  <div class="lbl">Career track</div>
  <div class="grid" id="careers"></div>

  <div class="lbl">Firm to simulate</div>
  <input id="firm" placeholder="e.g. Goldman Sachs, Evercore, Moelis" />
  <div class="tip">Optional. OB will run the interview in that firm's style.</div>

  <div class="lbl">Interview type</div>
  <div class="grid">
    <div class="typecard" data-type="behavioral"><div class="t">Behavioral</div><div class="d">~15 min · fit & story</div></div>
    <div class="typecard" data-type="technical"><div class="t" id="midt">Technical</div><div class="d">~15 min &middot; core skills</div></div>
    <div class="typecard on" data-type="full"><div class="t">Full mock</div><div class="d">~30-40 min · all three parts</div></div>
  </div>

  <button id="start">Start interview</button>
</div>

<div id="live">
  <div class="livehdr"><span class="dot"></span><b id="lvfirm">Interview</b><span id="lvtype"></span></div>
  <div id="tx"><div class="empty">Listen for your interviewer's first question, then answer out loud.</div></div>
  <div class="livebar">
    <span class="hint">Answer out loud &middot; your transcript appears here live</span>
    <button id="endbtn">End &amp; get assessment</button>
  </div>
</div>

<script src="qrc:///qtwebchannel/qwebchannel.js"></script>
<script>
var CAREERS=[["IB","Investment Banking",1],["PE","Private Equity",1],["RX","Restructuring",1],
["ST","Sales & Trading",1],["CONSULTING","Consulting",1],["ACCOUNTING","Accounting & Audit",1],
["AM","Asset Management",1],["RE","Real Estate",1],["ER","Equity Research",1],["VC","Venture Capital",1]];
var MIDLABELS={IB:"Technical",PE:"Technical",RX:"Technical",ST:"Markets & Math",CONSULTING:"Case",
ACCOUNTING:"Technical",AM:"Technical",RE:"Technical",ER:"Technical",VC:"Evaluation"};
var sel={career:"IB",type:"full"};
var cg=document.getElementById("careers");
function relabelMid(){var m=document.getElementById("midt");if(m)m.textContent=MIDLABELS[sel.career]||"Technical";}
CAREERS.forEach(function(c){
  var d=document.createElement("div");
  d.className="chip"+(c[2]?(c[0]===sel.career?" on":""):" soon");
  d.textContent=c[1]+(c[2]?"":" \u00b7 soon");
  if(c[2]){d.onclick=function(){sel.career=c[0];
    [].forEach.call(cg.children,function(x){x.classList.remove("on")});d.classList.add("on");relabelMid();};}
  cg.appendChild(d);
});
relabelMid();
var tcs=document.querySelectorAll(".typecard");
[].forEach.call(tcs,function(t){t.onclick=function(){
  [].forEach.call(tcs,function(x){x.classList.remove("on")});t.classList.add("on");
  sel.type=t.getAttribute("data-type");};});
window.bridge=null;
new QWebChannel(qt.webChannelTransport,function(ch){window.bridge=ch.objects.bridge;});
window.mockAddLine=function(role,text){
  var tx=document.getElementById("tx"); if(!tx)return;
  var e=tx.querySelector(".empty"); if(e)e.remove();
  if(role!=="user"){
    var st=tx.querySelector(".status"); if(st)st.remove();
    if(window._obEnding){window._obEnding=false;
      var b=document.getElementById("endbtn");
      b.textContent="New interview"; b.disabled=false; b.onclick=newInterview;}
  }
  var d=document.createElement("div");
  d.className="ln "+(role==="user"?"me":"ob");
  var who=document.createElement("span"); who.className="who";
  who.textContent=(role==="user"?"You":"Interviewer");
  d.appendChild(who); d.appendChild(document.createTextNode(text));
  tx.appendChild(d); tx.scrollTop=tx.scrollHeight;
};
var TLAB={behavioral:"Behavioral \u00b7 ~15 min",technical:"Technical \u00b7 ~15 min",full:"Full mock \u00b7 ~30-40 min"};
window._obEnding=false;
function endHandler(){
  var tx=document.getElementById("tx");
  if(tx){var e=tx.querySelector(".empty"); if(e)e.remove();
    if(!tx.querySelector(".status")){
      var s=document.createElement("div"); s.className="ln ob status";
      s.textContent="Preparing your assessment\u2026";
      tx.appendChild(s); tx.scrollTop=tx.scrollHeight;}}
  if(window.bridge&&window.bridge.endMock)window.bridge.endMock();
  window._obEnding=true;
  var b=document.getElementById("endbtn");
  b.textContent="Wrapping up\u2026"; b.disabled=true;
}
function newInterview(){
  document.getElementById("live").style.display="none";
  document.getElementById("form").style.display="block";
  var b=document.getElementById("endbtn");
  b.textContent="End & get assessment"; b.disabled=false; b.onclick=endHandler;
  window._obEnding=false;
}
document.getElementById("start").onclick=function(){
  if(!window.bridge)return;
  var firm=document.getElementById("firm").value||"";
  document.getElementById("lvfirm").textContent=firm||"Mock interview";
  document.getElementById("lvtype").textContent="\u00b7 "+(TLAB[sel.type]||"");
  document.getElementById("tx").innerHTML='<div class="empty">Listen for the first question, then answer out loud.</div>';
  var b=document.getElementById("endbtn");
  b.textContent="End & get assessment"; b.disabled=false; b.onclick=endHandler; window._obEnding=false;
  window.bridge.startMock(JSON.stringify({career:sel.career,firm:firm,type:sel.type}));
  document.getElementById("form").style.display="none";
  document.getElementById("live").style.display="block";
};
document.getElementById("endbtn").onclick=endHandler;
</script>
</body></html>"""
_MOCK_HTML = _MOCK_HTML.replace("__CSS__", _CB_CSS).replace("<body>", "<body>" + _BACKBTN, 1)


class ActiveHUD(QWidget):
    constel_request = pyqtSignal(str)
    timer_request = pyqtSignal(int, str)
    voice_request = pyqtSignal(str, str, str)

    def __init__(self, parent=None, on_send=None, on_mute=None, on_idle=None):
        super().__init__(parent)
        self._on_send = on_send
        self._on_mute = on_mute
        self._on_idle = on_idle
        self._state = "LISTENING"
        self._muted_flag = False
        self._on_mock_start = None
        self._t = 0.0
        self._grid = None
        self._buf = None
        self._morph = 0.0
        self._rot = 0.0
        self._tphase = 0.0
        self._spkf = 0.0
        self._constel = 0.0
        self._constel_target = 0.0
        self._constel_points = None
        self._constel_all = None
        self._orb_rect = QRect(0, 0, 10, 10)
        # portal state
        self._mode = "orb"            # orb | zoom_in | tab | zoom_out
        self._zoom = 0.0
        self._zoom_target = 0.0
        self._active_tab = None
        self._world = None
        self._WORLDS = [
            {"id": "net", "label": "Networking", "icon": "crm", "tabs": ["outreach", "prep", "crm"]},
            {"id": "markets", "label": "Markets", "icon": "teardown", "tabs": ["teardown", "fdiff", "earn", "brief"]},
            {"id": "school", "label": "School", "icon": "study", "tabs": ["study"]},
            {"id": "offerbell", "label": "OfferBell", "icon": "intern", "tabs": ["intern"]},
            {"id": "system", "label": "System", "icon": "system", "tabs": ["cookbook", "council", "timer", "notes", "contacts"]},
        ]
        self._page_visible = False
        self._hover_nodes = 0.0
        self._hover_target = 0.0
        self._hover_tab = None
        self._tabs = []
        # orb nodes (Fibonacci sphere) — unchanged engine
        self._nodes = []
        n = 50
        ga = math.pi * (3.0 - math.sqrt(5.0))
        for i in range(n):
            y = 1.0 - (i / float(n - 1)) * 2.0
            r = math.sqrt(max(0.0, 1.0 - y * y))
            th = ga * i
            self._nodes.append([math.cos(th) * r, y, math.sin(th) * r, random.random() * 6.28])
        # fixed mesh: link each node to its k nearest neighbours (cheap, stable)
        self._edges = []
        seen = set()
        for i in range(n):
            xi, yi, zi, _ = self._nodes[i]
            order = sorted(range(n), key=lambda j: (self._nodes[j][0] - xi) ** 2 + (self._nodes[j][1] - yi) ** 2 + (self._nodes[j][2] - zi) ** 2)
            for j in order[1:5]:
                e = (i, j) if i < j else (j, i)
                if e not in seen:
                    seen.add(e); self._edges.append(e)
        self._params = {
            "LISTENING": (1.0, 1.0, 0.85, 0.64, 0.72),
            "SPEAKING":  (2.3, 2.2, 1.00, 0.70, 0.92),
            "THINKING":  (1.6, 1.6, 0.95, 0.67, 0.80),
            "MUTED":     (0.5, 0.7, 0.55, 0.60, 0.55),
        }
        self._pvals = list(self._params["LISTENING"])
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self._build_chat()
        self._build_dock()
        self._timers = []
        self._timer_seq = 0
        self._timer_pulse = 0.0
        self._timer_mode = "timer"
        self._sw = {"elapsed": 0.0, "running": False, "laps": []}
        self._timer_tick = QTimer(self)
        self._timer_tick.timeout.connect(self._tick_timers)
        self.timer_request.connect(self._do_add_timer)
        self._toast = QWidget(self); self._toast.setObjectName("toast")
        self._toast.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        _tl = QHBoxLayout(self._toast); _tl.setContentsMargins(18, 9, 9, 9); _tl.setSpacing(13)
        self._toast_lbl = QLabel(""); self._toast_lbl.setStyleSheet("background: transparent; color: #dcecff; font-size: 14px;")
        _tl.addWidget(self._toast_lbl)
        self._toast_x = QPushButton("\u2715"); self._toast_x.setCursor(Qt.CursorShape.PointingHandCursor)
        self._toast_x.setFixedSize(22, 22)
        self._toast_x.setStyleSheet("QPushButton { background: transparent; border: none; color: #8aa6c8; font-size: 13px; } QPushButton:hover { color: #ffffff; }")
        self._toast_x.clicked.connect(self._dismiss_toast)
        _tl.addWidget(self._toast_x)
        self._toast.hide(); self._toast_kind = None; self._toast_dismissed = False
        self._register_default_tabs()
        self._tmr = QTimer(self)
        self._tmr.timeout.connect(self._adv)
        self._tmr.start(33)
        self._constel_timer = QTimer(self); self._constel_timer.setSingleShot(True)
        self._constel_timer.timeout.connect(self.constellate_clear)
        self.constel_request.connect(self._do_constellate)
        self.voice_request.connect(self._do_voice_open)

    # ---- public API ----
    def set_state(self, state):
        if state in self._params:
            self._state = state

    def set_muted(self, muted):
        self._muted_flag = bool(muted)
        if hasattr(self, "_mic_btn"):
            self._mic_btn.set_name("mic_off" if muted else "mic")
        self.set_state("MUTED" if muted else "LISTENING")

    def add_message(self, text):
        text = text or ""
        role, body = "sys", text
        if text.startswith("You: "): role, body = "user", text[5:]
        elif text.startswith("OB: "): role, body = "assistant", text[4:]
        elif text.startswith("SYS: "): role, body = "sys", text[5:]
        self._add_bubble(role, body)

    def constellate(self, text):
        # thread-safe entrypoint: marshal to the GUI thread via signal
        self.constel_request.emit(text or "")

    def _do_constellate(self, text):
        text = (text or "").strip()
        if not text:
            self.constellate_clear(); return
        try:
            pts = self._sample_text_points(text[:10], 1300)
        except Exception as _e:
            print("[Constellate] sample failed:", _e); return
        if not pts:
            return
        self._constel_all = pts
        n = len(self._nodes)
        if len(pts) >= n:
            step = len(pts) / float(n)
            self._constel_points = [pts[int(i * step)] for i in range(n)]
        else:
            self._constel_points = (pts * ((n // max(1, len(pts))) + 1))[:n]
        self._constel_target = 1.0
        self._constel_timer.start(6000)

    def constellate_clear(self):
        self._constel_target = 0.0

    def _sample_text_points(self, text, count):
        bs = getattr(self, "_buf_size", 0) or 480
        iw, ih = 760, 320
        img = QImage(iw, ih, QImage.Format.Format_ARGB32); img.fill(0)
        pp = QPainter(img); pp.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        f = QFont(); f.setFamily("Menlo"); f.setBold(True); fs = 160
        f.setPixelSize(fs); fm = QFontMetrics(f)
        while fm.horizontalAdvance(text) > iw - 24 and fs > 16:
            fs -= 6; f.setPixelSize(fs); fm = QFontMetrics(f)
        pp.setFont(f); pp.setPen(QColor(255, 255, 255))
        pp.drawText(QRectF(0, 0, iw, ih), int(Qt.AlignmentFlag.AlignCenter), text)
        pp.end()
        pts = []
        for y in range(0, ih, 2):
            for x in range(0, iw, 2):
                if img.pixelColor(x, y).alpha() > 120:
                    pts.append((x, y))
        if not pts:
            return None
        random.shuffle(pts)
        pts = pts[:count]
        scale = (bs * 0.82) / iw
        ox = bs / 2.0 - (iw * scale) / 2.0
        oy = bs / 2.0 - (ih * scale) / 2.0
        return [(ox + px * scale, oy + py * scale) for (px, py) in pts]

    # ---- chat (right-side dropdown) ----
    def _build_chat(self):
        self._chat_btn = IconButton("chat", self, on_click=self.toggle_chat, pill=True)
        self._chat = QWidget(self)
        self._chat.setObjectName("chatPanel")
        self._chat.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self._chat.setStyleSheet("#chatPanel { background: rgba(8,13,24,0.97); border: 1px solid #22384f; border-radius: 12px; }")
        lay = QVBoxLayout(self._chat); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(0)
        self._scroll = QScrollArea(self._chat); self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._scroll.setStyleSheet("background: transparent; border: none;")
        host = QWidget(); host.setStyleSheet("background: transparent;")
        self._msgs = QVBoxLayout(host); self._msgs.setContentsMargins(12, 12, 12, 12)
        self._msgs.setSpacing(9); self._msgs.setAlignment(Qt.AlignmentFlag.AlignTop)
        self._scroll.setWidget(host); lay.addWidget(self._scroll, 1)
        bar = QWidget(self._chat); bar.setStyleSheet("background: transparent;")
        bl = QHBoxLayout(bar); bl.setContentsMargins(10, 10, 10, 10)
        self._input = QLineEdit(); self._input.setPlaceholderText("Message OB")
        self._input.setStyleSheet("QLineEdit { background: rgba(10,16,28,0.9); border: 1px solid #20364f; border-radius: 9px; color: #dfe9ff; padding: 10px 13px; font-size: 13px; }")
        self._input.returnPressed.connect(self._send_chat); bl.addWidget(self._input)
        lay.addWidget(bar, 0); self._chat.hide()

    @staticmethod
    def _md_to_html(text):
        import re
        s = html.escape(text or "")
        s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
        s = re.sub(r"^\s*[-*]\s+", "&bull; ", s, flags=re.MULTILINE)
        s = s.replace("\n", "<br>")
        return s

    def _add_bubble(self, role, body):
        self._mock_echo(role, body)
        row = QWidget(); row.setStyleSheet("background: transparent;")
        rl = QHBoxLayout(row); rl.setContentsMargins(0, 0, 0, 0); rl.setSpacing(0)
        if role == "sys":
            s = QLabel(body); s.setWordWrap(True); s.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            s.setStyleSheet("background: transparent; color: #5f7aa0; font-size: 11px;")
            rl.addWidget(s, 1)
            self._msgs.addWidget(row)
            QTimer.singleShot(15, lambda: self._scroll.verticalScrollBar().setValue(self._scroll.verticalScrollBar().maximum()))
            return
        bub = QLabel(); bub.setWordWrap(True)
        bub.setTextFormat(Qt.TextFormat.RichText)
        bub.setText(self._md_to_html(body))
        bub.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        bub.setMaximumWidth(300)
        if role == "user":
            bub.setStyleSheet("QLabel { background: #2f5f8e; color: #ffffff; border-radius: 13px; border-top-right-radius: 4px; padding: 9px 13px; font-size: 13px; }")
            rl.addStretch(1); rl.addWidget(bub, 0)
        else:
            bub.setStyleSheet("QLabel { background: rgba(22,34,53,0.96); color: #e7f0fb; border-radius: 13px; border-top-left-radius: 4px; padding: 9px 13px; font-size: 13px; }")
            rl.addWidget(bub, 0); rl.addStretch(1)
        self._msgs.addWidget(row)
        QTimer.singleShot(15, lambda: self._scroll.verticalScrollBar().setValue(self._scroll.verticalScrollBar().maximum()))

    def _send_chat(self):
        txt = self._input.text().strip()
        if not txt: return
        self._input.clear(); self._add_bubble("user", txt)
        if self._on_send: self._on_send(txt)

    def toggle_chat(self):
        if self._chat.isVisible():
            self._chat.hide()
        else:
            self._layout_children(); self._chat.show(); self._chat.raise_(); self._input.setFocus()

    # ---- dock (control panel: mic, settings, back-to-idle) ----
    def _build_dock(self):
        self._dock = QWidget(self)
        self._dock.setObjectName("dock")
        self._dock.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self._dock.setStyleSheet("#dock { background: rgba(12,19,32,0.85); border: 1px solid #1d3149; border-radius: 13px; }")
        dl = QHBoxLayout(self._dock); dl.setContentsMargins(10, 6, 10, 6); dl.setSpacing(5)
        self._mic_btn = IconButton("mic", self._dock, on_click=self._mute_clicked); dl.addWidget(self._mic_btn)
        dl.addWidget(IconButton("settings", self._dock, on_click=self._settings_clicked))
        dl.addWidget(IconButton("power", self._dock, on_click=self._power_clicked))

    def _mute_clicked(self):
        if self._on_mute: self._on_mute()

    def _idle_clicked(self):
        if self._mode != "orb":
            self.exit_tab()
        if self._on_idle: self._on_idle()

    def _settings_clicked(self):
        self.open_tab("setup")

    def _power_clicked(self):
        from PyQt6.QtWidgets import QApplication
        app = QApplication.instance()
        if app is not None:
            app.quit()

    # ---- tabs ----
    def register_tab(self, tid, label, icon, builder=None, center=False, web=False):
        page = QWidget(self); page.setStyleSheet("background: transparent;")
        if web:
            wv = QVBoxLayout(page); wv.setContentsMargins(0, 0, 0, 0); wv.setSpacing(0)
            body = QWidget(); body.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
            body.setStyleSheet("background: #0b0b0e;")
            bv = QVBoxLayout(body); bv.setContentsMargins(0, 0, 0, 0); bv.setSpacing(0)
            wv.addWidget(body, 1)
            if builder:
                builder(bv)
            page.hide()
            self._tabs.append({"id": tid, "label": label, "icon": icon, "center": center, "page": page})
            if not hasattr(self, "_web_tab_ids"):
                self._web_tab_ids = set()
            self._web_tab_ids.add(tid)
            return
        v = QVBoxLayout(page); v.setContentsMargins(46, 132, 46, 118); v.setSpacing(0)
        head = QWidget(); head.setStyleSheet("background: transparent;")
        hl = QHBoxLayout(head); hl.setContentsMargins(0, 0, 0, 16); hl.setSpacing(12)
        hl.addWidget(IconButton("back", head, on_click=self.exit_tab, size=34))
        t = QLabel(label.upper()); t.setStyleSheet("color: #d3e2f6; font-family: Menlo; font-size: 15px; letter-spacing: 5px; background: transparent;")
        hl.addWidget(t); hl.addStretch(1)
        esc = QLabel("ESC"); esc.setStyleSheet("color: #3c5273; font-family: Menlo; font-size: 10px; letter-spacing: 2px; background: transparent;")
        hl.addWidget(esc)
        v.addWidget(head)
        body = QWidget(); body.setStyleSheet("background: transparent;")
        bv = QVBoxLayout(body); bv.setContentsMargins(0, 0, 0, 0); bv.setSpacing(0)
        v.addWidget(body, 1)
        if builder:
            builder(bv)
        else:
            ph = QLabel(label + " — coming soon")
            ph.setStyleSheet("color: #44597a; font-family: Menlo; font-size: 14px; background: transparent;")
            ph.setAlignment(Qt.AlignmentFlag.AlignCenter)
            bv.addStretch(1); bv.addWidget(ph); bv.addStretch(2)
        page.hide()
        self._tabs.append({"id": tid, "label": label, "icon": icon, "center": center, "page": page})

    def _register_default_tabs(self):
        # OB: brain at the centre (memory), recruiting coaches on the flat ring
        self.register_tab("memory", "Memory", "brain", self._build_memory_page, center=True)
        self.register_tab("mock", "Mock Interview", "council", self._build_mock_page, web=True)
        self.register_tab("outreach", "Outreach", "outreach", self._build_outreach_page, web=True)
        self.register_tab("coffee", "Coffee Chat", "prep", self._build_prep_page, web=True)
        self.register_tab("teardown", "Company Teardown", "teardown", self._build_teardown_page, web=True)
        self.register_tab("brief", "Morning Brief", "brief", self._build_brief_page, web=True)
        self.register_tab("setup", "Setup", "system", self._build_settings_page, web=False)

    def _tab_by_id(self, tid):
        for tab in self._tabs:
            if tab["id"] == tid:
                return tab
        return self._tabs[0]

    def _ring(self):
        # OB: one flat ring of feature nodes orbiting the orb (no worlds, no centre node)
        return [t for t in self._tabs if not t.get("center")]

    def _node_pos(self, tab):
        # brain pinned at centre; everything else sits on a ring driven by _ring()
        w = self.width(); h = self.height()
        cx = w / 2.0; cy = h * 0.42; R = min(w, h) * 0.30
        if tab.get("center"):
            return (cx, cy)
        ring = self._ring()
        idx = 0
        for i, r in enumerate(ring):
            if r["id"] == tab["id"]:
                idx = i; break
        m = max(1, len(ring))
        ang = -math.pi / 2.0 + idx * (2.0 * math.pi / m)
        rr = R * 0.82
        return (cx + math.cos(ang) * rr, cy + math.sin(ang) * rr)

    def open_tab(self, tid):
        self._active_tab = tid
        if tid == "memory":
            self._populate_memory()
        elif tid == "timer":
            self._refresh_timers()
        self._mode = "zoom_in"
        self._zoom_target = 1.0
        self.setFocus()

    def exit_tab(self):
        if self._active_tab == "mock":
            self._mock_active = False
        if self._mode in ("tab", "zoom_in"):
            self._mode = "zoom_out"
            self._zoom_target = 0.0

    def _show_active_page(self):
        for tab in self._tabs:
            tab["page"].setVisible(tab["id"] == self._active_tab)
            if tab["id"] == self._active_tab:
                tab["page"].setGeometry(0, 0, self.width(), self.height())
                tab["page"].raise_()
        self._dock.raise_(); self._chat_btn.raise_()
        if self._chat.isVisible():
            self._chat.raise_()
        self._page_visible = True

    def _hide_pages(self):
        for tab in self._tabs:
            tab["page"].hide()
        self._page_visible = False

    # ---- memory tab content ----
    def _build_memory_page(self, bv):
        self._mem_scroll = QScrollArea(); self._mem_scroll.setWidgetResizable(True)
        self._mem_scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self._mem_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._mem_scroll.setStyleSheet("background: transparent; border: none;")
        mhost = QWidget(); mhost.setStyleSheet("background: transparent;")
        self._mem_list = QVBoxLayout(mhost); self._mem_list.setContentsMargins(2, 0, 10, 12)
        self._mem_list.setSpacing(3); self._mem_list.setAlignment(Qt.AlignmentFlag.AlignTop)
        self._mem_scroll.setWidget(mhost); bv.addWidget(self._mem_scroll, 1)
        addbar = QWidget(); addbar.setStyleSheet("background: transparent;")
        al = QHBoxLayout(addbar); al.setContentsMargins(0, 10, 0, 0); al.setSpacing(7)
        self._mem_input = QLineEdit(); self._mem_input.setPlaceholderText("Add something to memory")
        self._mem_input.setStyleSheet("QLineEdit { background: rgba(10,16,28,0.92); border: 1px solid #20364f; border-radius: 7px; color: #dfe9ff; padding: 9px 12px; font-family: Menlo; font-size: 13px; }")
        self._mem_input.returnPressed.connect(self._add_memory); al.addWidget(self._mem_input, 1)
        al.addWidget(IconButton("add", addbar, on_click=self._add_memory, size=34))
        bv.addWidget(addbar, 0)

    @staticmethod
    def _val(v):
        if isinstance(v, dict):
            return str(v.get("value", v))
        return str(v)

    def _populate_memory(self):
        if not hasattr(self, "_mem_list"):
            return
        while self._mem_list.count():
            it = self._mem_list.takeAt(0); w = it.widget()
            if w: w.deleteLater()
        data = _load_mem()
        order = ["identity", "preferences", "projects", "relationships", "wishes", "notes"]
        cats = order + [c for c in data.keys() if c not in order]
        shown = False
        for cat in cats:
            entries = data.get(cat)
            if not isinstance(entries, dict) or not entries:
                continue
            shown = True
            hdr = QLabel(cat.upper())
            hdr.setStyleSheet("color: #5e9be8; font-family: Menlo; font-size: 10px; letter-spacing: 2px; padding-top: 11px; background: transparent;")
            self._mem_list.addWidget(hdr)
            for key, v in entries.items():
                row = QWidget(); row.setStyleSheet("background: transparent;")
                rl = QHBoxLayout(row); rl.setContentsMargins(6, 2, 2, 2); rl.setSpacing(6)
                lbl = QLabel(); lbl.setTextFormat(Qt.TextFormat.RichText); lbl.setWordWrap(True)
                lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
                val_e = html.escape(self._val(v))
                if cat == "notes":
                    lbl.setText("<span style='color:#dbe9fb'>" + val_e + "</span>")
                else:
                    kk = html.escape(str(key).replace("_", " "))
                    lbl.setText("<span style='color:#5f7aa0'>" + kk + "</span>&nbsp;&nbsp;<span style='color:#dbe9fb'>" + val_e + "</span>")
                lbl.setStyleSheet("font-family: Menlo; font-size: 13px; background: transparent;")
                rl.addWidget(lbl, 1)
                rl.addWidget(IconButton("close", row, size=22, on_click=(lambda *a, _c=cat, _k=key: self._forget(_c, _k))), 0, Qt.AlignmentFlag.AlignTop)
                self._mem_list.addWidget(row)
        if not shown:
            empty = QLabel("Nothing yet. Add a memory below, or talk to OB.")
            empty.setStyleSheet("color: #50678a; font-family: Menlo; font-size: 13px; background: transparent; padding-top: 6px;")
            self._mem_list.addWidget(empty)

    def _forget(self, cat, key):
        data = _load_mem()
        if cat in data and isinstance(data[cat], dict) and key in data[cat]:
            del data[cat][key]
            if not data[cat]:
                del data[cat]
            _save_mem(data)
        self._populate_memory()

    def _add_memory(self):
        txt = self._mem_input.text().strip()
        if not txt:
            return
        self._mem_input.clear()
        self.add_memory_text(txt)

    def start_mock_interview(self, cfg_json):
        import json as _j
        try:
            cfg = _j.loads(cfg_json) if isinstance(cfg_json, str) else (cfg_json or {})
        except Exception:
            cfg = {}
        self._mock_active = True
        # a voice interview can't run muted - unmute so the candidate can answer
        try:
            if getattr(self, "_muted_flag", False):
                self._mute_clicked()
        except Exception:
            pass
        if self._on_mock_start:
            try:
                self._on_mock_start(cfg)
            except Exception as e:
                print("[OB] mock start err:", e)

    def end_mock_interview(self):
        # keep _mock_active True so the wrap-up assessment still echoes into the
        # transcript; it gets reset when the user leaves the tab or starts a new mock
        if self._on_send:
            self._on_send("[End the interview now. Give a brief spoken wrap-up, about 20 seconds: "
                          "one short overall verdict, then 2-3 quick specific things to improve. "
                          "Be concise and direct, do not ramble or restate everything.]")

    def _mock_echo(self, role, body):
        if not getattr(self, "_mock_active", False):
            return
        v = getattr(self, "_mock_view", None)
        if not v or role not in ("user", "assistant"):
            return
        if role == "user" and (body or "").lstrip().startswith("["):
            return  # injected system instruction, not a real candidate answer
        import json as _j
        try:
            v.page().runJavaScript(
                "if(window.mockAddLine)window.mockAddLine(" + _j.dumps(role) + "," + _j.dumps(body or "") + ");")
        except Exception:
            pass

    def add_memory_text(self, note):
        note = (note or "").strip()
        if not note:
            return
        data = _load_mem()
        notes = data.setdefault("notes", {})
        i = 1; key = "note_1"
        while key in notes:
            i += 1; key = "note_" + str(i)
        notes[key] = {"value": note}
        _save_mem(data)
        try:
            self._populate_memory()
        except Exception:
            pass

    # ---- cookbook tab ----
    def _build_cookbook_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._cb_bridge = _CookbookBridge(); self._cb_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._cb_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_COOKBOOK_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._cb_view = view

    # ---- council (agents office) tab ----
    def _build_council_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._cv_bridge = _CouncilBridge(); self._cv_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._cv_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_COUNCIL_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._cv_view = view

    # ---- outreach tab (embedded OfferBell-style web app) ----
    def _build_outreach_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView()
        view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._oa_bridge = _OutreachBridge(); self._oa_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page())
        chan.registerObject("bridge", self._oa_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_OUTREACH_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1)
        self._oa_view = view

    def _build_prep_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._prep_bridge = _PrepBridge(); self._prep_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._prep_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_PREP_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._prep_view = view

    def _build_mock_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._mock_bridge = _MockBridge(); self._mock_bridge.exitRequested.connect(self.exit_tab)
        self._mock_bridge._on_start = self.start_mock_interview
        self._mock_bridge._on_end = self.end_mock_interview
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._mock_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_MOCK_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._mock_view = view

    def _build_crm_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._crm_bridge = _CrmBridge(); self._crm_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._crm_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_CRM_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._crm_view = view

    def _build_contacts_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._contacts_bridge = _ContactsBridge(); self._contacts_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._contacts_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_CONTACTS_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._contacts_view = view

    def _build_teardown_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._td_bridge = _TeardownBridge(); self._td_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._td_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_TEARDOWN_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._td_view = view

    def _build_fdiff_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._fd_bridge = _DiffBridge(); self._fd_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._fd_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_FDIFF_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._fd_view = view

    def _build_earn_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._earn_bridge = _EarnBridge(); self._earn_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._earn_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_EARN_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._earn_view = view

    def _build_brief_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._brief_bridge = _BriefBridge(); self._brief_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._brief_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_BRIEF_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._brief_view = view

    def _build_settings_page(self, bv):
        from PyQt6.QtWidgets import QLineEdit, QPushButton, QLabel, QWidget, QVBoxLayout
        from PyQt6.QtGui import QFont
        from PyQt6.QtCore import Qt
        import json as _json
        from pathlib import Path as _P
        self._keys_path = _P(__file__).resolve().parent / "config" / "keys.json"
        try:
            cur = _json.loads(self._keys_path.read_text())
            if not isinstance(cur, dict):
                cur = {}
        except Exception:
            cur = {}

        wrap = QWidget(); wrap.setStyleSheet("background:transparent;")
        col = QVBoxLayout(wrap); col.setContentsMargins(0, 0, 0, 0); col.setSpacing(0)

        intro = QLabel("Your API keys live on this machine only. Update them here anytime.")
        intro.setWordWrap(True)
        intro.setStyleSheet("color:#8a93a3; background:transparent; font-size:13px;")
        col.addWidget(intro); col.addSpacing(22)

        def _flabel(text):
            l = QLabel(text)
            f = QFont("Menlo", 9); f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1.5)
            l.setFont(f); l.setStyleSheet("color:#6f7a8c; background:transparent;")
            return l

        _in = ("QLineEdit{background:#0a0f18;border:1px solid #243246;border-radius:10px;"
               "color:#e6edf7;padding:11px 13px;font-size:14px;}"
               "QLineEdit:focus{border:1px solid #2563eb;}")
        _saved_ph = "saved \u2014 leave blank to keep"

        sender = cur.get("sender") or {}
        col.addWidget(_flabel("ABOUT YOU \u2014 who OB is coaching")); col.addSpacing(7)
        self._set_name = QLineEdit(); self._set_name.setStyleSheet(_in)
        self._set_name.setText(sender.get("name", "")); self._set_name.setPlaceholderText("Your name")
        col.addWidget(self._set_name); col.addSpacing(10)
        self._set_school = QLineEdit(); self._set_school.setStyleSheet(_in)
        self._set_school.setText(sender.get("school", "")); self._set_school.setPlaceholderText("School & year (e.g. Ohio State, junior)")
        col.addWidget(self._set_school); col.addSpacing(10)
        self._set_target = QLineEdit(); self._set_target.setStyleSheet(_in)
        self._set_target.setText(sender.get("target", "")); self._set_target.setPlaceholderText("Target role (e.g. investment banking)")
        col.addWidget(self._set_target); col.addSpacing(24)

        col.addWidget(_flabel("GEMINI API KEY  (required)")); col.addSpacing(7)
        self._set_gemini = QLineEdit(); self._set_gemini.setEchoMode(QLineEdit.EchoMode.Password)
        self._set_gemini.setStyleSheet(_in)
        self._set_gemini.setPlaceholderText(_saved_ph if cur.get("gemini_api_key") else "AIza...")
        col.addWidget(self._set_gemini); col.addSpacing(18)

        col.addWidget(_flabel("FINNHUB API KEY  (optional \u2014 live Morning Brief)")); col.addSpacing(7)
        self._set_finnhub = QLineEdit(); self._set_finnhub.setEchoMode(QLineEdit.EchoMode.Password)
        self._set_finnhub.setStyleSheet(_in)
        self._set_finnhub.setPlaceholderText(_saved_ph if cur.get("finnhub_api_key") else "optional")
        col.addWidget(self._set_finnhub); col.addSpacing(24)

        btn = QPushButton("Save keys")
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setStyleSheet("QPushButton{background:#2563eb;color:#fff;border:0;border-radius:10px;"
                          "padding:12px 22px;font-size:14px;font-weight:600;}"
                          "QPushButton:hover{background:#1d4fd0;}")
        btn.clicked.connect(self._save_settings)
        col.addWidget(btn, 0, Qt.AlignmentFlag.AlignLeft); col.addSpacing(12)

        self._set_status = QLabel("")
        self._set_status.setStyleSheet("color:#8a93a3; background:transparent; font-size:13px;")
        col.addWidget(self._set_status)
        col.addStretch(1)
        bv.addWidget(wrap, 1)

    def _save_settings(self):
        import json as _json
        try:
            cur = _json.loads(self._keys_path.read_text())
            if not isinstance(cur, dict):
                cur = {}
        except Exception:
            cur = {}
        g = self._set_gemini.text().strip()
        f = self._set_finnhub.text().strip()
        if g:
            cur["gemini_api_key"] = g
        if f:
            cur["finnhub_api_key"] = f
        nm = self._set_name.text().strip()
        if nm:
            cur["sender"] = {
                "name": nm,
                "school": self._set_school.text().strip(),
                "year": "",
                "target": (self._set_target.text().strip() or "finance recruiting"),
            }
        try:
            self._keys_path.parent.mkdir(parents=True, exist_ok=True)
            self._keys_path.write_text(_json.dumps(cur, indent=2))
            self._set_gemini.clear(); self._set_finnhub.clear()
            self._set_gemini.setPlaceholderText("saved \u2014 leave blank to keep" if cur.get("gemini_api_key") else "AIza...")
            self._set_finnhub.setPlaceholderText("saved \u2014 leave blank to keep" if cur.get("finnhub_api_key") else "optional")
            self._set_status.setText("Saved. New keys take effect when OB next reconnects.")
        except Exception as e:
            self._set_status.setText("Couldn't save: " + str(e)[:80])

    def _build_study_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._study_bridge = _StudyBridge(); self._study_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._study_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_STUDY_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._study_view = view

    def _build_intern_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._intern_bridge = _InternBridge(); self._intern_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._intern_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_INTERN_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._intern_view = view

    def _build_notes_page(self, bv):
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebChannel import QWebChannel
        from PyQt6.QtGui import QColor
        view = QWebEngineView(); view.page().setBackgroundColor(QColor("#0b0b0e"))
        self._notes_bridge = _NotesBridge(); self._notes_bridge.exitRequested.connect(self.exit_tab)
        chan = QWebChannel(view.page()); chan.registerObject("bridge", self._notes_bridge)
        view.page().setWebChannel(chan)
        view.setHtml(_NOTES_HTML, QUrl("qrc:///"))
        bv.addWidget(view, 1); self._notes_view = view

    # ---- voice-driven actions ----
    def voice_open_tab(self, tab_id, action="", arg=""):
        """Thread-safe entry: marshal onto the GUI thread, then open + populate."""
        self.voice_request.emit(tab_id or "", action or "", arg or "")
        return True

    def _do_voice_open(self, tab_id, action="", arg=""):
        """Runs on the GUI thread: open a HUD tab and optionally fire a bridge action."""
        from PyQt6.QtCore import QTimer
        try:
            target = self._tab_by_id(tab_id)
            if not target:
                return False
            # Switch the world to the one containing this tab so back-navigation makes sense
            for w in self._WORLDS:
                if tab_id in w["tabs"]:
                    self._world = w["id"]; break
            self.open_tab(tab_id)
            if not action:
                return True

            def _fire():
                import json as _json
                a = (arg or "")

                def esc(s):
                    return _json.dumps(str(s))

                try:
                    if tab_id == "brief" and action == "run":
                        self._brief_view.page().runJavaScript("if(typeof run==='function')run();")
                    elif tab_id == "earn" and action == "ticker":
                        self._earn_view.page().runJavaScript(
                            "var e=document.getElementById('tk');if(e){e.value=" + esc(a.upper()) + ";run();}")
                    elif tab_id == "teardown" and action == "ticker":
                        self._td_view.page().runJavaScript(
                            "var e=document.getElementById('tk');if(e){e.value=" + esc(a.upper()) + ";run();}")
                    elif tab_id == "fdiff" and action == "ticker":
                        self._fd_view.page().runJavaScript(
                            "var e=document.getElementById('tk');if(e){e.value=" + esc(a.upper()) + ";run();}")
                    elif tab_id == "study" and action == "source":
                        self._study_view.page().runJavaScript(
                            "var e=document.getElementById('src');if(e){e.value=" + esc(a) + ";go();}")
                    elif tab_id in ("prep", "coffee") and action == "url":
                        self._prep_view.page().runJavaScript(
                            "var u=document.getElementById('url');if(u)u.value=" + esc(a) + ";"
                            "if(typeof run==='function')run();")
                    elif tab_id == "outreach" and action == "draft":
                        try:
                            d = _json.loads(a) if a.strip().startswith("{") else {"url": a, "angle": "intro", "context": ""}
                        except Exception:
                            d = {"url": a, "angle": "intro", "context": ""}
                        js = ("var u=document.getElementById('url');if(u)u.value=" + esc(d.get("url", "")) + ";"
                              "var c=document.getElementById('context');if(c)c.value=" + esc(d.get("context", "")) + ";"
                              "if(typeof pick==='function')pick(" + esc(d.get("angle", "intro")) + ");"
                              "if(typeof run==='function')run();")
                        self._oa_view.page().runJavaScript(js)
                    elif tab_id == "intern" and action == "checkin":
                        items = _hud_store_load("interns")
                        ql = a.lower().strip()
                        match = None
                        for it in items:
                            nm = (it.get("name") or "").lower()
                            if nm and (ql == nm or ql in nm or nm.split()[0] == ql.split()[0]):
                                match = it
                                break
                        if match:
                            self._intern_bridge.draftCheckin(match.get("id"))
                except Exception as _e:
                    print("[voice] fire error:", _e)

            # Let the tab mount + zoom settle, then drive its own run() so the spinner shows
            QTimer.singleShot(650, _fire)
            return True
        except Exception as e:
            print("[voice] voice_open_tab error:", e)
            return False

    # ---- events ----
    def showEvent(self, e):
        super().showEvent(e)
        self._mode = "orb"; self._zoom = 0.0; self._zoom_target = 0.0
        self._active_tab = None; self._world = None; self._hide_pages()
        self._hover_nodes = 0.0; self._hover_target = 0.0; self._hover_tab = None

    def keyPressEvent(self, e):
        if e.key() == Qt.Key.Key_Escape and self._mode in ("tab", "zoom_in"):
            self.exit_tab(); return
        super().keyPressEvent(e)

    def leaveEvent(self, _e):
        self._hover_target = 0.0; self._hover_tab = None

    def mouseMoveEvent(self, e):
        if self._mode == "orb":
            pos = e.position()
            w = self.width(); h = self.height()
            cx = w / 2.0; cy = h * 0.42; R = min(w, h) * 0.30
            self._hover_target = 1.0 if math.hypot(pos.x() - cx, pos.y() - cy) < R * 1.25 else 0.0
            self._hover_tab = None
            if self._hover_target > 0:
                bd = 30.0; best = None
                for tab in self._ring() + [self._tab_by_id("memory")]:
                    nx, ny = self._node_pos(tab)
                    dd = math.hypot(pos.x() - nx, pos.y() - ny)
                    if dd < bd:
                        bd = dd; best = tab["id"]
                self._hover_tab = best
        super().mouseMoveEvent(e)

    def mousePressEvent(self, e):
        if self._mode == "orb" and self._hover_nodes > 0.4:
            pos = e.position()
            for item in self._ring() + [self._tab_by_id("memory")]:
                nx, ny = self._node_pos(item)
                if math.hypot(pos.x() - nx, pos.y() - ny) < 30.0:
                    if item.get("world"):
                        self._world = item["world"]; self._hover_tab = None; self._hover_target = 0.0
                        self.update(); return
                    if item.get("back"):
                        self._world = None; self._hover_tab = None; self._hover_target = 0.0
                        self.update(); return
                    self.open_tab(item["id"]); return
        super().mousePressEvent(e)

    # ---- layout / paint ----
    def resizeEvent(self, e):
        super().resizeEvent(e); self._grid = None; self._recompute(); self._layout_children()

    def _recompute(self):
        w = self.width(); h = self.height()
        # render resolution is capped for performance; the on-screen size is
        # decoupled so the orb stays large but the per-frame cost stays bounded
        self._buf_size = min(560, max(160, int(min(w, h) * 0.6)))
        self._buf = None
        half = int(min(w, h) * 0.36)
        cx = int(w / 2.0); cy = int(h * 0.42)
        self._orb_rect = QRect(cx - half, cy - half, half * 2, half * 2)

    def _layout_children(self):
        w = self.width(); h = self.height()
        self._dock.adjustSize()
        dw = self._dock.width(); dh = self._dock.height()
        self._dock.move(int((w - dw) / 2), int(h - dh - 24))
        self._chat_btn.move(w - self._chat_btn.width() - 28, 26)
        cw = min(390, int(w * 0.4)); ch = min(480, int(h * 0.6))
        self._chat.setGeometry(w - cw - 28, 26 + self._chat_btn.height() + 8, cw, ch)
        for tab in self._tabs:
            tab["page"].setGeometry(0, 0, w, h)

    # ---- timer tab content (painted console: timer + stopwatch) ----
    def _build_timer_page(self, bv):
        try:
            page = bv.parentWidget().parentWidget()
            page.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
            page.setStyleSheet("background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #0f1a2e, stop:0.5 #0a0f20, stop:1 #060912);")
        except Exception:
            pass
        wrap = QWidget(); wrap.setStyleSheet("background: transparent;")
        hl = QHBoxLayout(wrap); hl.setContentsMargins(40, 16, 40, 28); hl.setSpacing(30)

        canvas = TimerCanvas(self._tc_state, self._center_tap)
        self._timer_canvas = canvas
        hl.addWidget(canvas, 5)

        panel = QWidget(); panel.setObjectName("tpanel"); panel.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        panel.setStyleSheet("#tpanel { background: rgba(13,22,40,0.6); border: 1px solid #21384f; border-radius: 20px; }")
        pv = QVBoxLayout(panel); pv.setContentsMargins(28, 24, 28, 26); pv.setSpacing(18)

        mrow = QWidget(); mrow.setStyleSheet("background: transparent;")
        ml = QHBoxLayout(mrow); ml.setContentsMargins(0, 0, 0, 0); ml.setSpacing(0)
        seg = QWidget(); seg.setObjectName("seg"); seg.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        seg.setStyleSheet("#seg { background: rgba(9,15,28,0.8); border: 1px solid #25405c; border-radius: 11px; }")
        sl = QHBoxLayout(seg); sl.setContentsMargins(3, 3, 3, 3); sl.setSpacing(3)
        self._mode_btn_timer = QPushButton("TIMER"); self._mode_btn_timer.setCursor(Qt.CursorShape.PointingHandCursor)
        self._mode_btn_timer.clicked.connect(lambda *a: self._set_mode("timer"))
        self._mode_btn_sw = QPushButton("STOPWATCH"); self._mode_btn_sw.setCursor(Qt.CursorShape.PointingHandCursor)
        self._mode_btn_sw.clicked.connect(lambda *a: self._set_mode("stopwatch"))
        sl.addWidget(self._mode_btn_timer); sl.addWidget(self._mode_btn_sw)
        ml.addWidget(seg); ml.addStretch(1)
        pv.addWidget(mrow, 0)

        self._timer_body = QWidget(); self._timer_body.setStyleSheet("background: transparent;")
        self._timer_body_l = QVBoxLayout(self._timer_body)
        self._timer_body_l.setContentsMargins(0, 0, 0, 0); self._timer_body_l.setSpacing(13)
        self._timer_body_l.setAlignment(Qt.AlignmentFlag.AlignTop)
        pv.addWidget(self._timer_body, 1)

        hl.addWidget(panel, 4)
        bv.addWidget(wrap, 1)
        self._timer_pills = {}
        self._refresh_timers()

    @staticmethod
    def _tile_css():
        return ("QPushButton { background: rgba(20,32,52,0.65); border: 1px solid #284b6a; border-radius: 14px; color: #cfe0f5; font-size: 15px; padding: 18px 0; }"
                " QPushButton:hover { border-color: #3f9ae0; color: #ffffff; background: rgba(28,46,72,0.8); }")

    @staticmethod
    def _hdr_css():
        return "color: #5f7aa0; background: transparent; font-size: 11px; letter-spacing: 2px;"

    def _build_timer_body(self):
        bar = QWidget(); bar.setStyleSheet("background: transparent;")
        bl = QHBoxLayout(bar); bl.setContentsMargins(0, 0, 0, 0); bl.setSpacing(8)
        self._timer_input = QLineEdit(); self._timer_input.setPlaceholderText("5m, 1:30, 90s, 1h")
        self._timer_input.setStyleSheet("QLineEdit { background: rgba(9,15,28,0.7); border: 1px solid #223a55; border-radius: 11px; color: #e7f0fb; padding: 11px 15px; font-size: 14px; }")
        self._timer_input.returnPressed.connect(self._start_from_input)
        bl.addWidget(self._timer_input, 1)
        stb = QPushButton("Start"); stb.setCursor(Qt.CursorShape.PointingHandCursor)
        stb.setStyleSheet(self._pill_css(accent=True)); stb.clicked.connect(self._start_from_input)
        bl.addWidget(stb)
        self._timer_body_l.addWidget(bar, 0)

        gw = QWidget(); gw.setStyleSheet("background: transparent;")
        gg = QGridLayout(gw); gg.setContentsMargins(0, 2, 0, 2); gg.setSpacing(10)
        for idx, (lab, secs) in enumerate((("1 min", 60), ("5 min", 300), ("10 min", 600), ("25 min", 1500))):
            tile = QPushButton(lab); tile.setCursor(Qt.CursorShape.PointingHandCursor)
            tile.setStyleSheet(self._tile_css())
            tile.clicked.connect(lambda *a, _s=secs: self._start_timer_seconds(_s, ""))
            gg.addWidget(tile, idx // 2, idx % 2)
        self._timer_body_l.addWidget(gw, 0)

        hdr = QLabel("ACTIVE TIMERS"); hdr.setStyleSheet(self._hdr_css())
        self._timer_body_l.addWidget(hdr, 0)
        if not self._timers:
            none = QLabel("Nothing running yet."); none.setStyleSheet("color: #4d678f; background: transparent; font-size: 13px;")
            self._timer_body_l.addWidget(none, 0)
            self._timer_body_l.addStretch(1)
            return
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")
        host = QWidget(); host.setStyleSheet("background: transparent;")
        rv = QVBoxLayout(host); rv.setContentsMargins(0, 0, 0, 0); rv.setSpacing(9); rv.setAlignment(Qt.AlignmentFlag.AlignTop)
        for t in self._timers:
            rv.addWidget(self._timer_row(t))
        scroll.setWidget(host); self._timer_body_l.addWidget(scroll, 1)

    def _timer_row(self, t):
        done = t["done"]
        card = QWidget(); card.setObjectName("trow"); card.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        card.setStyleSheet("#trow { background: rgba(18,30,50,0.55); border: 1px solid %s; border-radius: 12px; }" % ("#caa23f" if done else "#223a55"))
        hb = QHBoxLayout(card); hb.setContentsMargins(15, 10, 11, 10); hb.setSpacing(10)
        left = QWidget(); left.setStyleSheet("background: transparent;")
        lv = QVBoxLayout(left); lv.setContentsMargins(0, 0, 0, 0); lv.setSpacing(1)
        tl = QLabel("DONE" if done else self._fmt_time(t["remaining"]))
        tf = QFont(); tf.setPointSize(21); tf.setWeight(QFont.Weight.DemiBold); tl.setFont(tf)
        tl.setStyleSheet("color: %s; background: transparent;" % ("#ffe1a6" if done else "#eef5ff"))
        lv.addWidget(tl)
        ll = QLabel(t["label"] or "Timer"); ll.setStyleSheet("color: #7f9bc0; background: transparent; font-size: 12px;")
        lv.addWidget(ll)
        hb.addWidget(left, 1)
        if not done:
            self._timer_pills[t["id"]] = tl
            pb = QPushButton("Pause" if t["running"] else "Resume"); pb.setCursor(Qt.CursorShape.PointingHandCursor)
            pb.setStyleSheet(self._pill_css()); pb.clicked.connect(lambda *a, _id=t["id"]: self._toggle_timer(_id))
            hb.addWidget(pb)
        cb = QPushButton("Dismiss" if done else "Cancel"); cb.setCursor(Qt.CursorShape.PointingHandCursor)
        cb.setStyleSheet(self._pill_css(danger=not done)); cb.clicked.connect(lambda *a, _id=t["id"]: self._cancel_timer(_id))
        hb.addWidget(cb)
        return card

    def _build_sw_body(self):
        row = QWidget(); row.setStyleSheet("background: transparent;")
        rl = QHBoxLayout(row); rl.setContentsMargins(0, 0, 0, 0); rl.setSpacing(9)
        sb = QPushButton("Pause" if self._sw["running"] else ("Resume" if self._sw["elapsed"] > 0 else "Start"))
        sb.setCursor(Qt.CursorShape.PointingHandCursor); sb.setStyleSheet(self._pill_css(accent=not self._sw["running"]))
        sb.clicked.connect(lambda *a: self._sw_toggle()); rl.addWidget(sb, 1)
        if self._sw["running"]:
            lb = QPushButton("Lap"); lb.setCursor(Qt.CursorShape.PointingHandCursor); lb.setStyleSheet(self._pill_css())
            lb.clicked.connect(lambda *a: self._sw_lap()); rl.addWidget(lb)
        rb = QPushButton("Reset"); rb.setCursor(Qt.CursorShape.PointingHandCursor); rb.setStyleSheet(self._pill_css())
        rb.clicked.connect(lambda *a: self._sw_reset()); rl.addWidget(rb)
        self._timer_body_l.addWidget(row, 0)

        hdr = QLabel("LAPS"); hdr.setStyleSheet(self._hdr_css())
        self._timer_body_l.addWidget(hdr, 0)
        laps = self._sw["laps"]
        if not laps:
            none = QLabel("Hit Lap while running to record splits."); none.setStyleSheet("color: #4d678f; background: transparent; font-size: 13px;")
            self._timer_body_l.addWidget(none, 0)
            self._timer_body_l.addStretch(1)
            return
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background: transparent; border: none;")
        host = QWidget(); host.setStyleSheet("background: transparent;")
        lv = QVBoxLayout(host); lv.setContentsMargins(0, 0, 0, 0); lv.setSpacing(6); lv.setAlignment(Qt.AlignmentFlag.AlignTop)
        p0 = 0.0; splits = []
        for i, lp in enumerate(laps):
            splits.append((i + 1, lp - p0, lp)); p0 = lp
        for n, sp, tot in reversed(splits):
            r = QWidget(); r.setObjectName("lrow"); r.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
            r.setStyleSheet("#lrow { background: rgba(16,30,30,0.5); border: 1px solid #234c47; border-radius: 10px; }")
            rh = QHBoxLayout(r); rh.setContentsMargins(14, 8, 14, 8); rh.setSpacing(8)
            a = QLabel("Lap %d" % n); a.setStyleSheet("color: #8fd6c8; background: transparent; font-size: 13px;")
            b = QLabel("+" + TimerCanvas._fmt_sw(sp)); b.setStyleSheet("color: #e7f0fb; background: transparent; font-size: 13px;")
            c = QLabel(TimerCanvas._fmt_sw(tot)); c.setStyleSheet("color: #6f8bb0; background: transparent; font-size: 12px;")
            rh.addWidget(a); rh.addStretch(1); rh.addWidget(b); rh.addSpacing(14); rh.addWidget(c)
            lv.addWidget(r)
        scroll.setWidget(host); self._timer_body_l.addWidget(scroll, 1)

    def _chip_css():
        return ("QPushButton { background: rgba(17,28,45,0.7); border: 1px solid #25405c; border-radius: 16px; color: #bcd4f0; font-size: 13px; padding: 8px 16px; }"
                " QPushButton:hover { border-color: #3f9ae0; color: #eaf3ff; }")

    @staticmethod
    def _mode_css(active):
        if active:
            return "QPushButton { background: #2c5f96; border: none; border-radius: 8px; color: #eaf3ff; font-size: 12px; letter-spacing: 2px; padding: 8px 22px; }"
        return ("QPushButton { background: transparent; border: none; border-radius: 8px; color: #89a4c6; font-size: 12px; letter-spacing: 2px; padding: 8px 22px; }"
                " QPushButton:hover { color: #eaf3ff; }")

    @staticmethod
    def _pill_css(danger=False, accent=False):
        if accent:
            return ("QPushButton { background: #2c5f96; border: none; border-radius: 10px; color: #eaf3ff; font-size: 13px; padding: 11px 22px; }"
                    " QPushButton:hover { background: #3672ad; }")
        border = "#6a3d49" if danger else "#27405c"
        txt = "#e0aab4" if danger else "#bcd4f0"
        hover = "#b06576" if danger else "#3f9ae0"
        return ("QPushButton { background: rgba(18,28,44,0.7); border: 1px solid %s; border-radius: 10px; color: %s; font-size: 13px; padding: 9px 20px; }"
                " QPushButton:hover { border-color: %s; color: #ffffff; }") % (border, txt, hover)

    @staticmethod
    def _fmt_time(rem):
        return TimerCanvas._fmt(rem)

    def _tc_state(self):
        if getattr(self, "_timer_mode", "timer") == "stopwatch":
            return {"mode": "stopwatch", "elapsed": self._sw["elapsed"], "running": self._sw["running"], "laps": self._sw["laps"]}
        return {"mode": "timer", "primary": self._primary_timer(), "pulse": getattr(self, "_timer_pulse", 0.0)}

    def _center_tap(self):
        if getattr(self, "_timer_mode", "timer") == "stopwatch":
            self._sw_toggle()
        else:
            self._toggle_primary()

    def _set_mode(self, m):
        if m == getattr(self, "_timer_mode", "timer"):
            return
        self._timer_mode = m
        self._refresh_timers()
        if hasattr(self, "_timer_canvas"):
            self._timer_canvas.update()

    def _sw_toggle(self):
        self._sw["running"] = not self._sw["running"]
        if self._sw["running"]:
            self._ensure_timer_tick()
        self._refresh_timers()

    def _sw_lap(self):
        if self._sw["running"]:
            self._sw["laps"].append(self._sw["elapsed"])
            self._refresh_timers()

    def _sw_reset(self):
        self._sw["elapsed"] = 0.0; self._sw["running"] = False; self._sw["laps"] = []
        self._refresh_timers()
        if not self._timers and not self._sw["running"]:
            self._timer_tick.stop()

    def _primary_timer(self):
        done = [t for t in self._timers if t["done"]]
        if done:
            return done[-1]
        running = [t for t in self._timers if not t["done"]]
        if running:
            return min(running, key=lambda x: x["remaining"])
        return None

    def _primary_state(self):
        return self._primary_timer(), getattr(self, "_timer_pulse", 0.0)

    def _toggle_primary(self):
        t = self._primary_timer()
        if t is not None and not t["done"]:
            t["running"] = not t["running"]
            self._refresh_timers()

    def _refresh_timers(self):
        if not hasattr(self, "_timer_body_l") or not hasattr(self, "_timers"):
            return
        mode = getattr(self, "_timer_mode", "timer")
        if hasattr(self, "_mode_btn_timer"):
            self._mode_btn_timer.setStyleSheet(self._mode_css(mode == "timer"))
            self._mode_btn_sw.setStyleSheet(self._mode_css(mode == "stopwatch"))
        self._timer_pills = {}
        while self._timer_body_l.count():
            it = self._timer_body_l.takeAt(0); w = it.widget()
            if w: w.deleteLater()
        if mode == "stopwatch":
            self._build_sw_body()
        else:
            self._build_timer_body()
        if hasattr(self, "_timer_canvas"):
            self._timer_canvas.update()
    def _ensure_timer_tick(self):
        import time
        if not self._timer_tick.isActive():
            self._timer_last = time.monotonic()
            self._timer_tick.start(100)

    def _tick_timers(self):
        import time
        now = time.monotonic(); dt = now - getattr(self, "_timer_last", now); self._timer_last = now
        if dt > 2.0:
            dt = 0.1
        self._timer_pulse = getattr(self, "_timer_pulse", 0.0) + dt * 4.0
        newly_done = False
        for t in self._timers:
            if t["running"] and not t["done"]:
                t["remaining"] -= dt
                if t["remaining"] <= 0:
                    t["remaining"] = 0.0; t["done"] = True; t["running"] = False
                    self._on_timer_done(t); newly_done = True
        if self._sw["running"]:
            self._sw["elapsed"] += dt
        vis = (getattr(self, "_active_tab", None) == "timer" and getattr(self, "_page_visible", False))
        if vis:
            if hasattr(self, "_timer_canvas"):
                self._timer_canvas.update()
            for tid, lbl in list(getattr(self, "_timer_pills", {}).items()):
                tt = next((x for x in self._timers if x["id"] == tid), None)
                if tt is not None:
                    try:
                        lbl.setText(self._fmt_time(tt["remaining"]))
                    except RuntimeError:
                        pass
            if newly_done:
                self._refresh_timers()
        self._refresh_toast()
        if not self._timers and not self._sw["running"]:
            self._timer_tick.stop()

    def _play_alarm(self):
        import subprocess, sys
        self._stop_alarm()
        try:
            if sys.platform == "darwin":
                self._alarm_proc = subprocess.Popen(
                    ["/bin/sh", "-c", "for i in $(seq 1 25); do afplay /System/Library/Sounds/Glass.aiff; done"],
                    start_new_session=True)
                return
        except Exception:
            pass
        try:
            QApplication.beep()
        except Exception:
            pass

    def _stop_alarm(self):
        p = getattr(self, "_alarm_proc", None)
        if p is not None:
            try:
                import os, signal
                os.killpg(os.getpgid(p.pid), signal.SIGTERM)
            except Exception:
                try: p.terminate()
                except Exception: pass
        self._alarm_proc = None

    def _set_toast(self, text, kind):
        if not hasattr(self, "_toast"):
            return
        if kind != self._toast_kind:
            if kind == "done":
                self._toast.setStyleSheet("#toast { background: rgba(58,44,12,0.97); border: 1px solid #d6a13a; border-radius: 13px; }")
                self._toast_lbl.setStyleSheet("background: transparent; color: #ffe6ab; font-size: 14px;")
            else:
                self._toast.setStyleSheet("#toast { background: rgba(13,28,48,0.97); border: 1px solid #2f6fae; border-radius: 13px; }")
                self._toast_lbl.setStyleSheet("background: transparent; color: #dcecff; font-size: 14px;")
            self._toast_kind = kind
        if self._toast_lbl.text() != text:
            self._toast_lbl.setText(text)
        self._toast.adjustSize()
        self._toast.move(int((self.width() - self._toast.width()) / 2), 78)
        if not self._toast.isVisible():
            self._toast.show()
        self._toast.raise_()

    def _refresh_toast(self):
        if not hasattr(self, "_toast"):
            return
        if getattr(self, "_toast_dismissed", False):
            self._toast.hide(); return
        done = [t for t in self._timers if t["done"]]
        running = [t for t in self._timers if not t["done"]]
        if done:
            t = done[-1]
            self._set_toast("Timer done  -  " + (t["label"] or "Timer"), "done")
        elif running:
            t = min(running, key=lambda x: x["remaining"])
            self._set_toast("Timer  -  " + self._fmt_time(t["remaining"]) + ((" - " + t["label"]) if t["label"] else ""), "info")
        else:
            self._toast.hide()

    def _dismiss_toast(self):
        self._stop_alarm()
        if self._toast_kind == "done":
            self._timers = [t for t in self._timers if not t["done"]]
            self._toast_dismissed = False
            if getattr(self, "_active_tab", None) == "timer" and getattr(self, "_page_visible", False):
                self._refresh_timers()
            self._refresh_toast()
            if not self._timers and not self._sw["running"]:
                self._timer_tick.stop()
        else:
            self._toast_dismissed = True
            self._toast.hide()

    def _on_timer_done(self, t):
        self._play_alarm()
        self._toast_dismissed = False
        self._refresh_toast()
        lab = "".join(ch for ch in (t["label"] or "") if ch.isalnum())[:8].upper() or "TIME"
        try:
            self.constellate(lab)
        except Exception:
            pass
        if getattr(self, "_active_tab", None) == "timer" and getattr(self, "_page_visible", False):
            self._refresh_timers()

    def _toggle_timer(self, tid):
        for t in self._timers:
            if t["id"] == tid and not t["done"]:
                t["running"] = not t["running"]
        self._refresh_timers()

    def _cancel_timer(self, tid):
        self._timers = [t for t in self._timers if t["id"] != tid]
        if not any(t["done"] for t in self._timers):
            self._stop_alarm()
        self._refresh_toast()
        self._refresh_timers()
        if not self._timers and not self._sw["running"]:
            self._timer_tick.stop()

    def _start_timer_seconds(self, secs, label=""):
        self._do_add_timer(int(secs), label)

    def _start_from_input(self):
        if not hasattr(self, "_timer_input"):
            return
        secs = self._parse_duration(self._timer_input.text())
        if secs and secs > 0:
            self._timer_input.clear()
            self._do_add_timer(int(secs), "")

    @staticmethod
    def _parse_duration(text):
        import re
        s = (text or "").strip().lower()
        if not s:
            return None
        if ":" in s:
            try:
                nums = [int(p) for p in s.split(":")]
            except ValueError:
                return None
            if len(nums) == 2:
                return nums[0] * 60 + nums[1]
            if len(nums) == 3:
                return nums[0] * 3600 + nums[1] * 60 + nums[2]
            return None
        total = 0; found = False
        for val, unit in re.findall(r"(\d+)\s*([hms])", s):
            found = True; v = int(val)
            total += v * 3600 if unit == "h" else v * 60 if unit == "m" else v
        if found:
            return total
        if s.isdigit():
            return int(s) * 60
        return None

    def add_timer(self, seconds, label=""):
        """Thread-safe entry point (e.g. from OB voice on the audio thread)."""
        try:
            self.timer_request.emit(int(max(1, seconds)), str(label or ""))
        except Exception:
            pass

    def _do_add_timer(self, seconds, label=""):
        self._timer_seq += 1
        self._timers.append({
            "id": self._timer_seq, "label": label or "",
            "total": float(seconds), "remaining": float(seconds),
            "running": True, "done": False,
        })
        self._timer_mode = "timer"
        self._ensure_timer_tick()
        self._toast_dismissed = False
        self._refresh_toast()
        if getattr(self, "_active_tab", None) == "timer" and getattr(self, "_page_visible", False):
            self._refresh_timers()

    def _build_grid(self):
        w = self.width(); h = self.height()
        pix = QPixmap(max(1, w), max(1, h)); pix.fill(QColor(4, 6, 12))
        gp = QPainter(pix); pen = QPen(QColor(60, 110, 180, 16)); pen.setWidthF(1.0); gp.setPen(pen)
        step = 40; x = 0
        while x <= w:
            gp.drawLine(x, 0, x, h); x += step
        y = 0
        while y <= h:
            gp.drawLine(0, y, w, y); y += step
        gp.end(); self._grid = pix
    def _adv(self):
        self._t += 0.012
        spk = (self._state == "SPEAKING")
        self._spkf += ((1.0 if spk else 0.0) - self._spkf) * 0.10
        tp = self._params.get(self._state, self._params["LISTENING"])
        for i in range(len(self._pvals)):
            self._pvals[i] += (tp[i] - self._pvals[i]) * 0.10
        self._rot += 0.012 * self._pvals[0]
        self._tphase += 0.012 * (2.0 + 2.5 * self._spkf)
        for n in self._nodes:
            n[3] += 0.035 + 0.05 * self._spkf
        target = 1.0 if self._state == "THINKING" else 0.0
        self._morph += (target - self._morph) * 0.08
        self._constel += (self._constel_target - self._constel) * 0.12
        self._hover_nodes += (self._hover_target - self._hover_nodes) * 0.22
        if self._mode in ("zoom_in", "zoom_out", "tab"):
            self._zoom += (self._zoom_target - self._zoom) * 0.30
            if self._mode == "zoom_in":
                if self._zoom > 0.5 and not self._page_visible:
                    self._show_active_page()
                if self._zoom > 0.97:
                    self._zoom = 1.0; self._mode = "tab"
            elif self._mode == "zoom_out":
                if self._zoom < 0.5 and self._page_visible:
                    self._hide_pages()
                if self._zoom < 0.04:
                    self._zoom = 0.0; self._mode = "orb"; self._active_tab = None
                    self.update()  # full repaint so the background grid comes back
                    return
        if self._mode == "tab":
            # When a WEB tab is open its view covers the orb fully, so repainting the
            # animated orb behind it every frame just fights the web view and causes
            # scroll/mouse jank. Skip it. (Native tabs like Timer still repaint.)
            if getattr(self, "_page_visible", False) and self._active_tab in getattr(self, "_web_tab_ids", set()):
                return
            self.update()
        elif self._mode in ("zoom_in", "zoom_out"):
            self.update()
        else:
            self.update(self._orb_rect)

    def paintEvent(self, e):
        if self._grid is None or self._grid.width() != self.width() or self._grid.height() != self.height():
            self._build_grid()
        p = QPainter(self)
        if self._mode == "orb":
            r = e.rect(); p.drawPixmap(r, self._grid, r)
        elif self._mode == "tab":
            p.drawPixmap(self.rect(), self._grid, self.rect())
        else:  # zoom transition: cheap solid fill instead of full-screen grid blit
            p.fillRect(self.rect(), QColor(4, 6, 12))
        self._render_orb()
        if self._buf is not None:
            bw = self._buf.width(); bh = self._buf.height()
            half = self._orb_rect.width() / 2
            cx0 = self.width() / 2.0; cy0 = self.height() * 0.42
            if self._mode == "orb":
                p.drawPixmap(QRectF(cx0 - half, cy0 - half, half * 2, half * 2), self._buf, QRectF(0, 0, bw, bh))
                self._paint_nodes(p)
                self._paint_chrome(p)
            elif self._mode in ("zoom_in", "zoom_out"):
                z = self._zoom; scale = 1.0 + z * 2.4
                tx, ty = self._node_pos(self._tab_by_id(self._active_tab))
                p.save()
                p.translate(tx, ty); p.scale(scale, scale); p.translate(-tx, -ty)
                p.setOpacity(max(0.0, 1.0 - z * 1.4))
                p.drawPixmap(QRectF(cx0 - half, cy0 - half, half * 2, half * 2), self._buf, QRectF(0, 0, bw, bh))
                p.restore(); p.setOpacity(1.0)
            else:  # tab — mini orb top-left
                ms = 84.0; mx = 74.0; my = 74.0
                p.drawPixmap(QRectF(mx - ms / 2, my - ms / 2, ms, ms), self._buf, QRectF(0, 0, bw, bh))
        p.end()

    def _paint_chrome(self, p):
        # OfferBell branding + onboarding cues painted over the orb home
        w = self.width(); h = self.height()
        cx = w / 2.0; cy = h * 0.42; R = min(w, h) * 0.30

        # wordmark (top-left): OB + "an OfferBell product"
        f = QFont("Georgia"); f.setPointSize(25)
        p.setFont(f); p.setPen(QColor(216, 230, 250, 235))
        p.drawText(QRectF(42, 30, 220, 38),
                   int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), "OB")
        ft = QFont("Helvetica Neue"); ft.setPointSize(9)
        ft.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 2.2)
        p.setFont(ft); p.setPen(QColor(118, 150, 202, 185))
        p.drawText(QRectF(43, 65, 300, 18),
                   int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), "AN OFFERBELL PRODUCT")

        # greeting removed per request

        # OfferBell credit below the orb
        fh = QFont("Helvetica Neue"); fh.setPointSize(11)
        fh.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 0.6)
        p.setFont(fh); p.setPen(QColor(120, 150, 198, 175))
        p.drawText(QRectF(cx - 360, cy + R + 26, 720, 22),
                   int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter),
                   "Brought to you by OfferBell")

    def _paint_nodes(self, p):
        if self._hover_nodes <= 0.01:
            return
        a = max(0.0, min(1.0, self._hover_nodes))
        brain = self._tab_by_id("memory")
        bx, by = self._node_pos(brain)  # brain at orb centre = synapse hub
        ring = self._ring()
        # synapse lines + pulses firing inward toward the brain
        for i, tab in enumerate(ring):
            x, y = self._node_pos(tab)
            hov = (self._hover_tab == tab["id"])
            pen = QPen(QColor(96, 150, 220, int((150 if hov else 52) * a)))
            pen.setWidthF(1.4 if hov else 1.0)
            p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawLine(QPointF(x, y), QPointF(bx, by))
            speed = 0.85 if hov else 0.5
            p.setPen(Qt.PenStyle.NoPen)
            for k in range(2):
                frac = (self._t * speed + i * 0.31 + k * 0.5) % 1.0
                px = x + (bx - x) * frac; py = y + (by - y) * frac
                pr = 3.6 if hov else 2.6
                pa = int((230 if hov else 150) * a * (0.35 + 0.65 * math.sin(frac * math.pi)))
                gg = QRadialGradient(px, py, pr * 2.2)
                gg.setColorAt(0.0, QColor(195, 222, 255, pa)); gg.setColorAt(1.0, QColor(195, 222, 255, 0))
                p.setBrush(gg); p.drawEllipse(QPointF(px, py), pr * 2.2, pr * 2.2)
                p.setBrush(QColor(228, 242, 255, pa)); p.drawEllipse(QPointF(px, py), pr, pr)
        # node discs + glyphs (brain drawn last so it sits on top at the centre)
        for tab in ring + [brain]:
            x, y = self._node_pos(tab)
            hov = (self._hover_tab == tab["id"])
            r = 22.0 if hov else 18.0
            g = QRadialGradient(x, y, r * 1.7)
            g.setColorAt(0.0, QColor(150, 195, 255, int((95 if hov else 55) * a)))
            g.setColorAt(1.0, QColor(150, 195, 255, 0))
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(g)
            p.drawEllipse(QPointF(x, y), r * 1.7, r * 1.7)
            p.setBrush(QColor(12, 20, 34, int(225 * a)))
            p.setPen(QPen(QColor(60, 110, 170, int(210 * a)), 1.0))
            p.drawEllipse(QPointF(x, y), r, r)
            col = QColor(226, 240, 255, int(255 * a)) if hov else QColor(176, 210, 250, int(235 * a))
            paint_glyph(p, tab["icon"], x, y, r * 1.18, col, 1.8)
            if hov:
                f = QFont(); f.setFamily("Menlo"); f.setPointSize(10); p.setFont(f)
                p.setPen(QColor(210, 226, 246, int(255 * a)))
                p.drawText(QRectF(x - 70, y + r + 6, 140, 16),
                           int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop), tab["label"])

    def _render_orb(self):
        bs = getattr(self, "_buf_size", 0)
        if bs <= 0:
            return
        if self._buf is None or self._buf.width() != bs:
            self._buf = QPixmap(bs, bs)
        self._buf.fill(QColor(0, 0, 0, 0))
        p = QPainter(self._buf); p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        sp, amp, bright, thrf, linkf = self._pvals
        t = self._t; cx = bs / 2.0; cy = bs / 2.0; Rb = bs * 0.30; m = self._morph
        throb = 1.0 + math.sin(self._tphase) * (0.012 + 0.138 * self._spkf)
        if self._state == "MUTED":
            c_glow = (120, 30, 30); c_link = (235, 140, 140); c_halo = (210, 110, 110); c_core = (255, 205, 205)
        else:
            c_glow = (40, 80, 150); c_link = (200, 222, 255); c_halo = (150, 195, 255); c_core = (236, 245, 255)
        glow = QRadialGradient(cx, cy, Rb * 1.5)
        glow.setColorAt(0.0, QColor(c_glow[0], c_glow[1], c_glow[2], int(34 * bright * (1.0 - 0.7 * self._constel))))
        glow.setColorAt(1.0, QColor(c_glow[0], c_glow[1], c_glow[2], 0))
        p.setBrush(glow); p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QPointF(cx, cy), Rb * 1.5, Rb * 1.5)
        a = self._rot; ca = math.cos(a); sa = math.sin(a)
        tilt = math.sin(t * 0.3) * 0.5; ct = math.cos(tilt); st = math.sin(tilt)
        N = len(self._nodes); pts = []
        for idx in range(N):
            bx, by, bz, _pu = self._nodes[idx]
            rx = bx * ca - bz * sa; rz = bx * sa + bz * ca; ry = by
            ry2 = ry * ct - rz * st; rz2 = ry * st + rz * ct
            sxp = cx + rx * Rb * throb; syp = cy + ry2 * Rb * throb; depth = rz2
            lxp = cx + ((idx / float(N - 1)) - 0.5) * bs * 0.74
            lyp = cy + math.sin(idx * 0.6 + t * 2.6) * bs * 0.045
            X = sxp * (1 - m) + lxp * m; Y = syp * (1 - m) + lyp * m
            dep = depth * (1 - m) + 0.4 * m
            c = self._constel
            if c > 0.001 and self._constel_points is not None:
                cxp, cyp = self._constel_points[idx]
                X = X * (1 - c) + cxp * c; Y = Y * (1 - c) + cyp * c
                dep = dep * (1 - c) + 0.7 * c
            pts.append((X, Y, dep))
        thr = Rb * thrf; thr2 = thr * thr
        for i, j in self._edges:
            xi, yi, zi = pts[i]; xj, yj, zj = pts[j]
            dx = xi - xj; dy = yi - yj; dd = dx * dx + dy * dy
            if dd < thr2:
                d = math.sqrt(dd); dep = (zi + zj) / 2.0
                al = (1.0 - d / thr) * linkf * (0.45 + 0.55 * ((dep + 1.0) / 2.0)) * bright
                if al > 0.012:
                    pen = QPen(QColor(c_link[0], c_link[1], c_link[2], int(al * 255))); pen.setWidthF(0.8)
                    p.setPen(pen); p.drawLine(QPointF(xi, yi), QPointF(xj, yj))
        p.setPen(Qt.PenStyle.NoPen)
        cc = self._constel
        for k in range(N):
            X, Y, z = pts[k]
            depth = 0.45 + (z + 1.0) / 2.0 * 0.55
            pl = 0.6 + abs(math.sin(self._nodes[k][3])) * 0.4 * amp
            sz = (1.4 + depth * 3.0) * (1.0 - 0.55 * cc)
            halo_a = int(55 * depth * bright * (1.0 - 0.92 * cc))
            if halo_a > 2:
                p.setBrush(QColor(c_halo[0], c_halo[1], c_halo[2], halo_a))
                p.drawEllipse(QPointF(X, Y), sz * 2.0, sz * 2.0)
            p.setBrush(QColor(c_core[0], c_core[1], c_core[2], int(255 * min(1.0, depth * pl * bright))))
            p.drawEllipse(QPointF(X, Y), sz, sz)
        if cc > 0.01 and self._constel_all:
            rad = 1.15 + 0.3 * cc
            dotcol = QColor(232, 244, 255, int(245 * cc))
            p.setBrush(dotcol)
            for dxp, dyp in self._constel_all:
                p.drawEllipse(QPointF(dxp, dyp), rad, rad)
        p.end()
