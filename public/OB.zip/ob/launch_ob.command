#!/bin/bash
# OB launcher - self-contained. Builds its own venv and installs its own
# dependencies on first run, then launches. No external environment needed.
cd "$(dirname "$0")"

clear
echo ""
echo "  OB - a production of OfferBell"
echo "  ------------------------------"
echo ""

# 1. Find a usable Python (3.10+). macOS doesn't always ship one.
PY=""
for c in python3.12 python3.11 python3.10 python3; do
  if command -v "$c" >/dev/null 2>&1; then
    V=$("$c" -c 'import sys; print(sys.version_info[0]*100+sys.version_info[1])' 2>/dev/null)
    if [ -n "$V" ] && [ "$V" -ge 310 ]; then PY="$c"; break; fi
  fi
done

if [ -z "$PY" ]; then
  echo "  OB needs Python 3.10 or newer, which isn't installed."
  echo ""
  echo "  Install it once from https://www.python.org/downloads/macos/"
  echo "  (download the latest macOS installer, run it, then re-open OB)."
  echo ""
  echo "  Press any key to close."
  read -n 1 -s
  exit 1
fi

# 2. Create the venv the first time.
if [ ! -d ".venv" ]; then
  echo "  First-time setup. This runs once and takes a couple of minutes."
  echo "  Building environment..."
  "$PY" -m venv .venv || { echo "  Could not create environment."; read -n 1 -s; exit 1; }
fi

source .venv/bin/activate

# 3. Install dependencies the first time (or when requirements change).
NEED_INSTALL=0
if [ ! -f ".venv/.ob_deps_ok" ]; then
  NEED_INSTALL=1
elif [ requirements.txt -nt ".venv/.ob_deps_ok" ]; then
  NEED_INSTALL=1
fi

if [ "$NEED_INSTALL" -eq 1 ]; then
  echo "  Installing dependencies (one time)..."
  python -m pip install --upgrade pip >/dev/null 2>&1
  if python -m pip install --upgrade -r requirements.txt; then
    touch ".venv/.ob_deps_ok"
    echo "  Setup complete."
  else
    echo ""
    echo "  Dependency install failed. Check your internet connection and try again."
    read -n 1 -s
    exit 1
  fi
fi

# 4. Launch.
echo "  Starting OB..."
echo ""
python main.py
