"""OB licensing - OB is an Elite-only OfferBell feature.

The user signs in with their OfferBell email + password during setup. We call
OfferBell's Convex `auth:verifyLicense` mutation over HTTPS (the same public
endpoint the website uses) and, if they're Elite, cache a short-lived signed
token in config/license.json. On launch we re-check silently from the token so
a cancelled/downgraded account loses access on the next refresh.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import requests

_BASE = Path(__file__).resolve().parent
KEYS_PATH = _BASE / "config" / "keys.json"
LICENSE_PATH = _BASE / "config" / "license.json"

# ── REQUIRED: your OfferBell Convex deployment URL ──────────────────────
# Find it in your OfferBell .env.local as NEXT_PUBLIC_CONVEX_URL (looks like
# https://something-animal-123.convex.cloud). Paste it here, OR add
# "convex_url": "https://..." to config/keys.json (that takes precedence).
CONVEX_URL_DEFAULT = "https://festive-kingfisher-224.convex.cloud"


def _convex_url() -> str:
    try:
        d = json.loads(KEYS_PATH.read_text(encoding="utf-8"))
        u = (d.get("convex_url") or "").strip()
        if u:
            return u
    except Exception:
        pass
    return CONVEX_URL_DEFAULT.strip()


def is_configured() -> bool:
    u = _convex_url()
    return bool(u) and "YOUR-DEPLOYMENT" not in u


def _call(path: str, args: dict) -> dict:
    """Call a public Convex mutation. Returns the mutation's value dict, or a
    clean error dict on transport failure."""
    if not is_configured():
        return {"ok": False, "reason": "unconfigured",
                "message": "OB isn't pointed at OfferBell yet. Set your Convex URL in ob_license.py."}
    url = _convex_url().rstrip("/") + "/api/mutation"
    try:
        r = requests.post(url, json={"path": path, "args": args, "format": "json"}, timeout=20)
        r.raise_for_status()
        data = r.json()
    except requests.exceptions.RequestException as e:
        return {"ok": False, "reason": "network",
                "message": "Couldn't reach OfferBell. Check your connection and try again."}
    except Exception as e:
        return {"ok": False, "reason": "error", "message": "Unexpected response from OfferBell."}
    if data.get("status") == "success":
        val = data.get("value")
        return val if isinstance(val, dict) else {"ok": False, "reason": "error", "message": "Bad response."}
    return {"ok": False, "reason": "error",
            "message": data.get("errorMessage") or "Verification failed. Try again."}


def verify_license(email: str, password: str) -> dict:
    return _call("auth:verifyLicense", {"email": email.strip(), "password": password})


def recheck_license(token: str) -> dict:
    return _call("auth:recheckLicense", {"token": token})


# ── local cache ─────────────────────────────────────────────────────────
def load_license() -> dict:
    try:
        d = json.loads(LICENSE_PATH.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def save_license(res: dict, email: str = "") -> None:
    LICENSE_PATH.parent.mkdir(parents=True, exist_ok=True)
    d = {
        "token": res.get("token", ""),
        "exp": res.get("exp", 0),
        "plan": res.get("plan", ""),
        "name": res.get("name", ""),
        "email": res.get("email") or email,
        "subscriptionStatus": res.get("subscriptionStatus", ""),
    }
    LICENSE_PATH.write_text(json.dumps(d, indent=2), encoding="utf-8")


def clear_license() -> None:
    try:
        LICENSE_PATH.unlink()
    except Exception:
        pass


def local_license_ok(lic: dict | None = None) -> bool:
    """True if a cached Elite license is present and not yet expired (offline-OK
    within the token TTL)."""
    if lic is None:
        lic = load_license()
    try:
        return lic.get("plan") == "elite" and float(lic.get("exp", 0)) > time.time() * 1000
    except Exception:
        return False
