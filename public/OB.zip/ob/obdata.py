"""OB data tools.

Return RAW financial data; OB narrates it by voice. No LLM text layer here.
- teardown_data: SEC EDGAR (free, no key)
- market_brief: Finnhub (free key)
"""
from __future__ import annotations


def teardown_data(ticker: str) -> dict:
    ticker = (ticker or "").strip().upper()
    if not ticker:
        return {"error": "Give me a ticker, like NVDA."}
    try:
        from actions import sec_edgar as edgar
        from actions.teardown import _xbrl_metrics, _metrics_text
    except Exception as e:
        return {"error": "Data modules unavailable: " + str(e)}

    cik = edgar.lookup_cik(ticker)
    if not cik:
        return {"error": "No SEC filer found for " + ticker + "."}
    name = edgar.get_company_name(ticker) or ticker
    try:
        filings = edgar.get_recent_filings(ticker, types=("10-K", "10-Q"), limit_per_type=1) or []
    except Exception:
        filings = []
    try:
        metrics = _xbrl_metrics(cik)
        financials = _metrics_text(metrics)
    except Exception as e:
        financials = "Financials unavailable: " + str(e)[:120]

    fl = [{"type": f.get("type"), "date": f.get("date")} for f in filings]
    return {"company": name, "ticker": ticker, "filings": fl, "financials": financials}


def market_brief(tickers=None) -> dict:
    try:
        from actions import finnhub as fh
    except Exception as e:
        return {"error": "Finnhub module unavailable: " + str(e)}
    if not fh.have_key():
        return {"error": "No Finnhub key set. Add a free Finnhub key in Setup to pull live market data."}

    out = {}
    try:
        out["indices"] = {s: fh.as_text(fh.snapshot(s)) for s in ("SPY", "QQQ", "DIA")}
    except Exception as e:
        out["indices_error"] = str(e)[:120]
    try:
        out["headlines"] = fh.general_news(6)
    except Exception as e:
        out["headlines_error"] = str(e)[:120]

    focus = {}
    for t in (tickers or [])[:5]:
        t = (t or "").strip().upper()
        if not t:
            continue
        try:
            focus[t] = {"snapshot": fh.as_text(fh.snapshot(t)), "news": fh.company_news(t, 2)}
        except Exception as e:
            focus[t] = {"error": str(e)[:120]}
    if focus:
        out["focus"] = focus
    return out
