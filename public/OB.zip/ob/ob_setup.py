"""OB first-run setup gate.

Shown on launch when no Gemini key is saved. OB can't talk without one, so the
user lands here first, gets their free key, saves it, and only then drops into
the orb.
"""
from __future__ import annotations

import json
import threading
from pathlib import Path

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout, QWidget,
)

_BASE = Path(__file__).resolve().parent
KEYS_PATH = _BASE / "config" / "keys.json"


def read_gemini_key() -> str:
    try:
        d = json.loads(KEYS_PATH.read_text(encoding="utf-8"))
        return (d.get("gemini_api_key") or d.get("gemini") or "").strip()
    except Exception:
        return ""


def save_keys(gemini: str, finnhub: str = "") -> None:
    KEYS_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        d = json.loads(KEYS_PATH.read_text(encoding="utf-8"))
        if not isinstance(d, dict):
            d = {}
    except Exception:
        d = {}
    d["gemini_api_key"] = gemini.strip()
    if finnhub.strip():
        d["finnhub_api_key"] = finnhub.strip()
    KEYS_PATH.write_text(json.dumps(d, indent=2), encoding="utf-8")


def save_gemini_key(key: str) -> None:
    save_keys(key)


def save_profile(name: str, school: str = "", target: str = "") -> None:
    KEYS_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        d = json.loads(KEYS_PATH.read_text(encoding="utf-8"))
        if not isinstance(d, dict):
            d = {}
    except Exception:
        d = {}
    d["sender"] = {
        "name": name.strip(),
        "school": school.strip(),
        "year": "",
        "target": (target.strip() or "finance recruiting"),
    }
    KEYS_PATH.write_text(json.dumps(d, indent=2), encoding="utf-8")


_SERIF = "Georgia"

_CARD_QSS = """
#card { background: #0d121c; border: 1px solid #1f2a3a; border-radius: 18px; }
QLabel { color: #c9d4e3; background: transparent; }
#wordmark { color: #e6edf7; }
#tag { color: #5f6b80; }
#heading { color: #eef3fb; }
#body { color: #8a93a3; }
#lbl { color: #6f7a8c; }
QLineEdit { background: #0a0f18; border: 1px solid #243246; border-radius: 10px;
            color: #e6edf7; padding: 11px 13px; font-size: 14px; }
QLineEdit:focus { border: 1px solid #2563eb; }
#start { background: #2563eb; color: #ffffff; border: 0; border-radius: 10px;
         padding: 12px 22px; font-size: 14px; font-weight: 600; }
#start:disabled { background: #1c2a44; color: #5d6b82; }
#note { color: #5b6675; }
"""


def _link(text: str, url: str) -> QLabel:
    lab = QLabel(f'<a style="color:#3b82f6; text-decoration:none;" href="{url}">{text}</a>')
    lab.setTextFormat(Qt.TextFormat.RichText)
    lab.setOpenExternalLinks(True)
    lab.setStyleSheet("background: transparent;")
    return lab


class SetupScreen(QWidget):
    _checked = pyqtSignal(bool, str)

    def __init__(self, on_complete, error=""):
        super().__init__()
        self._on_complete = on_complete
        self._initial_error = error or ""
        self._checked.connect(self._on_checked)
        self.setStyleSheet("background: #04060c;")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addStretch(1)

        row = QHBoxLayout()
        row.addStretch(1)
        card = QFrame()
        card.setObjectName("card")
        card.setStyleSheet(_CARD_QSS)
        card.setFixedWidth(560)
        row.addWidget(card)
        row.addStretch(1)
        outer.addLayout(row)
        outer.addStretch(1)

        c = QVBoxLayout(card)
        c.setContentsMargins(40, 36, 40, 36)
        c.setSpacing(0)

        wm = QLabel("OB")
        wm.setObjectName("wordmark")
        wm.setFont(QFont(_SERIF, 30))
        c.addWidget(wm)
        tag = QLabel("AN OFFERBELL PRODUCT")
        tf = QFont("Helvetica Neue", 9)
        tf.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 2.0)
        tag.setFont(tf)
        tag.setStyleSheet("color: #5f6b80; background: transparent;")
        c.addWidget(tag)

        c.addSpacing(26)
        heading = QLabel("Let's get you set up")
        heading.setObjectName("heading")
        heading.setFont(QFont(_SERIF, 24))
        c.addWidget(heading)

        c.addSpacing(10)
        body = QLabel("First, a quick intro so OB coaches you specifically, not a generic student.")
        body.setObjectName("body")
        body.setWordWrap(True)
        body.setStyleSheet("color: #8a93a3; background: transparent; font-size: 14px;")
        c.addWidget(body)

        _lf = QFont("Helvetica Neue", 9)
        _lf.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1.5)

        def _mklabel(t):
            l = QLabel(t); l.setFont(_lf)
            l.setStyleSheet("color: #6f7a8c; background: transparent;")
            return l

        c.addSpacing(22)
        c.addWidget(_mklabel("YOUR NAME"))
        c.addSpacing(7)
        self._name = QLineEdit(); self._name.setPlaceholderText("First name")
        self._name.textChanged.connect(self._on_change)
        c.addWidget(self._name)

        c.addSpacing(16)
        c.addWidget(_mklabel("SCHOOL & YEAR"))
        c.addSpacing(7)
        self._school = QLineEdit(); self._school.setPlaceholderText("e.g. Ohio State, junior")
        c.addWidget(self._school)

        c.addSpacing(16)
        c.addWidget(_mklabel("TARGET ROLE"))
        c.addSpacing(7)
        self._target = QLineEdit(); self._target.setPlaceholderText("e.g. investment banking")
        c.addWidget(self._target)

        c.addSpacing(24)
        keyintro = QLabel(
            "Now your key. OB runs on your own Google Gemini key, 100% free, made in a "
            "couple of clicks. It stays on your machine. Without it, OB can't talk."
        )
        keyintro.setWordWrap(True)
        keyintro.setStyleSheet("color: #8a93a3; background: transparent; font-size: 14px;")
        c.addWidget(keyintro)

        c.addSpacing(24)
        lbl = QLabel("GEMINI API KEY")
        lbl.setObjectName("lbl")
        lf = QFont("Helvetica Neue", 9)
        lf.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1.5)
        lbl.setFont(lf)
        lbl.setStyleSheet("color: #6f7a8c; background: transparent;")
        c.addWidget(lbl)
        c.addSpacing(7)

        self._key = QLineEdit()
        self._key.setEchoMode(QLineEdit.EchoMode.Password)
        self._key.setPlaceholderText("AIza...")
        self._key.textChanged.connect(self._on_change)
        c.addWidget(self._key)

        c.addSpacing(8)
        getlink = _link("Get your free key &rarr;  (aistudio.google.com/apikey)",
                        "https://aistudio.google.com/apikey")
        getlink.setStyleSheet("background: transparent; font-size: 12.5px;")
        c.addWidget(getlink)

        c.addSpacing(20)
        lbl2 = QLabel("FINNHUB API KEY  (optional)")
        lbl2.setFont(lf)
        lbl2.setStyleSheet("color: #6f7a8c; background: transparent;")
        c.addWidget(lbl2)
        c.addSpacing(4)
        sub2 = QLabel("Only needed for the live Morning Brief (market data). Company "
                      "breakdowns work without it.")
        sub2.setWordWrap(True)
        sub2.setStyleSheet("color: #6b7686; background: transparent; font-size: 12px;")
        c.addWidget(sub2)
        c.addSpacing(7)
        self._fh = QLineEdit()
        self._fh.setEchoMode(QLineEdit.EchoMode.Password)
        self._fh.setPlaceholderText("optional")
        c.addWidget(self._fh)
        c.addSpacing(8)
        getlink2 = _link("Get your free key &rarr;  (finnhub.io/register)",
                         "https://finnhub.io/register")
        getlink2.setStyleSheet("background: transparent; font-size: 12.5px;")
        c.addWidget(getlink2)

        c.addSpacing(26)
        btnrow = QHBoxLayout()
        self._start = QPushButton("Start OB")
        self._start.setObjectName("start")
        self._start.setCursor(Qt.CursorShape.PointingHandCursor)
        self._start.setEnabled(False)
        self._start.clicked.connect(self._do_start)
        btnrow.addWidget(self._start)
        self._status = QLabel("")
        self._status.setStyleSheet("color: #8a93a3; background: transparent; font-size: 13px;")
        btnrow.addSpacing(12)
        btnrow.addWidget(self._status)
        btnrow.addStretch(1)
        c.addLayout(btnrow)

        c.addSpacing(18)
        note = QLabel("Stored locally in config/keys.json. Only ever sent to Google.")
        note.setObjectName("note")
        note.setStyleSheet("color: #5b6675; background: transparent; font-size: 11.5px;")
        c.addWidget(note)

        if self._initial_error:
            self._status.setText(self._initial_error)

    def _on_change(self, *_):
        ok = bool(self._key.text().strip()) and bool(self._name.text().strip())
        self._start.setEnabled(ok)

    def _do_start(self):
        key = self._key.text().strip()
        if not key:
            return
        fh = self._fh.text().strip()
        self._start.setEnabled(False)
        self._key.setEnabled(False)
        self._fh.setEnabled(False)
        self._status.setText("Checking your key...")
        threading.Thread(target=self._validate, args=(key, fh), daemon=True).start()

    def _validate(self, key, fh):
        # Gemini (required): a real auth call. Bad key raises.
        try:
            from google import genai
            client = genai.Client(api_key=key)
            list(client.models.list())
        except Exception as e:
            print("[OB setup] gemini check failed:", e)
            self._checked.emit(False, "That Gemini key didn't work. Double-check it and try again.")
            return
        # Finnhub (optional): only validate if they entered one.
        if fh:
            try:
                import requests
                r = requests.get("https://finnhub.io/api/v1/quote",
                                 params={"symbol": "AAPL", "token": fh}, timeout=10)
                bad = r.status_code in (401, 403)
                try:
                    if r.status_code == 200 and isinstance(r.json(), dict) and r.json().get("error"):
                        bad = True
                except Exception:
                    pass
                if bad:
                    self._checked.emit(False, "That Finnhub key didn't work. Fix it or clear it (it's optional).")
                    return
            except Exception as e:
                print("[OB setup] finnhub check skipped (network):", e)
        self._checked.emit(True, "")

    def _on_checked(self, ok, msg):
        if not ok:
            self._status.setText(msg)
            self._start.setEnabled(True)
            self._key.setEnabled(True)
            self._fh.setEnabled(True)
            return
        try:
            save_keys(self._key.text().strip(), self._fh.text().strip())
            save_profile(self._name.text().strip(), self._school.text().strip(), self._target.text().strip())
        except Exception as e:
            self._status.setText("Couldn't save key.")
            self._start.setEnabled(True)
            self._key.setEnabled(True)
            self._fh.setEnabled(True)
            print("[OB setup] save failed:", e)
            return
        self._status.setText("Saved. Starting OB...")
        if self._on_complete:
            self._on_complete()
