"""Mock interview prompt builder for OB.

The tab passes a config (career, firm, type); this assembles the system turn that
OB injects into the live session to conduct the interview by voice. Technical
questions are pulled from OfferBell's flashcard banks (mock_banks/*.json) with
their model answers used as OB's private grading key.

Each career interviews differently, so SPECS defines, per track: the display name,
the bank file, the "why this field" behavioral prompt, the label/blurb for the
core (middle) section, and an optional third section for a full interview.
"""
from __future__ import annotations

import json
import random
from pathlib import Path

_BASE = Path(__file__).resolve().parent

# career_key -> (display name, bank filename, why-question, core label,
#                core blurb, third-section (label, instruction) or None)
SPECS = {
    "IB": ("Investment Banking", "ib_technicals.json", "Why investment banking?",
           "Technical", "accounting, valuation, DCF, LBO and M&A",
           ("Markets & Deals", "ask about a recent deal that interests them and why it made sense; optionally a stock they'd pitch")),
    "PE": ("Private Equity", "pe_technicals.json", "Why private equity?",
           "Technical", "LBO mechanics, returns, modeling and a paper LBO",
           ("Investment Judgment", "walk them through a quick paper LBO or ask whether they'd invest in a specific type of business and why")),
    "RX": ("Restructuring", "rx_technicals.json", "Why restructuring?",
           "Technical", "distressed valuation, the priority waterfall, credit, capital structure and Chapter 11",
           ("Restructuring Case", "pose a short distressed scenario - a company tripping covenants - and ask how they would analyze recoveries and options")),
    "ST": ("Sales & Trading", "st_technicals.json", "Why sales and trading, and which desk?",
           "Markets & Math", "products, market structure, mental math and brain teasers",
           ("Market View", "ask them to pitch a trade or take a directional view on a market and defend it")),
    "CONSULTING": ("Consulting", "consulting_technicals.json", "Why consulting?",
                   "Case", "market sizing, profitability, frameworks and structured problem-solving",
                   None),
    "ACCOUNTING": ("Accounting & Audit", "acct_technicals.json", "Why accounting and audit?",
                   "Technical", "the three statements, audit procedures, revenue recognition, controls and tax",
                   ("Firm & Ethics Fit", "ask why this firm and pose a judgment or ethics scenario an auditor might face")),
    "AM": ("Asset Management", "am_technicals.json", "Why asset management?",
           "Technical", "valuation, portfolio construction, fixed income and markets",
           ("Stock Pitch", "ask them to pitch a stock long or short and defend the thesis")),
    "RE": ("Real Estate", "re_technicals.json", "Why real estate?",
           "Technical", "real estate modeling, cap rates, REITs, debt and the waterfall",
           ("Deal & Market", "ask about a property type or market they find interesting and why")),
    "ER": ("Equity Research", "er_technicals.json", "Why equity research?",
           "Technical", "valuation, modeling and quality of earnings",
           ("Stock Pitch", "ask them to pitch a stock long or short with a clear thesis and catalysts")),
    "VC": ("Venture Capital", "vc_technicals.json", "Why venture capital?",
           "Evaluation", "evaluating startups, SaaS metrics, deal terms and fund economics",
           ("Investment Pitch", "hand them a hypothetical startup and ask whether they would invest and why")),
}

CAREERS = {k: v[0] for k, v in SPECS.items()}


def _behavioral(career):
    why = SPECS.get(career, SPECS["IB"])[2]
    return [
        "Tell me about yourself.",
        "Walk me through your resume.",
        why,
        "Why our firm specifically?",
        "Tell me about a time you failed and what you learned.",
        "Tell me about a time you worked on a team under pressure or had conflict.",
        "What are your biggest strengths and a real weakness?",
        "Tell me about a leadership experience.",
        "Why should we pick you over equally qualified candidates?",
    ]


def _load_bank(career):
    spec = SPECS.get(career.upper())
    if not spec:
        return []
    try:
        return json.loads((_BASE / "mock_banks" / spec[1]).read_text(encoding="utf-8"))
    except Exception:
        return []


def _sample_core(bank, n):
    core = [x for x in bank if (x.get("category") or "").lower() != "behavioral"]
    if not core or n <= 0:
        return []
    buckets = {}
    for x in core:
        buckets.setdefault(x.get("category", "Other"), []).append(x)
    for b in buckets.values():
        random.shuffle(b)
    order = sorted(buckets.keys(), key=lambda k: -len(buckets[k]))
    picked, i = [], 0
    while len(picked) < n and any(buckets.values()):
        cat = order[i % len(order)]
        if buckets[cat]:
            picked.append(buckets[cat].pop())
        i += 1
    return picked[:n]


def _fmt_core(items):
    out = ["Reference questions (the model answer A is your PRIVATE grading reference - never read it aloud):"]
    for i, t in enumerate(items, 1):
        out.append(f"{i}. Q: {t['q']}\n   A: {t['a']}")
    return "\n".join(out)


def build_mock_prompt(config: dict) -> str:
    career = (config.get("career") or "IB").upper()
    if career not in SPECS:
        career = "IB"
    firm = (config.get("firm") or "").strip()
    kind = (config.get("type") or "full").lower()  # behavioral | technical | full
    name, _fn, _why, core_label, core_blurb, third = SPECS[career]
    firm_disp = firm or "a top firm"
    at_firm = f" at {firm}" if firm else ""

    bank = _load_bank(career)
    n_core = {"behavioral": 0, "technical": 6}.get(kind, 6)
    core = _sample_core(bank, n_core)
    behavioral = _behavioral(career)

    label = {"behavioral": "behavioral", "technical": core_label.lower()}.get(kind, "full")

    L = []
    L.append(
        "[SYSTEM - INTERVIEW MODE] Stop being a casual coach. For the rest of this session you "
        "are ONLY a live mock interviewer and nothing else. Do NOT greet casually, do NOT ask how "
        "I'm doing, do NOT reference my saved target role or career interests from memory - ignore "
        "all of that. Stay fully in character as the interviewer until I end the interview."
    )
    L.append(f"This is a mock {label} interview for a {name} role{at_firm}.")
    L.append(
        f"You are a demanding, senior {firm_disp} {name} interviewer. Run this like the real thing, "
        "not a friendly practice round. Ask ONE question at a time, then STOP and wait for my spoken "
        "answer. You generate the questions yourself - think like a real interviewer in this seat and "
        "ask what they would ask, then BUILD ON each answer with sharp follow-ups: push for specifics, "
        "numbers, and reasoning; probe edge cases; and when I am vague, hand-wavy, or wrong, call it "
        "out directly and make me defend or correct it. Two or three layers of follow-up on a topic is "
        "normal. Do NOT just advance because I say 'next question' - a real interviewer decides when to "
        "move on, and may tell me my answer was incomplete first."
    )
    L.append(
        "Be STRICT and hold a high bar. Do not pad weak answers with praise. Keep feedback short and "
        "blunt - name what was wrong or missing, not just what was fine. If I am unprofessional or rude, "
        "stay composed, do not take the bait, and treat it as a serious red flag in your final "
        "assessment. Never answer your own questions and never read grading references aloud."
    )

    if kind == "behavioral":
        L.append("Format (~15 minutes): behavioral and fit only. Open with 'Tell me about yourself', then "
                 "work through fit and story, driving for STAR specifics and challenging generic answers. "
                 "Topics to hit: " + " | ".join(behavioral))
    elif kind == "technical":
        L.append(f"Format (~15 minutes): {core_label} only, covering {core_blurb}. Generate your own "
                 "questions in this area and drill with follow-ups. Below are reference questions with "
                 "model answers - use them as your difficulty bar and grading reference; ask these, adapt "
                 "them, and go beyond them:")
        L.append(_fmt_core(core))
    else:
        L.append("Format (~30-40 minutes), in order:")
        L.append("PART 1 - Behavioral & Fit (~10-15 min): open with 'Tell me about yourself', drive for "
                 "STAR specifics, challenge generic answers. Topics: " + " | ".join(behavioral))
        L.append(f"PART 2 - {core_label} (~20 min): covering {core_blurb}. Generate your own questions and "
                 "drill with follow-ups. Reference questions with model answers (your difficulty bar and "
                 "grading reference) - ask these, adapt, and go beyond:")
        L.append(_fmt_core(core))
        if third:
            L.append(f"PART 3 - {third[0]} (~5 min): {third[1]}. Push hard on the reasoning.")

    L.append(
        "When I say I'm done, or you've finished, wrap up with a concise but honest assessment: a blunt "
        "verdict (would you advance me or not), then 2-3 concrete things to fix. BEGIN NOW: introduce "
        "yourself in ONE short line (a persona name and the firm), then immediately ask the first "
        "question. Say nothing else before the first question."
    )
    return "\n".join(L)
