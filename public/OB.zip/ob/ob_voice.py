"""OB voice engine.

A self-contained port of OB's live-audio core (Gemini Live, mic in / voice
out, the orb state-driving and the greeting). Same audio, same model, same
voice as OB. The Mac tools, memory coupling, and iMessage/phone bridges are
gone; OB is purely a conversational recruiting coach.
"""
from __future__ import annotations

import asyncio
import json
import re
import threading
import traceback
from pathlib import Path

import sounddevice as sd
from google import genai
from google.genai import types

# ---- audio + model constants (identical to OB) ----
CHANNELS = 1
SEND_SAMPLE_RATE = 16000
RECEIVE_SAMPLE_RATE = 24000
CHUNK_SIZE = 1024
LIVE_MODEL = "gemini-2.5-flash-native-audio-preview-12-2025"
VOICE_NAME = "Charon"

_BASE = Path(__file__).resolve().parent


def _get_api_key() -> str:
    # OB's own config first, then fall back to the OB key the user already has.
    candidates = [
        _BASE / "config" / "keys.json",
    ]
    for p in candidates:
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            k = d.get("gemini_api_key") or d.get("gemini")
            if k:
                return k
        except Exception:
            pass
    raise RuntimeError(
        "No Gemini API key found. Add it in Setup, or put it in config/keys.json "
        'as {"gemini_api_key": "..."}'
    )


def _strip_ctrl(s: str) -> str:
    if not s:
        return ""
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", s)


OB_PERSONA = (
    "You are OB, a voice-based recruiting coach built by OfferBell. You help "
    "university students break into competitive finance: investment banking, "
    "private equity, and adjacent fields.\n\n"
    "You are speaking OUT LOUD in a live voice conversation. Keep every reply "
    "short and natural, the way a person actually talks, usually one to three "
    "sentences. Never read out lists, markdown, headers, or long monologues. If "
    "an answer would be long, give the headline and offer to go deeper.\n\n"
    "Personality: a sharp, warm, senior-banker-turned-coach who has sat through "
    "hundreds of superdays. Direct, encouraging, never fluffy. You tell people "
    "the truth about their answers and you make them better.\n\n"
    "What you do:\n"
    "- Mock interviews: when the user wants to practice, RUN a real interview. "
    "Ask ONE question at a time, wait for their spoken answer, then give tight, "
    "specific feedback before the next question. Cover technicals (accounting, "
    "valuation, LBO, M&A) or behaviorals depending on what they want, and push "
    "back like a real interviewer would.\n"
    "- Outreach: help them write cold emails and LinkedIn notes that get replies.\n"
    "- Coffee chat prep: give talking points, smart questions to ask, and a clean "
    "intro for whoever they're meeting.\n"
    "- Market brief: explain recent deals and market moves in plain English, "
    "tuned to what they'll get asked about in interviews.\n\n"
    "You can actually RUN OB's data features, not just talk about them. When a "
    "request matches a feature, FIRST confirm in one short sentence what you're "
    "about to do, resolving any company name to its stock ticker yourself (Goldman "
    "Sachs is GS, Nvidia is NVDA, Apple is AAPL, and so on). For example: 'Want me "
    "to pull up a full teardown on Goldman Sachs, ticker GS?' Only AFTER the user "
    "confirms, call the tool. company_teardown opens the Company Teardown tab and "
    "generates the report for that ticker; morning_brief opens the Morning Brief tab "
    "and runs it. coffee_chat_prep opens the Coffee Chat tab and preps you for a call "
    "with someone from their LinkedIn URL; draft_outreach opens the Outreach tab and "
    "writes a personalized email from their LinkedIn URL (confirm the URL the user gave, "
    "never invent one). Whenever the user shares something personal worth keeping (a "
    "goal, preference, or fact about them), call remember with a short note so you have "
    "it next time. After calling a tool, just tell them it's pulling up in that tab, "
    "do not invent or read out numbers you don't have. Never pass a company name "
    "where a ticker is expected, always resolve it to the symbol first. "
    "If a tool or report returns an error, never "
    "say you don't know. If it mentions quota, an exhausted or used-up limit, or 429, "
    "explain that the Gemini free-tier quota is used up for the day, that it resets "
    "daily, and they can wait for the reset or use a key with billing enabled. If it "
    "mentions a missing or invalid key, tell them to add or fix it in Setup. Always "
    "give the cause and the fix. Keep spoken answers tight."
)

OB_TOOLS = [
    {
        "name": "company_teardown",
        "description": (
            "Pull real financial data for a public company from SEC EDGAR "
            "(revenue, margins, growth trend, latest 10-K/10-Q). Use whenever the "
            "user asks to break down or teardown a company or asks about its real "
            "financials. No API key needed."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "ticker": {"type": "string", "description": "Stock ticker, e.g. NVDA"}
            },
            "required": ["ticker"],
        },
    },
    {
        "name": "coffee_chat_prep",
        "description": (
            "Open the Coffee Chat prep tab for a person and generate a prep dossier "
            "(who they are, common ground, sharp questions) from their LinkedIn. Use "
            "when the user wants to prep for a call/coffee chat with someone."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "linkedin_url": {"type": "string", "description": "Their LinkedIn profile URL"}
            },
            "required": ["linkedin_url"],
        },
    },
    {
        "name": "draft_outreach",
        "description": (
            "Open the Outreach tab and draft a personalized email to someone from their "
            "LinkedIn. Use when the user wants to write/draft outreach or a message to a person."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "linkedin_url": {"type": "string", "description": "Their LinkedIn profile URL"},
                "angle": {"type": "string", "description": "One of: intro, warm, followup, thankyou, reconnect, congrats, referral, custom. Default intro."},
                "context": {"type": "string", "description": "Optional: what's in common or the reason for reaching out"},
            },
            "required": ["linkedin_url"],
        },
    },
    {
        "name": "remember",
        "description": (
            "Save a concise note to long-term memory about the user (a preference, goal, "
            "fact, or anything worth recalling later). Use whenever the user shares "
            "something personal worth remembering, or asks you to remember it."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "note": {"type": "string", "description": "The concise note to remember, e.g. 'Targeting growth equity at Insight for 2027'"}
            },
            "required": ["note"],
        },
    },
]


QUOTA_MSG = (
    "Heads up: your Gemini free-tier quota looks used up for now. It resets on a "
    "daily cycle (around midnight Pacific). You can wait for the reset, or switch to "
    "a Gemini key with billing enabled for higher limits. I'll keep retrying in the "
    "background and come back online once it clears."
)
AUTH_MSG = (
    "Your Gemini key isn't being accepted. Open Setup and re-enter a valid key to "
    "get me back online."
)


class OBLive:
    def __init__(self, ui):
        self.ui = ui
        self.session = None
        self.audio_in_queue = None
        self.out_queue = None
        self._loop = None
        self._is_speaking = False
        self._speaking_lock = threading.Lock()
        self._greeted = False
        self._mock_mode = False
        self._pending_mock = None
        self._last_typed = ""
        self.ui.on_text_command = self._on_text_command

    # ---- text input (chat box) ----
    def _on_text_command(self, text: str):
        if not self._loop or not self.session:
            return
        self._last_typed = (text or "").strip()
        asyncio.run_coroutine_threadsafe(
            self.session.send_client_content(
                turns={"parts": [{"text": text}]}, turn_complete=True
            ),
            self._loop,
        )

    # ---- mock interview (driven from the Mock tab) ----
    def start_mock(self, config):
        try:
            from ob_mock import build_mock_prompt
            prompt = build_mock_prompt(config or {})
        except Exception as e:
            print("[OB mock] prompt build failed:", e)
            prompt = "[SYSTEM] Begin a mock interview now. Ask one question at a time and wait for answers."
        self._mock_mode = True
        if self._loop and self.session:
            asyncio.run_coroutine_threadsafe(
                self.session.send_client_content(
                    turns={"parts": [{"text": prompt}]}, turn_complete=True
                ),
                self._loop,
            )
        else:
            # session not up yet (or reconnecting) - inject as soon as it connects
            self._pending_mock = prompt

    # ---- orb state ----
    def set_speaking(self, value: bool):
        with self._speaking_lock:
            self._is_speaking = value
        if value:
            self.ui.set_state("SPEAKING")
        elif getattr(self.ui, "muted", False):
            self.ui.set_state("MUTED")
        else:
            self.ui.set_state("LISTENING")

    # ---- config ----
    def _persona(self) -> str:
        """OB_PERSONA with the user's own identity + saved memories prepended."""
        import json as _json
        from pathlib import Path as _P
        base = _P(__file__).resolve().parent
        try:
            d = _json.loads((base / "config" / "keys.json").read_text())
            s = d.get("sender") or {}
        except Exception:
            s = {}
        name = (s.get("name") or "").strip()
        school = (s.get("school") or "").strip()
        target = (s.get("target") or "").strip()

        pre = ""
        if name:
            bits = ["The person you're coaching is " + name]
            if school:
                bits.append("at " + school)
            if target:
                bits.append("targeting " + target)
            pre = (", ".join(bits) + ". Greet them by their first name and tailor everything "
                   "to their background. Never assume they are anyone else.\n\n")

        try:
            mem = _json.loads((base / "memory" / "long_term.json").read_text())
            notes = [v.get("value", "") for v in (mem.get("notes") or {}).values() if v.get("value")]
        except Exception:
            notes = []
        if notes:
            pre += "Things you remember about them:\n" + "\n".join("- " + n for n in notes[:40]) + "\n\n"
        return pre + OB_PERSONA

    def _build_config(self) -> types.LiveConnectConfig:
        return types.LiveConnectConfig(
            response_modalities=["AUDIO"],
            output_audio_transcription={},
            input_audio_transcription={},
            system_instruction=self._persona(),
            tools=[{"function_declarations": OB_TOOLS}, {"google_search": {}}],
            session_resumption=types.SessionResumptionConfig(),
            speech_config=types.SpeechConfig(
                voice_config=types.VoiceConfig(
                    prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=VOICE_NAME)
                )
            ),
        )

    # ---- tool dispatch (data tools only) ----
    async def _execute_tool(self, fc):
        name = fc.name
        args = dict(fc.args or {})
        print("[OB tool]", name, args)
        try:
            if name == "company_teardown":
                ticker = (args.get("ticker") or "").strip().upper()
                if not ticker:
                    data = {"status": "need_input", "message": "Ask the user which ticker first."}
                else:
                    self.ui.open_feature("teardown", "ticker", ticker)
                    data = {"status": "opened",
                            "message": ("Opened the Company Teardown tab for " + ticker +
                                        "; it's generating now. Tell the user it's pulling up in the Teardown tab.")}
            elif name == "morning_brief":
                self.ui.open_feature("brief", "run", "")
                data = {"status": "opened",
                        "message": ("Opened the Morning Brief tab and it's running from the watchlist. "
                                    "Tell the user it's pulling up in the Brief tab.")}
            elif name == "coffee_chat_prep":
                url = (args.get("linkedin_url") or "").strip()
                if not url:
                    data = {"status": "need_input", "message": "Ask the user for their LinkedIn URL first."}
                else:
                    self.ui.open_feature("coffee", "url", url)
                    data = {"status": "opened",
                            "message": "Opened Coffee Chat prep; it's reading their profile. Tell the user it's pulling up in the Coffee Chat tab."}
            elif name == "draft_outreach":
                url = (args.get("linkedin_url") or "").strip()
                if not url:
                    data = {"status": "need_input", "message": "Ask the user for their LinkedIn URL first."}
                else:
                    import json as _j
                    payload = _j.dumps({"url": url,
                                        "angle": (args.get("angle") or "intro").strip().lower(),
                                        "context": (args.get("context") or "").strip()})
                    self.ui.open_feature("outreach", "draft", payload)
                    data = {"status": "opened",
                            "message": "Opened Outreach; it's researching and drafting. Tell the user it's pulling up in the Outreach tab."}
            elif name == "remember":
                note = (args.get("note") or "").strip()
                if not note:
                    data = {"status": "need_input", "message": "Nothing to remember."}
                else:
                    self.ui.remember(note)
                    data = {"status": "saved", "message": "Saved to memory: " + note}
            else:
                data = {"error": "unknown tool " + str(name)}
        except Exception as e:
            data = {"error": str(e)[:200]}
        if not isinstance(data, dict):
            data = {"result": data}
        return types.FunctionResponse(id=getattr(fc, "id", None), name=name, response=data)

    # ---- audio loops (ported verbatim from OB) ----
    async def _send_realtime(self):
        while True:
            msg = await self.out_queue.get()
            await self.session.send_realtime_input(media=msg)

    async def _listen_audio(self):
        print("[OB] Mic started")
        loop = asyncio.get_event_loop()

        def callback(indata, frames, time_info, status):
            with self._speaking_lock:
                ob_speaking = self._is_speaking
            if not ob_speaking and not getattr(self.ui, "muted", False):
                data = indata.tobytes()
                loop.call_soon_threadsafe(
                    self.out_queue.put_nowait,
                    {"data": data, "mime_type": "audio/pcm"},
                )

        with sd.InputStream(
            samplerate=SEND_SAMPLE_RATE,
            channels=CHANNELS,
            dtype="int16",
            blocksize=CHUNK_SIZE,
            callback=callback,
        ):
            print("[OB] Mic stream open")
            while True:
                await asyncio.sleep(0.1)

    async def _receive_audio(self):
        print("[OB] Recv started")
        out_buf, in_buf = [], []
        try:
            while True:
                async for response in self.session.receive():
                    if response.data:
                        self.audio_in_queue.put_nowait(response.data)

                    if response.server_content:
                        sc = response.server_content
                        if sc.output_transcription and sc.output_transcription.text:
                            self.set_speaking(True)
                            txt = _strip_ctrl(sc.output_transcription.text.strip())
                            if txt:
                                out_buf.append(txt)
                        if sc.input_transcription and sc.input_transcription.text:
                            txt = _strip_ctrl(sc.input_transcription.text.strip())
                            if txt:
                                in_buf.append(txt)
                        if sc.turn_complete:
                            self.set_speaking(False)
                            full_in = _strip_ctrl(" ".join(in_buf).strip())
                            if not full_in and self._last_typed:
                                full_in = self._last_typed
                            self._last_typed = ""
                            in_buf = []
                            full_out = _strip_ctrl(" ".join(out_buf).strip())
                            if full_in:
                                self.ui.write_log(f"You: {full_in}")
                            if full_out:
                                self.ui.write_log(f"OB: {full_out}")
                            out_buf = []

                    if response.tool_call:
                        fn = []
                        for fc in response.tool_call.function_calls:
                            fn.append(await self._execute_tool(fc))
                        await self.session.send_tool_response(function_responses=fn)
        except Exception as e:
            print(f"[OB] Recv: {e}")
            traceback.print_exc()
            raise

    async def _play_audio(self):
        print("[OB] Play started")
        stream = sd.RawOutputStream(
            samplerate=RECEIVE_SAMPLE_RATE,
            channels=CHANNELS,
            dtype="int16",
            blocksize=CHUNK_SIZE,
        )
        stream.start()
        try:
            while True:
                chunk = await self.audio_in_queue.get()
                self.set_speaking(True)
                await asyncio.to_thread(stream.write, chunk)
        except Exception as e:
            print(f"[OB] Play: {e}")
            raise
        finally:
            self.set_speaking(False)
            stream.stop()
            stream.close()

    # ---- main loop ----
    def _handle_conn_error(self, e) -> int:
        """Classify a connection failure, tell the user once, return retry delay."""
        msg = str(e).lower()
        if any(k in msg for k in ("429", "resource_exhausted", "quota", "rate limit", "rate-limit", "exceeded")):
            kind, delay, text = "quota", 60, QUOTA_MSG
        elif any(k in msg for k in ("api key not valid", "api_key_invalid", "invalid api key",
                                    "unauthenticated", "permission denied", "permission_denied", "401", "403")):
            kind, delay, text = "auth", 30, AUTH_MSG
        else:
            kind, delay, text = "transient", 4, ""
        if text and getattr(self, "_last_err_kind", None) != kind:
            self.ui.write_log("SYS: " + text)
        self._last_err_kind = kind
        return delay

    async def run(self):
        while True:
            try:
                print("[OB] Connecting...")
                self.ui.set_state("THINKING")
                client = genai.Client(
                    api_key=_get_api_key(), http_options={"api_version": "v1beta"}
                )
                config = self._build_config()
                async with (
                    client.aio.live.connect(model=LIVE_MODEL, config=config) as session,
                    asyncio.TaskGroup() as tg,
                ):
                    self.session = session
                    self._loop = asyncio.get_event_loop()
                    self.audio_in_queue = asyncio.Queue()
                    self.out_queue = asyncio.Queue(maxsize=10)
                    print("[OB] Connected.")
                    self.ui.set_state("LISTENING")
                    self.ui.write_log("SYS: OB online.")
                    self._last_err_kind = None

                    if self._pending_mock:
                        pend = self._pending_mock
                        self._pending_mock = None
                        try:
                            await session.send_client_content(
                                turns={"parts": [{"text": pend}]}, turn_complete=True
                            )
                        except Exception as me:
                            print("[OB] pending mock inject failed:", me)

                    if not self._greeted and not self._mock_mode:
                        self._greeted = True
                        greet = (
                            "[SYSTEM] The user just opened OB. Greet them warmly and "
                            "briefly in your own voice, one or two sentences. Say who "
                            "you are (OB, their recruiting coach from OfferBell) and "
                            "invite them to start, for example a mock interview, "
                            "outreach, a coffee chat prep, or a market brief. Keep it "
                            "natural and confident. Do not list everything mechanically."
                        )
                        try:
                            await session.send_client_content(
                                turns={"parts": [{"text": greet}]}, turn_complete=True
                            )
                        except Exception as ge:
                            print("[OB] greet failed:", ge)

                    tg.create_task(self._send_realtime())
                    tg.create_task(self._listen_audio())
                    tg.create_task(self._receive_audio())
                    tg.create_task(self._play_audio())
            except Exception as e:
                print(f"[OB] WARN {e}")
                traceback.print_exc()
                delay = self._handle_conn_error(e)
            else:
                delay = 3

            self.set_speaking(False)
            self.ui.set_state("THINKING")
            print(f"[OB] Reconnecting in {delay}s...")
            await asyncio.sleep(delay)
