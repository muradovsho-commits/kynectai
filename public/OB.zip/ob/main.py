"""OB - the OfferBell recruiting coach.

Native orb HUD (OB engine, flattened) + live voice (OB audio core,
OfferBell persona). OB greets you out loud on open and you talk to it like
OB. Mic/settings/power live on the dock; the nodes are coaches OB can run.

Run:  ./launch_ob.command
"""
from __future__ import annotations

import asyncio
import os
import sys
import threading

os.environ.setdefault(
    "QTWEBENGINE_CHROMIUM_FLAGS",
    "--enable-smooth-scrolling --enable-gpu-rasterization --enable-zero-copy --ignore-gpu-blocklist",
)

from PyQt6.QtCore import QCoreApplication, Qt, QObject, pyqtSignal

QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)

try:
    from PyQt6 import QtWebEngineWidgets  # noqa: F401
except Exception as _e:
    print("[OB] QtWebEngine import skipped:", _e)

from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel
from PyQt6.QtGui import QFont

from activehud import ActiveHUD
from ob_voice import OBLive
from ob_setup import SetupScreen, read_gemini_key
import ob_license
from ob_license_screen import LicenseScreen


class OBBridge(QObject):
    """Bridges the voice engine (worker thread) to the orb (GUI thread).

    set_state is called from the async audio loop, so it must marshal onto the
    GUI thread via a queued signal rather than touch the widget directly.
    """

    _state = pyqtSignal(str)
    _log = pyqtSignal(str, str)  # role, body
    _remember = pyqtSignal(str)

    def __init__(self, hud):
        super().__init__()
        self.hud = hud
        self.muted = False
        self.on_text_command = None
        self._state.connect(self._apply_state)
        self._log.connect(self._apply_log)
        self._remember.connect(self._apply_remember)

    def remember(self, note):
        self._remember.emit(note or "")

    def _apply_remember(self, note):
        try:
            if self.hud:
                self.hud.add_memory_text(note)
        except Exception as e:
            print("[OB] remember err:", e)

    def set_state(self, state: str):
        self._state.emit(state)

    def _apply_state(self, state: str):
        try:
            self.hud.set_state(state)
        except Exception:
            pass

    def write_log(self, msg: str):
        m = (msg or "").strip()
        if m.startswith("You:"):
            self._log.emit("user", m[4:].strip())
        elif m.startswith("OB:"):
            self._log.emit("ob", m[3:].strip())
        elif m.startswith("SYS:"):
            self._log.emit("sys", m[4:].strip())
        else:
            print("[OB]", m)

    def _apply_log(self, role: str, body: str):
        if not body:
            return
        try:
            r = "user" if role == "user" else ("sys" if role == "sys" else "assistant")
            self.hud._add_bubble(r, body)
        except Exception as e:
            print("[OB] log err:", e)

    def set_greet_callback(self, cb):
        pass  # OB greets directly inside the run loop

    def open_feature(self, tab_id, action="", arg=""):
        """Called from the voice thread; voice_open_tab marshals to the GUI thread."""
        try:
            if self.hud:
                self.hud.voice_open_tab(tab_id, action, arg)
        except Exception as e:
            print("[OB] open_feature err:", e)

    # called from the GUI thread when the user taps the mic
    def toggle_mute(self):
        self.muted = not self.muted
        try:
            self.hud.set_muted(self.muted)
        except Exception:
            pass


class OBWindow(QMainWindow):
    _validated = pyqtSignal(bool, bool)  # (key_ok, is_auth_error)
    _lic_result = pyqtSignal(bool, str)  # (ok, message)

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("OB")
        self.resize(1200, 820)
        self.setMinimumSize(900, 640)
        self.setStyleSheet("background:#04060c;")

        self.bridge = None
        self.hud = None
        self._voice_started = False
        self._validated.connect(self._after_validate)
        self._lic_result.connect(self._after_license)

        self._gate_license()

    # ── Elite license gate (runs before anything else) ──────────────────
    def _gate_license(self) -> None:
        lic = ob_license.load_license()
        if lic.get("token") and ob_license.is_configured():
            # Recheck on EVERY launch: confirm the account is still Elite and
            # downgrade immediately if not. Falls back to the cached token only
            # when the network call fails (offline) — handled in _recheck_worker.
            self.setCentralWidget(self._checking_widget("Checking your OfferBell membership..."))
            threading.Thread(target=self._recheck_worker, args=(lic.get("token"),), daemon=True).start()
        else:
            self._show_license()

    def _recheck_worker(self, token: str) -> None:
        res = ob_license.recheck_license(token)
        if res.get("ok") and res.get("plan") == "elite":
            ob_license.save_license(res)
            self._lic_result.emit(True, "")
        elif res.get("reason") == "network" and ob_license.local_license_ok():
            # Offline: don't lock out a still-valid cached Elite user.
            self._lic_result.emit(True, "")
        else:
            # Definitive rejection (downgraded, expired, no account): drop the
            # stale token so the next launch goes straight to sign-in.
            ob_license.clear_license()
            self._lic_result.emit(False, res.get("message") or "Your OfferBell Elite membership is no longer active.")

    def _after_license(self, ok: bool, message: str) -> None:
        if ok:
            self._post_license()
        else:
            self._show_license(message)

    def _show_license(self, error: str = "") -> None:
        self.setCentralWidget(LicenseScreen(on_verified=self._post_license, error=error))

    # ── existing key/setup flow, now gated behind a valid Elite license ──
    def _post_license(self) -> None:
        if not read_gemini_key():
            self._show_setup()
        else:
            self.setCentralWidget(self._checking_widget())
            threading.Thread(target=self._validate_key, daemon=True).start()

    def _checking_widget(self, text: str = "Starting OB...") -> QWidget:
        w = QWidget()
        w.setStyleSheet("background:#04060c;")
        lay = QVBoxLayout(w)
        lay.addStretch(1)
        lab = QLabel(text)
        lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lab.setFont(QFont("Georgia", 20))
        lab.setStyleSheet("color:#8a93a3; background:transparent;")
        lay.addWidget(lab)
        lay.addStretch(1)
        return w

    def _show_setup(self, error: str = "") -> None:
        self.setCentralWidget(SetupScreen(on_complete=self.start_ob, error=error))

    def _validate_key(self) -> None:
        key = read_gemini_key()
        try:
            from google import genai
            list(genai.Client(api_key=key).models.list())
            self._validated.emit(True, False)
        except Exception as e:
            msg = str(e).lower()
            auth = any(k in msg for k in (
                "api key not valid", "api_key_invalid", "invalid api key",
                "unauthenticated", "permission denied", "permission_denied",
                "401", "403",
            ))
            print("[OB] launch key check failed:", e)
            self._validated.emit(False, auth)

    def _after_validate(self, ok: bool, auth: bool) -> None:
        if ok:
            self.start_ob()
        elif auth:
            self._show_setup("Your saved key didn't work. Enter a valid one to continue.")
        else:
            # Network/transient error: don't trap a good user offline. Boot anyway;
            # the voice loop will retry once a connection is back.
            self.start_ob()

    def start_ob(self) -> None:
        def _send(text):
            if self.bridge and self.bridge.on_text_command:
                self.bridge.on_text_command(text)

        def _mute():
            if self.bridge:
                self.bridge.toggle_mute()

        self.hud = ActiveHUD(self, on_send=_send, on_mute=_mute, on_idle=lambda: None)
        self.setCentralWidget(self.hud)
        self.bridge = OBBridge(self.hud)

        if not self._voice_started:
            self._voice_started = True
            voice = OBLive(self.bridge)
            self.hud._on_mock_start = voice.start_mock

            def runner():
                try:
                    asyncio.run(voice.run())
                except KeyboardInterrupt:
                    pass
                except Exception as e:
                    print("[OB] voice loop crashed:", e)

            threading.Thread(target=runner, daemon=True).start()


def main() -> None:
    app = QApplication.instance() or QApplication(sys.argv)
    app.setStyle("Fusion")
    win = OBWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
