@echo off
setlocal
cd /d "%~dp0"

cls
echo.
echo   OB - a production of OfferBell
echo   ------------------------------
echo.

REM 1. Find a usable Python (3.10+). Windows doesn't ship one by default.
set "PY="
for %%C in (py python python3) do (
  if not defined PY (
    %%C -c "import sys; sys.exit(0 if sys.version_info[:2]>=(3,10) else 1)" >nul 2>&1
    if not errorlevel 1 set "PY=%%C"
  )
)

if not defined PY (
  echo   OB needs Python 3.10 or newer, which isn't installed or isn't on PATH.
  echo.
  echo   Install it once from https://www.python.org/downloads/windows/
  echo   During setup, CHECK the box "Add python.exe to PATH". Then re-open OB.
  echo.
  pause
  exit /b 1
)

REM 2. Create the venv the first time.
if not exist ".venv\" (
  echo   First-time setup. This runs once and takes a couple of minutes.
  echo   Building environment...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo   Could not create environment.
    pause
    exit /b 1
  )
)

REM 3. Install dependencies the first time (delete .venv\.ob_deps_ok to force a refresh).
if not exist ".venv\.ob_deps_ok" (
  echo   Installing dependencies ^(one time^)...
  ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>&1
  ".venv\Scripts\python.exe" -m pip install --upgrade -r requirements.txt
  if errorlevel 1 (
    echo.
    echo   Dependency install failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
  echo ok> ".venv\.ob_deps_ok"
  echo   Setup complete.
)

REM 4. Launch.
echo   Starting OB...
echo.
".venv\Scripts\python.exe" main.py
if errorlevel 1 pause
endlocal
