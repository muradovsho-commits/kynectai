"""
mac_chrome.py - Single source of truth for Chrome operations on macOS.
"""
import os
import subprocess
import time
import platform

IS_MAC = platform.system() == "Darwin"
CHROME_APP_PATH = "/Applications/Google Chrome.app"


def chrome_installed() -> bool:
    return os.path.exists(CHROME_APP_PATH)


def _osascript(script: str, timeout: float = 6.0):
    try:
        return subprocess.run(
            ["osascript", "-e", script],
            capture_output=True, text=True, timeout=timeout
        )
    except subprocess.TimeoutExpired:
        return None
    except Exception:
        return None


def activate_chrome():
    _osascript('tell application "Google Chrome" to activate', timeout=3)


def open_tab(url: str) -> bool:
    if not chrome_installed():
        return False
    try:
        subprocess.Popen(["open", "-a", "Google Chrome", url])
        time.sleep(0.4)
        return True
    except Exception:
        return False


def read_url_text(url: str, wait: float = 3.5) -> str:
    """Open url in Chrome and return the rendered page text (document.body.innerText).
    Opens the URL, finds the exact tab whose URL matches, waits for it to finish
    loading, and reads that tab specifically (not whichever window is frontmost).
    Requires Chrome menu: View > Developer > Allow JavaScript from Apple Events.
    Returns "" on any failure."""
    if not chrome_installed():
        return ""
    # match on the profile slug so we find the right tab regardless of redirects
    key = url.split("//", 1)[-1].split("?", 1)[0].rstrip("/")
    key = key.replace('"', '').replace("\\", "")
    script = (
        'set targetKey to "' + key + '"\n'
        'tell application "Google Chrome"\n'
        '  set foundTab to missing value\n'
        '  set foundWin to missing value\n'
        '  repeat with w in windows\n'
        '    repeat with t in tabs of w\n'
        '      if (URL of t) contains targetKey then\n'
        '        set foundTab to t\n'
        '        set foundWin to w\n'
        '        exit repeat\n'
        '      end if\n'
        '    end repeat\n'
        '    if foundTab is not missing value then exit repeat\n'
        '  end repeat\n'
        '  if foundTab is missing value then\n'
        '    set foundWin to (make new window)\n'
        '    set foundTab to (make new tab at end of tabs of foundWin with properties {URL:"' + url + '"})\n'
        '  end if\n'
        '  delay ' + str(max(1.0, float(wait))) + '\n'
        '  set theText to execute foundTab javascript "document.body.innerText"\n'
        '  return theText\n'
        'end tell'
    )
    r = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True, text=True, timeout=60
    )
    if r.returncode != 0:
        return ""
    return (r.stdout or "").strip()


def open_window_with_urls(urls: list) -> bool:
    if not urls or not chrome_installed():
        return False

    first = urls[0].replace('"', '\\"')
    script_open = (
        'tell application "Google Chrome"\n'
        '  activate\n'
        '  make new window with properties {URL:"' + first + '"}\n'
        'end tell'
    )
    r = _osascript(script_open, timeout=6)
    if r is None or r.returncode != 0:
        try:
            subprocess.Popen(["open", "-na", "Google Chrome", "--args", "--new-window", urls[0]])
            time.sleep(0.8)
        except Exception:
            return False

    time.sleep(0.6)

    for u in urls[1:]:
        u_esc = u.replace('"', '\\"')
        script_tab = (
            'tell application "Google Chrome"\n'
            '  tell front window\n'
            '    make new tab with properties {URL:"' + u_esc + '"}\n'
            '  end tell\n'
            'end tell'
        )
        _osascript(script_tab, timeout=5)
        time.sleep(0.35)

    return True


def get_screen_size():
    r = _osascript('tell application "Finder" to get bounds of window of desktop', timeout=2)
    if r and r.returncode == 0 and r.stdout:
        try:
            parts = [int(p.strip()) for p in r.stdout.replace("{", "").replace("}", "").split(",")]
            if len(parts) == 4:
                return parts[2], parts[3]
        except Exception:
            pass
    return 1440, 900


def exit_fullscreen_all():
    """Exit fullscreen on all Chrome windows."""
    script = (
        'tell application "Google Chrome" to activate\n'
        'delay 0.3\n'
        'tell application "System Events"\n'
        '  tell process "Google Chrome"\n'
        '    repeat with w in (every window)\n'
        '      try\n'
        '        if value of attribute "AXFullScreen" of w is true then\n'
        '          set value of attribute "AXFullScreen" of w to false\n'
        '        end if\n'
        '      end try\n'
        '    end repeat\n'
        '  end tell\n'
        'end tell'
    )
    _osascript(script, timeout=5)
    time.sleep(0.9)


def snap_front_chrome(side: str):
    """Snap the frontmost Chrome window to left or right half of the screen.
    Auto-exits fullscreen first."""
    exit_fullscreen_all()
    w, h = get_screen_size()
    half = w // 2
    if side == "left":
        x, y, ww, hh = 0, 25, half, h - 25
    else:
        x, y, ww, hh = half, 25, half, h - 25
    script = (
        'tell application "Google Chrome" to activate\n'
        'delay 0.2\n'
        'tell application "System Events"\n'
        '  tell process "Google Chrome"\n'
        '    try\n'
        '      set position of window 1 to {' + str(x) + ', ' + str(y) + '}\n'
        '      set size of window 1 to {' + str(ww) + ', ' + str(hh) + '}\n'
        '    end try\n'
        '  end tell\n'
        'end tell'
    )
    _osascript(script, timeout=4)
    time.sleep(0.4)


def close_front_tab():
    _osascript('tell application "Google Chrome" to close active tab of front window', timeout=3)


def focus_tab_with_url_substring(substr: str) -> bool:
    substr_low = substr.lower()
    script = (
        'tell application "Google Chrome"\n'
        '  set winList to every window\n'
        '  repeat with w in winList\n'
        '    set tabList to every tab of w\n'
        '    repeat with t in tabList\n'
        '      if URL of t contains "' + substr_low + '" then\n'
        '        set active tab index of w to (index of t)\n'
        '        set index of w to 1\n'
        '        activate\n'
        '        return "ok"\n'
        '      end if\n'
        '    end repeat\n'
        '  end repeat\n'
        'end tell\n'
        'return "nope"'
    )
    r = _osascript(script, timeout=5)
    return bool(r and r.returncode == 0 and "ok" in (r.stdout or ""))
