"""OB Elite sign-in gate.

Shown on launch when there's no valid cached Elite license. The user signs in
with their OfferBell account; if they're Elite we cache the license and drop
them into the normal setup/app flow. Anyone else is told it's Elite-only.
"""
from __future__ import annotations

import threading

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QHBoxLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout, QWidget,
)

import ob_license


class LicenseScreen(QWidget):
    _result = pyqtSignal(bool, str)  # (ok, message)

    def __init__(self, on_verified, error: str = ""):
        super().__init__()
        self._on_verified = on_verified
        self._busy = False
        self._result.connect(self._on_result)
        self.setStyleSheet("background:#04060c;")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addStretch(1)

        card = QWidget()
        card.setFixedWidth(440)
        card.setStyleSheet("background:transparent;")
        cl = QVBoxLayout(card)
        cl.setSpacing(0)

        eyebrow = QLabel("AN OFFERBELL PRODUCT")
        eyebrow.setStyleSheet("color:#2563eb; font-size:11px; font-weight:600; letter-spacing:2px; background:transparent;")
        cl.addWidget(eyebrow)

        title = QLabel("OB")
        title.setFont(QFont("Georgia", 46))
        title.setStyleSheet("color:#eef2f8; background:transparent;")
        cl.addWidget(title)

        sub = QLabel("OB is an Elite feature. Sign in with your OfferBell account to continue.")
        sub.setWordWrap(True)
        sub.setStyleSheet("color:#8a93a3; font-size:14px; background:transparent;")
        cl.addWidget(sub)
        cl.addSpacing(24)

        cl.addWidget(self._lbl("OFFERBELL EMAIL"))
        self._email = self._field("you@email.com")
        cl.addWidget(self._email)
        cl.addSpacing(14)

        cl.addWidget(self._lbl("PASSWORD"))
        self._pw = self._field("Your OfferBell password", password=True)
        self._pw.returnPressed.connect(self._submit)
        cl.addWidget(self._pw)
        cl.addSpacing(18)

        self._btn = QPushButton("Sign in")
        self._btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._btn.setStyleSheet(
            "QPushButton{background:#2563eb; color:#fff; border:none; border-radius:11px;"
            "padding:13px; font-size:15px; font-weight:600;}"
            "QPushButton:hover{background:#2f6df0;}"
            "QPushButton:disabled{background:#1a2438; color:#5a6478;}"
        )
        self._btn.clicked.connect(self._submit)
        cl.addWidget(self._btn)

        self._msg = QLabel(error or "")
        self._msg.setWordWrap(True)
        self._msg.setStyleSheet("color:#e0653b; font-size:13px; background:transparent;")
        self._msg.setVisible(bool(error))
        cl.addSpacing(12)
        cl.addWidget(self._msg)

        hint = QLabel("Not Elite yet? Upgrade at offerbell.org, then sign in here.")
        hint.setStyleSheet("color:#5a6478; font-size:12px; background:transparent;")
        cl.addSpacing(8)
        cl.addWidget(hint)

        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(card)
        row.addStretch(1)
        outer.addLayout(row)
        outer.addStretch(1)

        if not ob_license.is_configured():
            self._set_msg("OB isn't connected to OfferBell yet. Set your Convex URL in ob_license.py first.")

    def _lbl(self, text):
        l = QLabel(text)
        l.setStyleSheet("color:#5a6478; font-size:11px; font-weight:600; letter-spacing:1.5px; background:transparent;")
        return l

    def _field(self, placeholder, password=False):
        e = QLineEdit()
        e.setPlaceholderText(placeholder)
        if password:
            e.setEchoMode(QLineEdit.EchoMode.Password)
        e.setStyleSheet(
            "QLineEdit{background:#0b1119; color:#eef2f8; border:1px solid #1c2740;"
            "border-radius:11px; padding:12px 14px; font-size:14px;}"
            "QLineEdit:focus{border:1px solid #2563eb;}"
        )
        return e

    def _set_msg(self, text):
        self._msg.setText(text)
        self._msg.setVisible(bool(text))

    def _submit(self):
        if self._busy:
            return
        email = self._email.text().strip()
        pw = self._pw.text()
        if not email or not pw:
            self._set_msg("Enter your OfferBell email and password.")
            return
        self._busy = True
        self._btn.setEnabled(False)
        self._btn.setText("Checking...")
        self._set_msg("")
        threading.Thread(target=self._worker, args=(email, pw), daemon=True).start()

    def _worker(self, email, pw):
        res = ob_license.verify_license(email, pw)
        if res.get("ok"):
            ob_license.save_license(res, email=email)
            self._result.emit(True, "")
        else:
            self._result.emit(False, res.get("message") or "Couldn't verify your account.")

    def _on_result(self, ok, message):
        self._busy = False
        self._btn.setEnabled(True)
        self._btn.setText("Sign in")
        if ok:
            self._on_verified()
        else:
            self._set_msg(message)
