"""teardown.py — Deep company teardown.

Pulls hard XBRL financials (multi-year revenue, margins, FCF, stock-comp dilution)
straight from SEC EDGAR's companyfacts API, plus the latest 10-K/10-Q text, and asks
Gemini for the non-obvious read: quality-of-earnings flags, what investors overlook,
and the bear case. Built to surface things surface-level summaries miss.
"""
import json
import re


# ---- XBRL financials from companyfacts ----
_REV = ["RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues", "SalesRevenueNet"]
_GP = ["GrossProfit"]
_OI = ["OperatingIncomeLoss"]
_NI = ["NetIncomeLoss"]
_CFO = ["NetCashProvidedByUsedInOperatingActivities",
        "NetCashProvidedByUsedInOperatingActivitiesContinuingOperations"]
_CAPEX = ["PaymentsToAcquirePropertyPlantAndEquipment", "PaymentsToAcquireProductiveAssets"]
_SBC = ["ShareBasedCompensation", "ShareBasedCompensationExpense"]
_CASH = ["CashAndCashEquivalentsAtCarryingValue", "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents"]
_DEBT = ["LongTermDebtNoncurrent", "LongTermDebt"]
_SH = ["WeightedAverageNumberOfDilutedSharesOutstanding", "WeightedAverageNumberOfSharesOutstandingBasic"]


def _annual(cf, tags):
    """Return {fiscal_year: value} merged across ALL matching us-gaap tags (FY 10-K facts only).
    Merging matters because companies change which revenue/income tag they file under over time,
    so picking only the first tag can return stale years (e.g. NVDA pre-2023)."""
    facts = cf.get("facts", {}).get("us-gaap", {})
    out = {}
    for t in tags:
        node = facts.get(t)
        if not node:
            continue
        units = node.get("units", {})
        key = "USD" if "USD" in units else ("shares" if "shares" in units else (list(units.keys())[0] if units else None))
        if not key:
            continue
        for r in units[key]:
            if r.get("fp") == "FY" and str(r.get("form", "")).startswith("10-K") and r.get("fy") and r.get("val") is not None:
                fy = r["fy"]
                filed = str(r.get("filed", ""))
                if fy not in out or filed > out[fy][1]:
                    out[fy] = (r["val"], filed)
    return {fy: v[0] for fy, v in out.items()}


def _fmt_money(v):
    if v is None:
        return "—"
    a = abs(v)
    if a >= 1e9:
        return ("-" if v < 0 else "") + "$%.1fB" % (a / 1e9)
    if a >= 1e6:
        return ("-" if v < 0 else "") + "$%.0fM" % (a / 1e6)
    return ("-" if v < 0 else "") + "$%.0f" % a


def _pct(x):
    return "—" if x is None else "%.1f%%" % (x * 100)


def _xbrl_metrics(cik):
    import requests
    from actions.sec_edgar import SEC_HEADERS
    url = "https://data.sec.gov/api/xbrl/companyfacts/CIK%s.json" % str(cik).zfill(10)
    try:
        cf = requests.get(url, headers=SEC_HEADERS, timeout=15).json()
    except Exception:
        return None
    rev, gp, oi, ni = _annual(cf, _REV), _annual(cf, _GP), _annual(cf, _OI), _annual(cf, _NI)
    cfo, capex, sbc = _annual(cf, _CFO), _annual(cf, _CAPEX), _annual(cf, _SBC)
    if not rev:
        return None
    years = sorted(rev.keys())[-4:]
    rows = []

    def g(d, y):
        return d.get(y)

    rev_row, growth_row, gm_row, om_row, nm_row, fcf_row, sbc_row = [], [], [], [], [], [], []
    for i, y in enumerate(years):
        rv = g(rev, y)
        rev_row.append(_fmt_money(rv))
        prev = g(rev, years[i - 1]) if i > 0 else None
        growth_row.append(_pct((rv / prev - 1) if (rv and prev) else None))
        gm_row.append(_pct((g(gp, y) / rv) if (g(gp, y) is not None and rv) else None))
        om_row.append(_pct((g(oi, y) / rv) if (g(oi, y) is not None and rv) else None))
        nm_row.append(_pct((g(ni, y) / rv) if (g(ni, y) is not None and rv) else None))
        fcf = (g(cfo, y) - g(capex, y)) if (g(cfo, y) is not None and g(capex, y) is not None) else None
        fcf_row.append(_fmt_money(fcf))
        sbc_row.append(_pct((g(sbc, y) / rv) if (g(sbc, y) is not None and rv) else None))

    rows = [
        {"label": "Revenue", "vals": rev_row},
        {"label": "Rev growth", "vals": growth_row},
        {"label": "Gross margin", "vals": gm_row},
        {"label": "Operating margin", "vals": om_row},
        {"label": "Net margin", "vals": nm_row},
        {"label": "Free cash flow", "vals": fcf_row},
        {"label": "Stock comp / rev", "vals": sbc_row},
    ]
    return {"years": years, "rows": rows}


def _metrics_text(m):
    if not m:
        return "No XBRL financial history available."
    head = "Fiscal year:  " + "  |  ".join(str(y) for y in m["years"])
    lines = [head] + ["%-18s %s" % (r["label"] + ":", "  |  ".join(r["vals"])) for r in m["rows"]]
    return "\n".join(lines)


def company_teardown(ticker: str) -> dict:
    ticker = (ticker or "").strip().upper()
    if not ticker:
        return {"error": "Give me a ticker, e.g. NVDA."}
    try:
        from actions import sec_edgar as edgar
    except Exception as e:
        return {"error": "EDGAR module unavailable: " + str(e)}

    cik = edgar.lookup_cik(ticker)
    if not cik:
        return {"error": "Couldn't find an SEC filer for ticker " + ticker + "."}

    name = edgar.get_company_name(ticker) or ticker
    filings = edgar.get_recent_filings(ticker, types=("10-K", "10-Q"), limit_per_type=1) or []
    tenk = next((f for f in filings if f.get("type") == "10-K"), None)
    tenq = next((f for f in filings if f.get("type") == "10-Q"), None)

    metrics = _xbrl_metrics(cik)

    filing_text = ""
    if tenk and tenk.get("url"):
        try:
            filing_text = edgar.fetch_filing_text(tenk["url"], max_chars=46000)
        except Exception:
            filing_text = ""

    system = (
        "You are an equity research analyst preparing a sharp, concise investment briefing for a finance "
        "student who already knows the basics. Use the hard XBRL financials provided (authoritative, do NOT "
        "contradict them), the 10-K text, and live web search for segment detail, the latest quarter, peer "
        "multiples, and the current price. Be specific and quantitative, and go a level deeper than a "
        "surface summary, but stay concise.\n"
        "Return ONLY JSON with EXACTLY these keys:\n"
        '{"snapshot": "2-3 sentence top-line take on the company and the investment setup", '
        '"businessOverview": "2-4 sentences of prose: what the company does, its main revenue sources, and its position in the industry", '
        '"growthDrivers": ["3-5 bullets, each a full explanatory sentence naming a driver of revenue/earnings growth over the next 3-5 years and WHY it matters"], '
        '"competitiveAdvantage": "2-4 sentences of prose on the moat: switching costs, network effects, scale, brand, or other structural advantages, and how durable they are", '
        '"financialQuality": ["3-5 bullets reading the ACTUAL numbers: revenue growth trend, margin direction, profitability, FCF quality, SBC dilution, balance-sheet strength"], '
        '"risks": ["3-5 bullets on the most important risks to the thesis"], '
        '"valuation": "2-4 sentences of prose on whether it looks expensive or cheap vs peers and its own history, and what has to be true to justify the price", '
        '"keyMetrics": ["4-6 bullets: the specific indicators an investor should monitor going forward"]}. '
        "Nothing outside the JSON."
    )
    parts = ["Company: " + name + " (" + ticker + "), CIK " + str(cik)]
    if tenk:
        parts.append("Latest 10-K filed " + str(tenk.get("date", "")) + ": " + str(tenk.get("url", "")))
    if tenq:
        parts.append("Latest 10-Q filed " + str(tenq.get("date", "")) + ": " + str(tenq.get("url", "")))
    parts.append("HARD XBRL FINANCIALS (authoritative):\n" + _metrics_text(metrics))
    if filing_text:
        parts.append("SEC 10-K text excerpt:\n" + filing_text)
    parts.append("Research current market data, segments, and the bear case via search, then write the teardown. Return only the JSON.")
    prompt = "\n\n".join(parts)

    try:
        from actions.outreach import _gen
        text = _gen(system, prompt, use_search=True)
    except Exception as e:
        text = ""

    from actions.outreach import _loads
    d = _loads(text)

    def _has_content(x):
        return isinstance(x, dict) and bool(
            str(x.get("snapshot", "")).strip() or str(x.get("businessOverview", "")).strip()
            or x.get("growthDrivers"))

    # If the model returned nothing usable (often a daily quota cap), retry on the fallback
    # path without search, then surface a clear error rather than a blank card.
    if not _has_content(d):
        try:
            text2 = _gen(system, prompt + "\n\nReturn ONLY the JSON object — no prose, no markdown fences.",
                         use_search=False)
            d2 = _loads(text2)
            if _has_content(d2):
                d, text = d2, text2
        except Exception:
            pass

    if not _has_content(d):
        return {"error": "The analysis model returned no usable content. This usually means the daily "
                         "Gemini quota is exhausted. Raw: " + (str(text)[:200] or "(empty)")}

    def _list(x):
        return [str(i).strip() for i in x if str(i).strip()] if isinstance(x, list) else []

    return {
        "name": name, "ticker": ticker,
        "tenk": {"date": (tenk or {}).get("date", ""), "url": (tenk or {}).get("url", "")} if tenk else None,
        "tenq": {"date": (tenq or {}).get("date", ""), "url": (tenq or {}).get("url", "")} if tenq else None,
        "metrics": metrics,
        "snapshot": str(d.get("snapshot", "")).strip(),
        "businessOverview": str(d.get("businessOverview", "")).strip(),
        "growthDrivers": _list(d.get("growthDrivers")),
        "competitiveAdvantage": str(d.get("competitiveAdvantage", "")).strip(),
        "financialQuality": _list(d.get("financialQuality")),
        "risks": _list(d.get("risks")),
        "valuation": str(d.get("valuation", "")).strip(),
        "keyMetrics": _list(d.get("keyMetrics")),
    }
