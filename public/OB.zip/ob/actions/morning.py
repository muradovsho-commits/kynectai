"""morning.py — Morning brief. A watchlist in, a pre-market rundown out.

Pulls live index tone, macro (oil/gold/rates/dollar/BTC/vol), sector performance,
per-ticker pre-market moves, news, and earnings-on-deck from Finnhub, then writes a
tight spoken/visual brief.
"""
from datetime import date

_INDICES = [("SPY", "S&P 500"), ("QQQ", "Nasdaq 100"), ("DIA", "Dow Jones"), ("IWM", "Russell 2000")]
_MACRO = [("USO", "Oil"), ("GLD", "Gold"), ("TLT", "Treasuries"), ("UUP", "US Dollar"),
          ("BITO", "Bitcoin"), ("VIXY", "Volatility")]
_SECTORS = [("XLK", "Tech"), ("XLF", "Financials"), ("XLE", "Energy"), ("XLV", "Health Care"),
            ("XLY", "Discretionary"), ("XLP", "Staples"), ("XLI", "Industrials"), ("XLU", "Utilities"),
            ("XLB", "Materials"), ("XLRE", "Real Estate"), ("XLC", "Comm Svcs")]


def _pct(p):
    return ("+" if (p or 0) >= 0 else "") + "%.2f%%" % (p or 0)


def _summary(market, macro, sectors, movers, earnings_today, top_news):
    try:
        from actions.outreach import _gen
    except Exception:
        return ""
    lines = []
    if market:
        lines.append("Indices: " + ", ".join("%s %s" % (m["label"], _pct(m["pct"])) for m in market))
    if macro:
        lines.append("Macro: " + ", ".join("%s %s" % (m["label"], _pct(m["pct"])) for m in macro))
    if sectors:
        ss = sorted(sectors, key=lambda x: (x["pct"] or 0))
        lines.append("Sectors: leading %s %s, lagging %s %s" % (
            ss[-1]["label"], _pct(ss[-1]["pct"]), ss[0]["label"], _pct(ss[0]["pct"])))
    if movers:
        lines.append("Watchlist: " + "; ".join("%s %s%s" % (
            m["ticker"], _pct(m["pct"]), (" [" + m["earnings"] + "]") if m.get("earnings") else "") for m in movers[:6]))
    if earnings_today:
        lines.append("Reporting today: " + ", ".join(earnings_today))
    if top_news:
        lines.append("Headlines: " + " | ".join(n["headline"] for n in top_news[:4]))
    data = "\n".join(lines)
    system = (
        "You are a markets analyst writing a tight pre-market brief for a finance student, the kind you'd say "
        "over coffee before the open. Use ONLY the data provided; do not invent numbers. Write 4-5 sentences "
        "of flowing prose: lead with the overall tone (indices and what macro/rates/oil are doing), note any "
        "clear sector rotation, then the most notable watchlist moves and any names reporting, and close with "
        "one line on what to watch today. No preamble, no bullet points."
    )
    try:
        return (_gen(system, "Data:\n" + data + "\n\nWrite the brief.", use_search=False, allow_fallback=True) or "").strip()
    except Exception:
        return ""


def _strip(pairs):
    from actions import finnhub as fh
    out = []
    for sym, label in pairs:
        q = fh.quote(sym)
        if q:
            out.append({"label": label, "sym": sym, "pct": q["pct"]})
    return out


def morning_brief(tickers):
    from actions import finnhub as fh
    if not fh.have_key():
        return {"error": "Add a free Finnhub API key (finnhub_api_key in config/api_keys.json) to use the morning brief."}
    tickers = [t.strip().upper() for t in (tickers or []) if t and t.strip()]
    today = date.today()

    market = _strip(_INDICES)
    macro = _strip(_MACRO)
    sectors = _strip(_SECTORS)
    top_news = fh.general_news(6)

    movers, earnings_today, earnings_week = [], [], []
    for t in tickers:
        q = fh.quote(t)
        if not q:
            continue
        news = fh.company_news(t, 2)
        nd = fh.next_earnings_date(t)
        flag = ""
        if nd:
            try:
                delta = (date.fromisoformat(nd) - today).days
                if delta == 0:
                    flag = "Reports today"
                    earnings_today.append(t)
                elif 0 < delta <= 7:
                    flag = "Reports " + nd
                    earnings_week.append({"ticker": t, "date": nd})
            except Exception:
                pass
        movers.append({"ticker": t, "price": q["price"], "pct": q["pct"], "prev": q.get("prev"),
                       "open": q.get("open"), "high": q.get("high"), "low": q.get("low"),
                       "nextDate": nd, "earnings": flag,
                       "headlines": [{"headline": n["headline"], "url": n["url"]} for n in news]})
    movers.sort(key=lambda m: abs(m.get("pct") or 0), reverse=True)

    summary = _summary(market, macro, sectors, movers, earnings_today, top_news)

    return {"date": today.isoformat(), "market": market, "macro": macro, "sectors": sectors,
            "topNews": top_news, "movers": movers, "earningsToday": earnings_today,
            "earningsWeek": earnings_week, "summary": summary, "empty": len(tickers) == 0}
