"""outreach.py — Jarvis outreach agent, using OfferBell's trained outreach logic.

Ports the OfferBell Outreach Writer: the same system prompt (structure, tone, do/don'ts,
subject rules, example) and the same angle system. Jarvis adds one thing OfferBell never had:
it reads the recipient's real LinkedIn page (via mac_chrome) and feeds it in as research.

Entry points:
  - outreach(parameters)       voice/command action: email in, draft opened in composer.
  - research_profile(...)      Outreach HUD tab: LinkedIn URL + angle in -> {name, summary, subject, body}.

Sender identity is read from config/api_keys.json["sender"] (name/school/year/target).
"""
import sys
import json
import re
from pathlib import Path


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


API_CONFIG_PATH = _base_dir() / "config" / "keys.json"


def _get_api_key() -> str:
    from pathlib import Path as _P
    for _p in (_base_dir() / "config" / "keys.json",
               _base_dir() / "config" / "api_keys.json",
               _P.home() / "jarvis-mac" / "config" / "api_keys.json"):
        try:
            _d = json.load(open(_p))
            _k = _d.get("gemini_api_key") or _d.get("gemini")
            if _k:
                return _k
        except Exception:
            pass
    return ""


# Angle system (mirrors OfferBell's Outreach Writer)
ANGLES = [
    {"key": "intro",     "label": "Intro",        "sub": "First-time cold outreach"},
    {"key": "warm",      "label": "Warm Intro",   "sub": "Referral or mutual connection"},
    {"key": "followup",  "label": "Follow-up",    "sub": "After a call or prior email"},
    {"key": "thankyou",  "label": "Thank You",    "sub": "After a chat or their help"},
    {"key": "reconnect", "label": "Reconnect",    "sub": "Old contact, pick back up"},
    {"key": "congrats",  "label": "Congrats",     "sub": "New role, deal, or news"},
    {"key": "referral",  "label": "Referral Ask", "sub": "Ask for an intro or referral"},
    {"key": "custom",    "label": "Custom",       "sub": "Describe it in the context"},
]
CTX_LABELS = {
    "intro": "Why this person? Any hook?",
    "warm": "Who referred you?",
    "followup": "What happened, and the next step?",
    "thankyou": "What are you thanking them for?",
    "reconnect": "How do you know them?",
    "congrats": "What's the news?",
    "referral": "What are you asking for?",
    "custom": "Describe the email you want",
}
CTX_PLACEHOLDERS = {
    "intro": "e.g. their group covers TMT, which I'm targeting",
    "warm": "e.g. Jane Smith suggested I reach out",
    "followup": "e.g. spoke Tuesday; you said apply when apps open",
    "thankyou": "e.g. the coffee chat Thursday; recruiting advice",
    "reconnect": "e.g. met at the 2024 conference; want to catch up",
    "congrats": "e.g. promoted to VP; closed a big deal",
    "referral": "e.g. intro to someone on the buyside team",
    "custom": "e.g. short note sharing an article they'd find useful",
}
_ANGLE_LABEL = {a["key"]: a["label"] for a in ANGLES}

SITUATION_GUIDE = {
    "intro": "First-time cold outreach. Use the default initial-outreach structure: introduce the student briefly plus ONE genuine professional connection point drawn from the recipient's profile, then a specific ask for a brief call with schedule flexibility.",
    "warm": "A referral or mutual connection exists (named in the context). Name the referral naturally in the intro, then proceed like an initial outreach with a specific, easy ask for a brief call.",
    "followup": "A call or prior email already happened (see context). Keep it short: reference something specific that was discussed, confirm or restate the next step, and keep momentum. Do not reintroduce the student at length.",
    "thankyou": "A thank-you after a conversation or their help (see context). Thank them, reference one specific thing discussed, mention a concrete next step (e.g. applying when applications open), and optionally ask if there's anyone else worth speaking to. Brief and warm.",
    "reconnect": "Reconnecting with a contact after a gap (see context for how they know each other). Acknowledge the gap lightly, reference the prior connection specifically, and propose catching up. Warmer than a cold intro.",
    "congrats": "Congratulate the recipient on recent news (new role, promotion, deal, from context or profile). Be genuine and specific about the news, keep it short, optionally add a light interest or reconnect note. Not a hard ask.",
    "referral": "Ask the recipient for a referral or introduction (see context for the specific ask). Be specific, respect their time, make it easy to say yes, and give them an easy out.",
    "custom": "Follow the context exactly, the student has described the specific email they want. Keep the trained voice and structure, adapting to whatever the context specifies.",
}


# The exact OfferBell Outreach Writer system prompt.
OUTREACH_SYSTEM = """You are an expert at writing networking and outreach emails for college students recruiting into investment banking and other competitive finance roles. You know exactly what analysts and associates actually respond to, because you have been trained on what real banking professionals expect. The student fills in details; you turn them into a polished, ready-to-send email.

OUTPUT CONTRACT (follow exactly):
- The very first line must be "Subject: <subject line>".
- Then one blank line, then the email body.
- No commentary, labels, or notes before or after. Output only the email.

STRUCTURE (this matters most): never write the body as one large block of text. Split it into short, distinct paragraphs separated by a blank line, in this order:
1. Greeting on its own line: "Hi <FirstName>," (use "Hi", never "Hey").
2. Intro paragraph: who the student is (name, year, school or program, and the role they are targeting), then ONE genuine, professional connection point, for example a shared program, school, or club, or something specific noticed about the recipient's own role or path on LinkedIn. Keep the connection professional. Never use personal trivia like movies, sports, or hobbies as the hook.
3. Ask paragraph: show specific interest in the recipient's group, firm, or career path. Ask to hear about their experience, what drew them to their group, what their day to day looks like, or advice on recruiting. Then make one clear, specific request for a brief call, and signal flexibility (for example, happy to work around their schedule).
4. Warm closing line (for example: "Hope to connect soon. Have a great day.").
5. Sign-off: "Best," on one line, then the student's first name on the next line.

SUBJECT LINE: specific and informative, in Title Case. Good patterns: "<School or Program> Student Interested in <Group or Bank> Reaching Out", or "<School> Student Networking Call Request". Never generic like "Student Reach-Out" or "Quick Question".

TONE: professional and polished, even if a warmer tone is requested. Confident but never desperate or over-eager. Concise: the body should be roughly 4 to 8 sentences total. Personalized to this exact person, never something that reads like a copy-paste blast.

DO:
- Personalize to the recipient's specific role, group, and firm.
- Keep it brief and to the point.
- Use flawless grammar and spelling. If any day or date is mentioned, keep it internally consistent.
- If a resume is referenced, treat it as attached to the email (below the message), never "above".

DO NOT:
- Do not use a casual greeting ("Hey") or a casual sign-off (no period after the name, no "Cheers" for a first cold email).
- Do not name-drop a mutual contact unless the provided context explicitly says a referral or mutual connection was given.
- Do not invent shared personal interests or hobbies as the connection point.
- Do not use hollow filler or cliches, and never use the words "delve", "robust", "thrilled", or "tapestry".
- Do not be wordy, and do not oversell or sound desperate.

EMAIL TYPE: infer from the context. Default is an initial outreach requesting a brief call. If the context indicates a thank-you or follow-up after a call already happened, instead: thank them, reference something specific that was discussed, optionally ask if there is anyone else worth speaking to, and mention a concrete next step (such as applying when applications open). Keep follow-ups short.

Example of the structure and tone to match (do not copy the details, only the shape):
Subject: Finance Student Reaching Out

Hi Yash,

I hope you are doing well. My name is Jordan Lee, and I am a finance student exploring a career in investment banking. I noticed on your LinkedIn that you are now an Analyst at KeyBanc.

I am exploring opportunities in coverage groups for next summer, and I would love to hear about how you have enjoyed your role so far. If you are open to it, I would appreciate setting up a brief call to learn about your experience and ask for any advice on the recruiting process. I know you are busy, so I am happy to work around your schedule.

Hope to connect soon. Have a great day.

Best,
Jordan"""


_DEFAULT_SENDER = {
    "name": "",
    "school": "",
    "year": "",
    "target": "finance recruiting",
}


def _sender() -> dict:
    try:
        s = json.load(open(API_CONFIG_PATH)).get("sender", {})
        return {k: (str(s.get(k, "")).strip() or _DEFAULT_SENDER[k]) for k in _DEFAULT_SENDER}
    except Exception:
        return dict(_DEFAULT_SENDER)


_NAV_STOP = {
    "0 notifications", "skip to search", "skip to main content", "skip to primary content",
    "skip to aside", "skip to footer", "home", "my network", "jobs", "messaging",
    "notifications", "me", "for business", "advertise", "more", "message", "follow",
    "contact info", "highlights",
}


def _profile_brief(page_text: str) -> str:
    """Cheap local extract of name + headline + first role, for the 'who they are' box."""
    lines = [ln.strip() for ln in page_text.split("\n") if ln.strip()]
    clean = [ln for ln in lines if ln.lower() not in _NAV_STOP and not ln.isdigit()]
    name = clean[0] if clean else ""
    headline = clean[1] if len(clean) > 1 else ""
    role = ""
    for i, ln in enumerate(lines):
        if ln.lower() == "experience" and i + 2 < len(lines):
            role = lines[i + 1].strip() + " at " + lines[i + 2].strip()
            break
    bits = [b for b in [name, headline] if b]
    out = " — ".join(bits[:2]) if bits else "Profile read from LinkedIn."
    if role:
        out += ". Current: " + role + "."
    return out


def _parse_email(text: str):
    text = (text or "").strip().strip("`")
    m = re.match(r"(?is)^\s*subject:\s*(.+?)\r?\n\s*\r?\n(.*)$", text)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    lines = text.split("\n")
    if lines and lines[0].lower().startswith("subject:"):
        return lines[0].split(":", 1)[1].strip(), "\n".join(lines[1:]).strip()
    return "Networking Call Request", text


def _build_prompt(contact_name, contact_firm, contact_role, contact_school, angle_label, ctx, profile_text, situation_key="intro"):
    s = _sender()
    guide = SITUATION_GUIDE.get(situation_key, SITUATION_GUIDE["intro"])
    p = (
        "Write a networking/outreach email for an undergraduate student to this person.\n"
        "Student Info: name=" + s["name"] + ", school=" + s["school"] + ", year=" + s["year"] +
        ", target role=" + s["target"] + ".\n"
        "Contact Info: name=" + (contact_name or "see profile below") + ", firm=" + (contact_firm or "see profile below") +
        ", role=" + (contact_role or "see profile below") + ", school=" + (contact_school or "") + ".\n"
        "Message type: " + angle_label + ". " + guide + "\n"
        "Context from the student: " + (ctx or "None provided") + ".\n"
    )
    if profile_text:
        p += ("\nThe recipient's actual LinkedIn profile text is below. Treat it as the source of truth for "
              "their role, firm, school, and background, and pick the most relevant specific detail as the connection point.\n"
              "--- PROFILE ---\n" + profile_text[:6000] + "\n--- END PROFILE ---\n")
    else:
        p += ("\nIMPORTANT: You could NOT access the recipient's LinkedIn profile. Do NOT invent or assume their "
              "employer, title, group, recent deals, or investment strategy. Use ONLY the recipient details the "
              "student explicitly gave in the context above (such as a company name they mentioned). If you have no "
              "specific verified detail about the recipient, keep the connection point general and lean on the "
              "student's own stated context and intent — never fabricate facts about the recipient.\n")
    p += (
        "\nRules:\n"
        '1. Do not use overly formal or robotic words like "delve", "robust", "thrilled", or "tapestry".\n'
        "2. Sound like a natural, ambitious college student. Roughly 4 to 8 sentences, but follow-ups and thank-yous should be shorter.\n"
        '3. The very first line must be exactly "Subject: [your subject here]". Then two newlines, then the email body. Do not include any other commentary before or after.\n'
        "4. Ensure the subject line uses grammatically correct Title Case.\n"
        "5. Pay close attention to the contact's specific role and firm. Do not mistakenly refer to the contact's job as the student's target role if they are different."
    )
    return p


def _gen_retry(call, tries: int = 4):
    import time
    last = None
    for i in range(tries):
        try:
            return call()
        except Exception as e:
            last = e
            msg = str(e).lower()
            # only retry brief server-side spikes; hard quota (429/resource_exhausted) should fall through fast
            transient = any(k in msg for k in ("503", "unavailable", "overloaded", "high demand"))
            if transient and i < tries - 1:
                time.sleep(1.5 * (i + 1))
                continue
            raise
    raise last


def _gen(system: str, user: str, use_search: bool = False, allow_fallback: bool = True) -> str:
    """Generate text. Try Gemini first; on any failure (quota, outage) fall back to the
    secondary model pool via or_client. With allow_fallback=False, raise instead of
    falling back (use for tasks that need live web search, which the fallback lacks)."""
    gemini_err = None
    try:
        from google import genai
        client = genai.Client(api_key=_get_api_key())
        cfg = {"system_instruction": system}
        if use_search:
            cfg["tools"] = [{"google_search": {}}]
        resp = _gen_retry(lambda: client.models.generate_content(
            model="gemini-2.5-flash", contents=[user], config=cfg))
        t = (getattr(resp, "text", "") or "").strip()
        if t:
            return t
        gemini_err = RuntimeError("Empty Gemini response")
    except Exception as e:
        gemini_err = e
    if not allow_fallback:
        raise gemini_err
    # Fallback tier 1: secondary model pool (OpenRouter free tier, large context).
    try:
        import or_client
        out = or_client.client.chat(user[:90000], system=system[:4000])
        if out and out.strip():
            return out.strip()
    except Exception:
        pass
    # Fallback tier 2: local Ollama (never quota-limited). Free, offline, last resort.
    try:
        out = _ollama_chat(system, user)
        if out and out.strip():
            return out.strip()
    except Exception:
        pass
    raise gemini_err


def _ollama_chat(system: str, user: str) -> str:
    """Call a locally-running Ollama model. Configurable via api_keys.json:
    'ollama_model' (default 'qwen2.5:7b') and 'ollama_url' (default localhost:11434)."""
    import json as _json
    import urllib.request
    cfg = {}
    try:
        cfg = _json.load(open(_API_KEY_PATH)) if "_API_KEY_PATH" in globals() else {}
    except Exception:
        cfg = {}
    if not cfg:
        try:
            import os as _os
            p = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "config", "api_keys.json")
            cfg = _json.load(open(p))
        except Exception:
            cfg = {}
    model = str(cfg.get("ollama_model", "qwen2.5:7b")).strip() or "qwen2.5:7b"
    base = str(cfg.get("ollama_url", "http://localhost:11434")).rstrip("/")
    body = _json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system[:8000]},
            {"role": "user", "content": user[:24000]},
        ],
        "stream": False,
    }).encode("utf-8")
    req = urllib.request.Request(base + "/api/chat", data=body,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        data = _json.loads(r.read().decode("utf-8"))
    return ((data.get("message") or {}).get("content") or "").strip()


def _loads(text):
    """Tolerant JSON loader for local-model output: strips reasoning tags and code
    fences, isolates the outermost object, repairs trailing commas, and falls back to
    Python literal eval."""
    import json as _json
    import re as _re
    if not text:
        return None
    t = text.strip()
    t = _re.sub(r"<think(ing)?>.*?</think(ing)?>", "", t, flags=_re.DOTALL | _re.I)
    t = t.strip()
    if t.startswith("```"):
        t = _re.sub(r"^```[a-zA-Z]*\n?", "", t)
        t = _re.sub(r"\n?```\s*$", "", t).strip()
    i, j = t.find("{"), t.rfind("}")
    if i != -1 and j != -1 and j > i:
        t = t[i:j + 1]
    candidates = [t, _re.sub(r",(\s*[}\]])", r"\1", t)]
    for c in candidates:
        try:
            return _json.loads(c)
        except Exception:
            pass
    try:
        import ast
        py = _re.sub(r"\btrue\b", "True", t)
        py = _re.sub(r"\bfalse\b", "False", py)
        py = _re.sub(r"\bnull\b", "None", py)
        v = ast.literal_eval(py)
        return v if isinstance(v, dict) else None
    except Exception:
        return None


def _generate(prompt: str, use_search: bool) -> str:
    return _gen(OUTREACH_SYSTEM, prompt, use_search=use_search)


def _name_from_linkedin(url: str) -> str:
    m = re.search(r"linkedin\.com/in/([^/?#]+)", url or "", re.I)
    if not m:
        return ""
    slug = re.sub(r"-?[0-9a-fA-F]{6,}$", "", m.group(1))
    slug = re.sub(r"\d+$", "", slug)
    return " ".join(w.capitalize() for w in re.split(r"[-_]", slug) if w and not w.isdigit())


def draft_followup(name="", firm="", role="", notes=""):
    """Short, friendly follow-up nudge after no reply. Returns {subject, body}."""
    s = _sender()
    first = s["name"].split()[0] if s.get("name") else "Best"
    prompt = (
        "Write a SHORT, friendly follow-up email. The student already emailed this person a while ago and "
        "has not heard back; this is a gentle nudge, not a first contact.\n"
        "Student: name=" + s["name"] + ", school=" + s["school"] + ", year=" + s["year"] + ", target=" + s["target"] + ".\n"
        "Recipient: name=" + (name or "") + ", firm=" + (firm or "") + ", role=" + (role or "") + ".\n"
        "Notes/context: " + (notes or "(none)") + ".\n"
        "Keep it 2 to 4 sentences, warm, no guilt-tripping, reaffirm interest and the small ask (a brief chat). "
        'First line "Subject: ...", then a blank line, then the body. Sign off as ' + first + "."
    )
    raw = _generate(prompt, use_search=False)
    subject, body = _parse_email(raw)
    return {"subject": subject, "body": body}


def research_profile(linkedin_url="", email="", context="", angle="intro", name="") -> dict:
    page_text = ""
    read_ok = False
    read_err = ""
    if linkedin_url and "linkedin.com/in/" in linkedin_url.lower():
        _mc = None
        try:
            import mac_chrome as _mc
        except Exception as e:
            read_err = "Reader not installed (mac_chrome.py is missing from the OB folder). " + str(e)[:80]
        if _mc is not None:
            import time as _t
            for _attempt in range(3):
                try:
                    raw = _mc.read_url_text(linkedin_url, wait=4.0)
                    low = (raw or "")[:700].lower()
                    if not raw:
                        read_err = ("Chrome returned nothing. Check: Chrome is running, the automation "
                                    "prompt was approved, and 'Allow JavaScript from Apple Events' is on.")
                    elif len(raw) < 400:
                        read_err = "Page came back nearly empty (%d chars) - still loading or an auth/redirect wall." % len(raw)
                    elif "join linkedin" in low or "sign in" in low or "new to linkedin" in low:
                        read_err = "Hit LinkedIn's login wall - log into LinkedIn in the Chrome that's running, then retry."
                    else:
                        page_text, read_ok = raw, True
                        break
                except Exception as e:
                    read_err = "Chrome read error: " + str(e)[:160]
                _t.sleep(1.5)
    print("[outreach] linkedin read:", "OK (%d chars)" % len(page_text) if read_ok else ("FAIL - " + read_err))

    angle_label = _ANGLE_LABEL.get(angle, "Intro")
    contact_name = name or _name_from_linkedin(linkedin_url)
    prompt = _build_prompt(contact_name, "", "", "", angle_label, context, page_text, situation_key=angle)
    raw = _generate(prompt, use_search=False)
    subject, body = _parse_email(raw)

    if read_ok:
        summary = _profile_brief(page_text)
    elif linkedin_url:
        summary = (read_err or "Couldn't read the LinkedIn page.") + " Drafted from name and angle instead."
    else:
        summary = "Drafted from the details you provided."
    return {"name": contact_name or email or linkedin_url, "summary": summary,
            "subject": subject, "body": body, "read_profile": read_ok}


def outreach(parameters=None, response=None, player=None, session_memory=None, speak=None) -> str:
    params = parameters or {}
    email = str(params.get("email", "")).strip()
    context = str(params.get("context", "")).strip()
    angle = str(params.get("angle", "intro")).strip().lower()
    if angle not in _ANGLE_LABEL:
        angle = "intro"
    if not email or "@" not in email:
        return "I need a recipient email address to draft outreach, Boss."
    try:
        prompt = _build_prompt("", email.split("@")[-1], "", "", _ANGLE_LABEL[angle], context, "", situation_key=angle)
        raw = _generate(prompt, use_search=True)
        subject, body = _parse_email(raw)
    except Exception as e:
        return "Outreach drafting failed: " + str(e)
    if not subject or not body:
        return "I couldn't compose that one. Give me a line of context about who they are and I'll try again."
    try:
        from actions.draft_email import draft_email as draft_email_action
        draft_email_action(parameters={"to": email, "subject": subject, "body": body}, player=player)
    except Exception as e:
        return ("Drafted, but couldn't open the composer (" + str(e) + ").\n\nSubject: " + subject + "\n\n" + body)
    return ("Outreach to " + email + " drafted and opened, Boss. Subject: '" + subject + "'.")
