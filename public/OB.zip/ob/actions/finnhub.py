"""finnhub.py — Thin Finnhub client for live market data (free tier).

Returns both a text block (for the LLM) and structured fields (for the UI): quote,
key stats, EPS beat/miss history, analyst ratings, next-earnings estimates, and news.
Every call is best-effort; failing/premium endpoints return None so callers degrade.
Requires "finnhub_api_key" in config/api_keys.json.
"""
import json
import os
import sys
from datetime import date, timedelta

BASE = "https://finnhub.io/api/v1"


def _base_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _key():
    for _fn in ("keys.json", "api_keys.json"):
        try:
            with open(os.path.join(_base_dir(), "config", _fn)) as f:
                d = json.load(f)
            k = d.get("finnhub_api_key") or d.get("finnhub_key") or ""
            if k:
                return k
        except Exception:
            pass
    return ""


def have_key():
    return bool(_key())


def _get(path, params=None):
    import requests
    k = _key()
    if not k:
        return None
    p = dict(params or {})
    p["token"] = k
    try:
        r = requests.get(BASE + path, params=p, timeout=12)
        if r.status_code != 200:
            return None
        return r.json()
    except Exception:
        return None


def _fmt_money(v):
    try:
        v = float(v)
    except Exception:
        return "—"
    a = abs(v)
    if a >= 1e6:
        return "$%.2fT" % (v / 1e6)
    if a >= 1e3:
        return "$%.1fB" % (v / 1e3)
    if a >= 1:
        return "$%.0fM" % v
    return "$%.2f" % v


def snapshot(symbol):
    """Return live data (text + structured), or None if no key / no quote."""
    symbol = (symbol or "").strip().upper()
    if not _key():
        return None
    out = {"ok": False, "symbol": symbol, "price_line": "", "lines": [],
           "stat_cards": [], "surprises": [], "ratings": None, "next_est": None, "news_items": []}

    q = _get("/quote", {"symbol": symbol})
    if q and q.get("c"):
        c, dp = q.get("c"), q.get("dp")
        out["price"], out["pct"] = c, dp
        sign = "+" if (dp or 0) >= 0 else ""
        out["price_line"] = "$%.2f (%s%.2f%%)" % (c, sign, dp) if dp is not None else "$%.2f" % c
        out["lines"].append("Price: $%.2f, day change %s%.2f%%, prior close $%.2f" % (c, sign, dp or 0, q.get("pc", 0)))
        out["ok"] = True

    prof = _get("/stock/profile2", {"symbol": symbol})
    if prof:
        if prof.get("marketCapitalization"):
            out["lines"].append("Market cap: " + _fmt_money(prof["marketCapitalization"]))
            out["stat_cards"].append({"label": "Market cap", "value": _fmt_money(prof["marketCapitalization"])})
        if prof.get("finnhubIndustry"):
            out["lines"].append("Industry: " + str(prof["finnhubIndustry"]))
            out["industry"] = prof["finnhubIndustry"]

    met = (_get("/stock/metric", {"symbol": symbol, "metric": "all"}) or {}).get("metric", {})
    if met:
        pe = met.get("peNormalizedAnnual") or met.get("peBasicExclExtraTTM") or met.get("peTTM")
        if pe:
            out["lines"].append("P/E: %.1f" % pe)
            out["stat_cards"].append({"label": "P/E", "value": "%.1f" % pe})
        hi, lo = met.get("52WeekHigh"), met.get("52WeekLow")
        if hi and lo:
            out["lines"].append("52-week range: $%.2f - $%.2f" % (lo, hi))
            out["stat_cards"].append({"label": "52-wk range", "value": "$%.0f \u2013 $%.0f" % (lo, hi)})
        npm = met.get("netProfitMarginTTM")
        if npm is not None:
            out["lines"].append("Net margin (TTM): %.1f%%" % npm)
            out["stat_cards"].append({"label": "Net margin", "value": "%.1f%%" % npm})
        rg = met.get("revenueGrowthTTMYoy")
        if rg is not None:
            out["lines"].append("Revenue growth (TTM YoY): %.1f%%" % rg)
            out["stat_cards"].append({"label": "Rev growth TTM", "value": "%.1f%%" % rg})

    earn = _get("/stock/earnings", {"symbol": symbol, "limit": 4})
    if isinstance(earn, list) and earn:
        sl = []
        for e in earn[:4]:
            a, est = e.get("actual"), e.get("estimate")
            if a is None or est is None:
                continue
            beat = round(a - est, 2)
            out["surprises"].append({"period": e.get("period", ""), "actual": a, "estimate": est, "beat": beat})
            sl.append("%s: actual EPS $%.2f vs est $%.2f (%s$%.2f)" % (e.get("period", ""), a, est, "+" if beat >= 0 else "", beat))
        if sl:
            out["lines"].append("Recent EPS surprises: " + "; ".join(sl))

    rec = _get("/stock/recommendation", {"symbol": symbol})
    if isinstance(rec, list) and rec:
        r = rec[0]
        out["ratings"] = {"strongBuy": r.get("strongBuy", 0), "buy": r.get("buy", 0), "hold": r.get("hold", 0),
                          "sell": r.get("sell", 0), "strongSell": r.get("strongSell", 0), "period": r.get("period", "")}
        out["lines"].append("Analyst ratings (%s): %d strong buy, %d buy, %d hold, %d sell, %d strong sell" % (
            r.get("period", ""), r.get("strongBuy", 0), r.get("buy", 0), r.get("hold", 0), r.get("sell", 0), r.get("strongSell", 0)))

    today = date.today()
    cal = _get("/calendar/earnings", {"symbol": symbol, "from": today.isoformat(),
                                      "to": (today + timedelta(days=120)).isoformat()})
    if cal and cal.get("earningsCalendar"):
        ec = cal["earningsCalendar"][0]
        nd = ec.get("date", "")
        out["next_date"] = nd
        ne = {"date": nd, "eps": None, "rev": None}
        bits = ["Next earnings date: " + nd]
        if ec.get("epsEstimate") is not None:
            ne["eps"] = "$%.2f" % ec["epsEstimate"]
            bits.append("EPS estimate $%.2f" % ec["epsEstimate"])
        if ec.get("revenueEstimate"):
            ne["rev"] = _fmt_money(ec["revenueEstimate"] / 1e6)
            bits.append("revenue estimate " + ne["rev"])
        out["next_est"] = ne
        out["lines"].append(", ".join(bits))

    news = _get("/company-news", {"symbol": symbol, "from": (today - timedelta(days=10)).isoformat(),
                                  "to": today.isoformat()})
    if isinstance(news, list):
        for n in news[:6]:
            h = (n.get("headline") or "").strip()
            if h:
                out["news_items"].append({"headline": h, "url": n.get("url", "")})
        out["news"] = [n["headline"] for n in out["news_items"]]

    return out if out["ok"] else None


def as_text(snap):
    if not snap:
        return ""
    txt = "LIVE MARKET DATA (authoritative, from Finnhub):\n- " + "\n- ".join(snap.get("lines", []))
    if snap.get("news"):
        txt += "\n\nRecent headlines:\n- " + "\n- ".join(snap["news"])
    return txt


# ---- Light helpers for the morning brief (1 call each) ----
def quote(symbol):
    q = _get("/quote", {"symbol": symbol})
    if q and q.get("c"):
        return {"price": q["c"], "pct": q.get("dp"), "prev": q.get("pc"),
                "high": q.get("h"), "low": q.get("l"), "open": q.get("o")}
    return None


def company_news(symbol, n=2):
    today = date.today()
    news = _get("/company-news", {"symbol": symbol,
                                  "from": (today - timedelta(days=4)).isoformat(),
                                  "to": today.isoformat()})
    out = []
    if isinstance(news, list):
        for x in news[:n]:
            h = (x.get("headline") or "").strip()
            if h:
                out.append({"headline": h, "url": x.get("url", "")})
    return out


def next_earnings_date(symbol):
    today = date.today()
    cal = _get("/calendar/earnings", {"symbol": symbol, "from": today.isoformat(),
                                      "to": (today + timedelta(days=30)).isoformat()})
    if cal and cal.get("earningsCalendar"):
        return cal["earningsCalendar"][0].get("date", "")
    return ""


def general_news(n=5):
    news = _get("/news", {"category": "general"})
    out = []
    if isinstance(news, list):
        for x in news[:n]:
            h = (x.get("headline") or "").strip()
            if h:
                out.append({"headline": h, "url": x.get("url", "")})
    return out
