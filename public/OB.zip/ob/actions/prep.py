"""prep.py — Coffee-chat / networking-call prep.

Reads a recipient's real LinkedIn profile (via the same logged-in-Chrome reader
OB uses for outreach) and produces a prep dossier: who they are, what you have
in common, sharp questions to ask, talking points, and what to avoid.
"""
import json
import re
from actions.outreach import _get_api_key, _sender, _name_from_linkedin


def _read_profile(url: str) -> str:
    if not url or "linkedin.com/in/" not in url.lower():
        return ""
    try:
        import mac_chrome
    except Exception:
        return ""
    import time as _t
    for _attempt in range(3):
        try:
            raw = mac_chrome.read_url_text(url, wait=4.0)
            low = (raw or "")[:700].lower()
            if raw and len(raw) > 400 and not any(k in low for k in ("join linkedin", "sign in", "new to linkedin")):
                return raw
        except Exception:
            pass
        _t.sleep(1.5)
    return ""


def coffee_prep(linkedin_url: str = "", context: str = "", name: str = "") -> dict:
    page = _read_profile(linkedin_url)
    s = _sender()
    who = (name or _name_from_linkedin(linkedin_url)).strip()

    system = (
        "You prep a college student for a networking call or coffee chat with a finance professional. "
        "You are sharp, specific, and practical. The student: name=" + s["name"] + ", school=" + s["school"] +
        ", year=" + s["year"] + ", targeting " + s["target"] + ".\n"
        "Produce a tight, useful prep dossier. Be concrete, reference real details about the recipient, "
        "never invent facts. Questions must be specific to this person, not generic.\n"
        'Return ONLY JSON: {"snapshot": "2-3 sentences on who they are and their path", '
        '"commonalities": ["specific shared things between the student and them"], '
        '"questions": ["5 sharp, specific questions to ask them"], '
        '"talking_points": ["things the student should mention or steer toward"], '
        '"watchouts": ["1-3 things to avoid or be aware of"]}. Nothing outside the JSON.'
    )
    blocks = ["Recipient: " + (who or "(name unknown)")]
    if linkedin_url:
        blocks.append("LinkedIn: " + linkedin_url)
    if context:
        blocks.append("Context from the student (what the call is for): " + context)
    if page:
        blocks.append("RECIPIENT LINKEDIN PAGE TEXT (authoritative):\n" + page[:6000])
    blocks.append("Build the dossier. Return only the JSON.")
    user_msg = "\n\n".join(blocks)

    from actions.outreach import _gen, _loads

    def _attempt(use_search):
        try:
            return _loads(_gen(system, user_msg, use_search=use_search, allow_fallback=True))
        except Exception:
            return None

    d = _attempt(use_search=(not page))
    if not isinstance(d, dict):
        # retry as pure generation (covers search/quota failures) so a card still renders
        d = _attempt(use_search=False)
    if not isinstance(d, dict):
        d = {"snapshot": "Couldn't pull a full dossier this round — here's a quick frame; re-run for more depth."
                         + ("" if page else " (Tip: open their LinkedIn in Chrome and make sure you're logged in for a richer read.)"),
             "commonalities": [],
             "questions": [
                 "How did you get into your current seat, and what surprised you most early on?",
                 "What separates the people who break in here from the ones who don't?",
                 "If you were in my shoes as a student, where would you focus your next year?"],
             "talking_points": [], "watchouts": []}

    def _list(x):
        return [str(i).strip() for i in x if str(i).strip()] if isinstance(x, list) else []

    return {
        "name": who or linkedin_url,
        "snapshot": str(d.get("snapshot", "")).strip(),
        "commonalities": _list(d.get("commonalities")),
        "questions": _list(d.get("questions")),
        "talking_points": _list(d.get("talking_points")),
        "watchouts": _list(d.get("watchouts")),
        "read_profile": bool(page),
    }
