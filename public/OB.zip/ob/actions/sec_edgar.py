"""
sec_edgar.py — Direct SEC EDGAR filings pull. Free, official, no API key.
Caches ticker->CIK mapping. Pulls latest 10-K, 10-Q, 8-K for a company.
"""
import os
import json
import time
import requests
from pathlib import Path

# SEC requires a User-Agent identifying who you are (per their fair-use policy)
SEC_UA = "OfferBell OB research@offerbell.org"
SEC_HEADERS = {"User-Agent": SEC_UA, "Accept-Encoding": "gzip, deflate"}

TICKER_MAP_URL = "https://www.sec.gov/files/company_tickers.json"
SUBMISSIONS_URL = "https://data.sec.gov/submissions/CIK{cik}.json"

CACHE_DIR = Path("cache")
CACHE_DIR.mkdir(exist_ok=True)
TICKER_CACHE = CACHE_DIR / "sec_tickers.json"
TICKER_CACHE_MAX_AGE = 7 * 24 * 3600  # refresh weekly


def _load_ticker_map():
    """Returns dict mapping uppercase ticker -> 10-digit zero-padded CIK string."""
    fresh = False
    if TICKER_CACHE.exists():
        age = time.time() - TICKER_CACHE.stat().st_mtime
        if age < TICKER_CACHE_MAX_AGE:
            try:
                return json.loads(TICKER_CACHE.read_text(encoding="utf-8"))
            except Exception:
                pass

    try:
        r = requests.get(TICKER_MAP_URL, headers=SEC_HEADERS, timeout=10)
        raw = r.json()
        mapping = {}
        for entry in raw.values():
            ticker = entry.get("ticker", "").upper()
            cik = str(entry.get("cik_str", "")).zfill(10)
            if ticker and cik:
                mapping[ticker] = cik
        TICKER_CACHE.write_text(json.dumps(mapping), encoding="utf-8")
        return mapping
    except Exception:
        if TICKER_CACHE.exists():
            try:
                return json.loads(TICKER_CACHE.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {}


def lookup_cik(ticker):
    mapping = _load_ticker_map()
    return mapping.get(ticker.upper().strip())


def get_recent_filings(ticker, types=("10-K", "10-Q", "8-K"), limit_per_type=2):
    """Returns list of dicts: {type, date, url, description}."""
    cik = lookup_cik(ticker)
    if not cik:
        return []

    try:
        r = requests.get(
            SUBMISSIONS_URL.format(cik=cik),
            headers=SEC_HEADERS,
            timeout=10,
        )
        data = r.json()
        recent = data.get("filings", {}).get("recent", {})
        forms = recent.get("form", [])
        dates = recent.get("filingDate", [])
        accessions = recent.get("accessionNumber", [])
        primary_docs = recent.get("primaryDocument", [])
        descriptions = recent.get("primaryDocDescription", [])

        results = []
        counts = {t: 0 for t in types}
        cik_int = int(cik)

        for i, form in enumerate(forms):
            if form not in types:
                continue
            if counts[form] >= limit_per_type:
                continue
            acc_clean = accessions[i].replace("-", "")
            doc_url = f"https://www.sec.gov/Archives/edgar/data/{cik_int}/{acc_clean}/{primary_docs[i]}"
            results.append({
                "type": form,
                "date": dates[i],
                "url": doc_url,
                "description": descriptions[i] if i < len(descriptions) else "",
            })
            counts[form] += 1

        return results
    except Exception as e:
        return []


def get_company_name(ticker):
    cik = lookup_cik(ticker)
    if not cik:
        return None
    try:
        r = requests.get(SUBMISSIONS_URL.format(cik=cik), headers=SEC_HEADERS, timeout=10)
        return r.json().get("name")
    except Exception:
        return None


def fetch_filing_text(url, max_chars=5000):
    """Pulls filing text. SEC filings are HTML; we strip to plain text."""
    try:
        from bs4 import BeautifulSoup
        r = requests.get(url, headers=SEC_HEADERS, timeout=15)
        soup = BeautifulSoup(r.text, "html.parser")
        for tag in soup(["script", "style", "table"]):
            tag.decompose()
        text = " ".join(soup.get_text(" ").split())
        return text[:max_chars]
    except Exception:
        return ""
